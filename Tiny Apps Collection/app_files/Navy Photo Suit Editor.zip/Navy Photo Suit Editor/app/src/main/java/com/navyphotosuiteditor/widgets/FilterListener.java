package com.navyphotosuiteditor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}