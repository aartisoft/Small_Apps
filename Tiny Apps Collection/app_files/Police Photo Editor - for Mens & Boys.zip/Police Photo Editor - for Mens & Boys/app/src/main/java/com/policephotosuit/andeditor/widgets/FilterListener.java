package com.policephotosuit.andeditor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}