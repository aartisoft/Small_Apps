package com.policephotosuit.andeditor.Activity;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.policephotosuit.andeditor.ConnectionDetector;
import com.policephotosuit.andeditor.Constant;
import com.policephotosuit.andeditor.Eraser_Tools.CutOut;
import com.policephotosuit.andeditor.R;
import com.policephotosuit.andeditor.Utility;
import com.policephotosuit.andeditor.Cropimage.CropImage;
import com.policephotosuit.andeditor.Cropimage.InternalStorageContentProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import static com.google.android.gms.common.util.IOUtils.copyStream;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Select_Image_Activity extends AppCompatActivity{


    private ConnectionDetector detectorconn;
    Boolean conn;
    File mFileTemp;
    Constant constantfile;
    LinearLayout camera_ll,gallery_ll;
    private int REQUEST_CAMERA = 2, SELECT_FILE = 1,CROP_IMAGE = 3;

    private String userChoosenTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectimage);

        constantfile = new Constant();
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        ActionBar action = getSupportActionBar();
        action.setTitle(getResources().getString(R.string.choose_image_title));
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        camera_ll = (LinearLayout) findViewById(R.id.camera_ll);
        gallery_ll = (LinearLayout) findViewById(R.id.gallery_ll);


        camera_ll.setOnClickListener(v -> selectImage("camera"));

        gallery_ll.setOnClickListener(v -> selectImage("gallery"));


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if(userChoosenTask.equals("camera"))
                        cameraIntent();
                    else if(userChoosenTask.equals("gallery"))
                        galleryIntent();
                } else {
                    //code for deny
                }
                break;
        }
    }

    private void selectImage(String type) {
        boolean result= Utility.checkPermission(Select_Image_Activity.this);
        userChoosenTask = type;
        if (type.equals("camera")) {
            if(result)
                cameraIntent();

        } else if (type.equals("gallery")) {
            if (result)
                galleryIntent();
        }
    }

    private void galleryIntent()
    {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mFileTemp = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".png");
        } else {
            mFileTemp = new File(getFilesDir(), System.currentTimeMillis() + ".png");
        }
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_PICK);//
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(Intent.createChooser(intent, "Select File"),SELECT_FILE);
    }

    private void cameraIntent()
    {
        Uri mImageCaptureUri = null;
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mFileTemp = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".png");
            mImageCaptureUri = FileProvider.getUriForFile(Select_Image_Activity.this, getApplicationContext().getPackageName()+".provider" , mFileTemp);
        } else {
            mFileTemp = new File(getFilesDir(), System.currentTimeMillis() + ".png");
            mImageCaptureUri = InternalStorageContentProvider.CONTENT_URI;
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, mImageCaptureUri);
        startActivityForResult(intent, REQUEST_CAMERA);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1){
            if (resultCode == Activity.RESULT_OK) {
                if (requestCode == SELECT_FILE)
                    onSelectFromGalleryResult(data);
                else if (requestCode == REQUEST_CAMERA)
                    onCaptureImageResult(data);
                else if (requestCode == CROP_IMAGE)
                    onCropandRotateOpenErase(data);
                else if(requestCode == CutOut.CUTOUT_ACTIVITY_REQUEST_CODE){
                    switch (resultCode) {
                        case Activity.RESULT_OK:
                            onCropandRotateResult(data);
                            break;
                        case CutOut.CUTOUT_ACTIVITY_RESULT_ERROR_CODE:
                            Exception ex = CutOut.getError(data);
                            Log.e("gettingerror", ex.getMessage()+"     :::  CUTOUT_ACTIVITY_RESULT_ERROR_CODE");
                            break;
                        default:
                            Log.e("gettingerror",     " :::  default");
                            System.out.print("User cancelled the CutOut screen");
                    }
                }
            }
        }

    }

    private void onCaptureImageResult(Intent data) {
        try {
            startCropImage();
        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (IndexOutOfBoundsException e) {
        } catch (OutOfMemoryError e) {
        } catch (NullPointerException e) {
        } catch (NumberFormatException e) {
        } catch (Exception e) {

        }
    }

    @SuppressWarnings("deprecation")
    private void onSelectFromGalleryResult(Intent data) {

        try {

            InputStream inputStream = getContentResolver().openInputStream(data.getData());
            FileOutputStream fileOutputStream = new FileOutputStream(mFileTemp);
            copyStream(inputStream, fileOutputStream);
            fileOutputStream.close();
            inputStream.close();
            startCropImage();

        } catch (ArrayIndexOutOfBoundsException e) {
            Log.e("selectedfileerror ","arrayindex:::   "+e.toString());
        } catch (IndexOutOfBoundsException e) {
            Log.e("selectedfileerror ","indextout:::   "+e.toString());
        } catch (OutOfMemoryError e) {
            Log.e("selectedfileerror ","outofmemory:::   "+e.toString());
        } catch (NullPointerException e) {
            Log.e("selectedfileerror ","nullpointer:::   "+e.toString());
        } catch (NumberFormatException e) {
            Log.e("selectedfileerror ","numberfrmate:::   "+e.toString());
        } catch (Exception e) {
            Log.e("selectedfileerror ","exception:::   "+e.toString());
        }

    }


    @SuppressWarnings("deprecation")
    private void onCropandRotateOpenErase(Intent data) {
        String path = data.getStringExtra("image-path");
        Log.e("callingpath","calling +->  "+path);
        if (path == null) {
            return;
        }
        CutOut.activity()
                .src(Uri.fromFile(mFileTemp))
                .bordered()
                .noCrop()
                .start(this);

    }

    @SuppressWarnings("deprecation")
    private void onCropandRotateResult(Intent data) {
        Log.e("callingeditscreen","calling +->  ");
        try {
            Intent i1 = new Intent(Select_Image_Activity.this, SetEditSuitActivity.class);
            Constant.bmpUri = CutOut.getUri(data);
            try {
                if(  Constant.bmpUri != null   ){
                    Constant.bmp = MediaStore.Images.Media.getBitmap(getContentResolver() , Constant.bmpUri);
                }
            }
            catch (Exception e) {
                //handle exception
            }
            startActivity(i1);
            finish();
        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (IndexOutOfBoundsException e) {
        } catch (OutOfMemoryError e) {
        } catch (NullPointerException e) {
        } catch (NumberFormatException e) {
        } catch (Exception e) {
        }
    }

    private void startCropImage() {
        Intent intent = new Intent(this, CropImage.class);
        intent.putExtra("image-path", mFileTemp.getPath());
        intent.putExtra(CropImage.RETURN_DATA, false);
        startActivityForResult(intent, CROP_IMAGE);

    }

}
