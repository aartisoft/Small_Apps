package com.policephotosuit.andeditor.Activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RelativeLayout;

import com.policephotosuit.andeditor.Constant;
import com.policephotosuit.andeditor.R;
import com.policephotosuit.andeditor.Utility;
import com.policephotosuit.andeditor.widgets.FilterListener;
import com.policephotosuit.andeditor.widgets.FilterViewAdapter;
import com.policephotosuit.andeditor.widgets.OnPhotoEditorListener;
import com.policephotosuit.andeditor.widgets.PhotoEditor;
import com.policephotosuit.andeditor.widgets.PhotoEditorView;
import com.policephotosuit.andeditor.widgets.PhotoFilter;
import com.policephotosuit.andeditor.widgets.SaveSettings;
import com.policephotosuit.andeditor.widgets.StickerBSFragment;
import com.policephotosuit.andeditor.widgets.TextEditorDialogFragment;
import com.policephotosuit.andeditor.widgets.TextStyleBuilder;
import com.policephotosuit.andeditor.widgets.ViewType;

import java.io.File;
import java.io.IOException;

import static com.policephotosuit.andeditor.Constant.finalimagepath;


public class EditActivity extends AppCompatActivity implements Constant.Callingafterads,OnPhotoEditorListener, FilterListener, StickerBSFragment.StickerListener {

    Animation in, out;
    RelativeLayout relative_edit;
    Constant constantfile;

    private PhotoEditor mPhotoEditor;
    private PhotoEditorView mPhotoEditorView;
    private StickerBSFragment mStickerBSFragment;
    private RecyclerView mRvFilters;
    private FilterViewAdapter mFilterViewAdapter = new FilterViewAdapter(EditActivity.this,this);
    private boolean mIsFilterVisible = false;

    ImageView imgUndo,imgRedo;
    Button back;
    AlertDialog alert;
    RadioButton radio_sticker, radio_effect, radio_text, radio_save;


    @SuppressLint("NewApi")
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_activity_frame);

        constantfile = new Constant();

        try {
            relative_edit = (RelativeLayout) findViewById(R.id.relative_edit);

            mRvFilters = (RecyclerView) findViewById(R.id.rvFilterView);
            back = (Button) findViewById(R.id.back);

            LinearLayoutManager llmFilters = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
            mRvFilters.setLayoutManager(llmFilters);
            mRvFilters.setAdapter(mFilterViewAdapter);


            mStickerBSFragment = new StickerBSFragment();
            mStickerBSFragment.setStickerListener(this);
            showFilter(false);
            mPhotoEditorView = findViewById(R.id.photoEditorView);
            imgUndo = findViewById(R.id.imgUndo);
            imgRedo = findViewById(R.id.imgRedo);
            radio_sticker = (RadioButton) findViewById(R.id.radio_sticker);
            radio_effect = (RadioButton) findViewById(R.id.radio_effect);
            radio_text = (RadioButton) findViewById(R.id.radio_text);
            radio_save = (RadioButton) findViewById(R.id.radio_save);
            radio_sticker.setOnClickListener(radio_listener);
            radio_effect.setOnClickListener(radio_listener);
            radio_text.setOnClickListener(radio_listener);
            radio_save.setOnClickListener(radio_listener);

            in = AnimationUtils.loadAnimation(this, R.anim.in);
            out = AnimationUtils.loadAnimation(this, R.anim.out);

            mPhotoEditor = new PhotoEditor.Builder(this, mPhotoEditorView)
                    .setPinchTextScalable(true) // set flag to make text scalable when pinch
                    //.setDefaultTextTypeface(mTextRobotoTf)
                    //.setDefaultEmojiTypeface(mEmojiTypeFace)
                    .build(); // build photo andeditor sdk

            mPhotoEditor.setOnPhotoEditorListener(this);

            //Set Image Dynamically
            mPhotoEditorView.getSource().setImageBitmap(Constant.getSuitimage);

            imgUndo.setOnClickListener(v ->mPhotoEditor.undo());
            imgRedo.setOnClickListener(v ->mPhotoEditor.redo());

        } catch (NullPointerException e) {

        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (ActivityNotFoundException e) {

        } catch (ClassCastException e) {

        } catch (NoClassDefFoundError e) {
            // TODO: handle exception
        } catch (Exception e) {
            // TODO: handle exception
        }

        back.setOnClickListener(v -> onBackPressed());


    }


    View.OnClickListener radio_listener = new View.OnClickListener() {
        @SuppressLint("NewApi")
        public void onClick(View v) {
            showFilter(false);
            if (v == radio_effect) {
                showFilter(true);
            } else if (v == radio_sticker) {
                mStickerBSFragment.show(getSupportFragmentManager(), mStickerBSFragment.getTag());
            } else if (v == radio_text) {
                AddText();
            } else if (v == radio_save) {
                saveImage();
            }
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    void showFilter(boolean isVisible) {
        if (isVisible) {
            mRvFilters.setVisibility(View.VISIBLE);
        } else {
            mRvFilters.setVisibility(View.GONE);
        }
        mIsFilterVisible = isVisible;


    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    void AddText() {
        TextEditorDialogFragment textEditorDialogFragment = TextEditorDialogFragment.show(this);
        textEditorDialogFragment.setOnTextEditorListener(new TextEditorDialogFragment.TextEditor() {
            @Override
            public void onDone(String inputText, int colorCode, Typeface font) {
                final TextStyleBuilder styleBuilder = new TextStyleBuilder();
                styleBuilder.withTextColor(colorCode);
                styleBuilder.withTextFont(font);
                mPhotoEditor.addText(inputText, styleBuilder);
            }
        });


    }


    @SuppressLint("NewApi")
    @Override
    public void onBackPressed() {
        if (mIsFilterVisible) {
            showFilter(false);
        } else {
            AppExit();
        }
    }

    public void AppExit() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.AlertDialog);
        alertDialogBuilder.setMessage(getResources().getString(R.string.exit_editimage_title));
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        alert.dismiss();
                        Intent intent = new Intent(EditActivity.this, MainActivity.class);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });
        alert = alertDialogBuilder.create();
        alert.show();

    }


    public boolean dir_exists(String dir_path) {
        boolean ret = false;
        File dir = new File(dir_path);
        if (dir.exists() && dir.isDirectory())
            ret = true;
        return ret;
    }


    @SuppressLint("MissingPermission")
    private void saveImage() {
        boolean result = Utility.checkPermission(EditActivity.this);
        if (result) {
            constantfile.showLoading(EditActivity.this, "Saving...");
            String dir_path = Environment.getExternalStorageDirectory().toString() + "/" + getResources().getString(R.string.download_directory) + "/";

            if (!dir_exists(dir_path)) {
                File directory = new File(dir_path);
                if (directory.mkdirs()) {
                    Log.v("dir", "is created 1");
                } else { }
                if (directory.mkdir()) {
                    Log.v("dir", "is created 2");
                } else { }
            } else { }

            File file = new File(dir_path + getResources().getString(R.string.download_imagename) + "_" + System.currentTimeMillis() + ".png");
            try {
                file.createNewFile();

                SaveSettings saveSettings = new SaveSettings.Builder()
                        .setClearViewsEnabled(true)
                        .setTransparencyEnabled(true)
                        .build();

                mPhotoEditor.saveAsFile(file.getAbsolutePath(), saveSettings, new PhotoEditor.OnSaveListener() {
                    @Override
                    public void onSuccess(@NonNull String imagePath) {
                        finalimagepath = imagePath;
                        constantfile.hideLoading();
                        mPhotoEditorView.getSource().setImageURI(Uri.fromFile(new File(imagePath)));
                        if (finalimagepath != null && !finalimagepath.equals("")) {
                            callads();
                        } else {
                            constantfile.snackbarcommonview(EditActivity.this, relative_edit, "Something Went Wrong! Please Try Again");
                        }

                    }

                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        constantfile.hideLoading();
                        constantfile.snackbarcommonview(EditActivity.this, relative_edit, "Something Went Wrong! Please Try Again");
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
                constantfile.hideLoading();
                constantfile.snackbarcommonview(EditActivity.this, relative_edit, "Something Went Wrong! Please Try Again");
            }
        }
    }

    public void callads() {
        constantfile.loadInterstitialAd(EditActivity.this,this);
    }

    @Override
    public void onAdsresponce(Boolean showing) {
        Intent intent = new Intent(EditActivity.this, Final_Image_Activity.class);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }


    @Override
    public void onFilterSelected(PhotoFilter photoFilter) {
        mPhotoEditor.setFilterEffect(photoFilter);
    }


    @Override
    public void onStickerClick(Bitmap bitmap, int position) {
        mPhotoEditor.addImage(bitmap);

    }

    @Override
    public void onEditTextChangeListener(View rootView, String text, int colorCode) {
//        TextEditorDialogFragment textEditorDialogFragment = TextEditorDialogFragment.show(this, text, colorCode);
//        textEditorDialogFragment.setOnTextEditorListener(new TextEditorDialogFragment.TextEditor() {
//            @Override
//            public void onDone(String inputText, int colorCode, Typeface font) {
//                final TextStyleBuilder styleBuilder = new TextStyleBuilder();
//                styleBuilder.withTextColor(colorCode);
//                styleBuilder.withTextFont(font);
//                mPhotoEditor.editText(rootView, inputText, styleBuilder);
//            }
//        });
    }

    @Override
    public void onAddViewListener(ViewType viewType, int numberOfAddedViews) {

    }

    @Override
    public void onRemoveViewListener(ViewType viewType, int numberOfAddedViews) {

    }

    @Override
    public void onStartViewChangeListener(ViewType viewType) {

    }

    @Override
    public void onStopViewChangeListener(ViewType viewType) {

    }


}
