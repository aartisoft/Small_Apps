package com.traditional.womenphotosuiteditor.widgets;

import android.content.Context;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.traditional.womenphotosuiteditor.Constant;
import com.traditional.womenphotosuiteditor.R;

import java.util.List;


public class FontPickerAdapter extends RecyclerView.Adapter<FontPickerAdapter.ViewHolder> {

    private Context context;
    private LayoutInflater inflater;
    private List<String> arrayoffont;
    private OnFontPickerClickListener onfontPickerClickListener;

    FontPickerAdapter(@NonNull Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.arrayoffont = Constant.arrayoffont;
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = inflater.inflate(R.layout.font_picker_item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Typeface text_font  = Typeface.createFromAsset(context.getAssets(), "font/"+Constant.arrayoffont.get(position));
        holder.font_text_view.setTypeface(text_font);
        holder.font_text_view.setText("Abc");
    }

    @Override
    public int getItemCount() {
        return arrayoffont.size();
    }


    public void setOnfontPickerClickListener(OnFontPickerClickListener onfontPickerClickListener) {
        this.onfontPickerClickListener = onfontPickerClickListener;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView font_text_view;

        public ViewHolder(View itemView) {
            super(itemView);
            font_text_view = itemView.findViewById(R.id.font_text_view);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onfontPickerClickListener != null)
                        onfontPickerClickListener.onfontPickerClickListener(getAdapterPosition());
                }
            });
        }
    }

    public interface OnFontPickerClickListener {
        void onfontPickerClickListener(int pos);
    }

}
