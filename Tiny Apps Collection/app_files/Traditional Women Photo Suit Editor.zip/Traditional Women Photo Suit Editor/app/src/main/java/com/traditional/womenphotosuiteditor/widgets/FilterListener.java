package com.traditional.womenphotosuiteditor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}