package com.traditional.womenphotosuiteditor.widgets;



public enum ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
