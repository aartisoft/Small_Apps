package com.bulletbikephotosuit.editor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}