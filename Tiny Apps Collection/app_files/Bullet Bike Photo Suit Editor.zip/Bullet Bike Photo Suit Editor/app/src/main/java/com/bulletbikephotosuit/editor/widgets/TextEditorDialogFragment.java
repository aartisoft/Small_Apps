package com.bulletbikephotosuit.editor.widgets;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bulletbikephotosuit.editor.Constant;
import com.bulletbikephotosuit.editor.R;


public class TextEditorDialogFragment extends DialogFragment {

    public static final String TAG = TextEditorDialogFragment.class.getSimpleName();
    public static final String EXTRA_INPUT_TEXT = "extra_input_text";
    public static final String EXTRA_COLOR_CODE = "extra_color_code";
    private Button add_text_done,back;
    private RelativeLayout cancel_rl;
    TextView final_addtext;
    TextView font_tv,color_tv;
    private InputMethodManager mInputMethodManager;
    private int mColorCode;
    private Typeface text_font;
    private TextEditor mTextEditor;
    EditText add_text_type;
    RecyclerView font_picker_recycler_view,color_picker_recycler_view;

    public interface TextEditor {
        void onDone(String inputText, int colorCode, Typeface font);
    }


    //Show dialog with provide text and text color
    public static TextEditorDialogFragment show(@NonNull AppCompatActivity appCompatActivity,
                                                @NonNull String inputText,
                                                @ColorInt int colorCode) {
        Bundle args = new Bundle();
        args.putString(EXTRA_INPUT_TEXT, inputText);
        args.putInt(EXTRA_COLOR_CODE, colorCode);
        TextEditorDialogFragment fragment = new TextEditorDialogFragment();
        fragment.setArguments(args);
        fragment.show(appCompatActivity.getSupportFragmentManager(), TAG);
        return fragment;
    }

    //Show dialog with default text input as empty and text color white
    public static TextEditorDialogFragment show(@NonNull AppCompatActivity appCompatActivity) {
        return show(appCompatActivity, "", ContextCompat.getColor(appCompatActivity, R.color.white));
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.add_text_dialog, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mInputMethodManager = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        add_text_done = view.findViewById(R.id.add_text_done);
        back = view.findViewById(R.id.back);
        cancel_rl = view.findViewById(R.id.cancel_rl);
        add_text_type = view.findViewById(R.id.add_text_type);
        final_addtext = view.findViewById(R.id.final_addtext);
        font_tv = view.findViewById(R.id.font_tv);
        color_tv = view.findViewById(R.id.color_tv);


        color_picker_recycler_view = view.findViewById(R.id.color_picker_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        color_picker_recycler_view.setLayoutManager(layoutManager);
        color_picker_recycler_view.setHasFixedSize(true);
        ColorPickerAdapter colorPickerAdapter = new ColorPickerAdapter(getActivity());
        colorPickerAdapter.setOnColorPickerClickListener(colorCode -> {
            mColorCode = colorCode;
            final_addtext.setTextColor(colorCode);
        });
        color_picker_recycler_view.setAdapter(colorPickerAdapter);

        font_picker_recycler_view = view.findViewById(R.id.font_picker_recycler_view);
        LinearLayoutManager fontManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        font_picker_recycler_view.setLayoutManager(fontManager);
        font_picker_recycler_view.setHasFixedSize(true);

        FontPickerAdapter fontPickeradapter = new FontPickerAdapter(getActivity());
        fontPickeradapter.setOnfontPickerClickListener(pos -> {
            text_font  = Typeface.createFromAsset(getActivity().getAssets(), "font/"+Constant.arrayoffont.get(pos));
            final_addtext.setTypeface(text_font);
        });

        font_picker_recycler_view.setAdapter(fontPickeradapter);

        hideonInit();

        final_addtext.setText(getArguments().getString(EXTRA_INPUT_TEXT));
        text_font  = Typeface.createFromAsset(getActivity().getAssets(), "font/"+Constant.arrayoffont.get(0));
        mColorCode = getArguments().getInt(EXTRA_COLOR_CODE);
        final_addtext.setTextColor(mColorCode);
        final_addtext.setTypeface(text_font);
        mInputMethodManager.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);


        add_text_done.setOnClickListener(view1 -> {
            mInputMethodManager.hideSoftInputFromWindow(view1.getWindowToken(), 0);
            dismiss();
            String inputText = final_addtext.getText().toString();
            if (!TextUtils.isEmpty(inputText) && mTextEditor != null) {
                mTextEditor.onDone(inputText, mColorCode,text_font);
            }
        });

        back.setOnClickListener(v -> onDismiss(getDialog()));

        cancel_rl.setOnClickListener(v -> onDismiss(getDialog()));

        add_text_type.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (add_text_type.getText() != null && !add_text_type.getText().equals("")){
                    final_addtext.setText(add_text_type.getText().toString());
                }else{
                    final_addtext.setText("");
                }
            }
        });

        color_tv.setOnClickListener(v -> showcolorlist());
        font_tv.setOnClickListener(v -> showfontlist());

    }

    public void hideonInit(){
        color_picker_recycler_view.setVisibility(View.GONE);
        font_picker_recycler_view.setVisibility(View.GONE);
    }

    public void showcolorlist(){
        color_picker_recycler_view.setVisibility(View.VISIBLE);
        font_picker_recycler_view.setVisibility(View.GONE);
    }

    public void showfontlist(){
        font_picker_recycler_view.setVisibility(View.VISIBLE);
        color_picker_recycler_view.setVisibility(View.GONE);
    }


    public void setOnTextEditorListener(TextEditor textEditor) {
        mTextEditor = textEditor;
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);

    }
}