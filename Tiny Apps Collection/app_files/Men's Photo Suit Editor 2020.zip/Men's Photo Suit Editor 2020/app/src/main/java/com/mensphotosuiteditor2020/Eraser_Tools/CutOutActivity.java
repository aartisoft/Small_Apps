package com.mensphotosuiteditor2020.Eraser_Tools;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.mensphotosuiteditor2020.R;

public class CutOutActivity extends AppCompatActivity {

    private static final int WRITE_EXTERNAL_STORAGE_CODE = 1;

    private static final short BORDER_SIZE = 45;
    Button back;
    Button undoButton,redoButton;
    RadioButton radio_auto, radio_erase, radio_restore, radio_zoom;


    public DrawingView drawingdv;
    private ImageView dv1;
    private RelativeLayout main_rel;
    private SeekBar offset_seekbar, offset_seekbar1;
    private SeekBar radius_seekbar;
    private LinearLayout lay_offset_seek;
    private LinearLayout lay_threshold_seek;
    public ImageView tbg_img;
    public static Bitmap bgCircleBit = null;
    public static Bitmap bitmap = null;
    public Bitmap mainbitmap = null;
    public int height;
    public int width;
    public static Uri selectedImageUri;
    public static BitmapShader patternBMPshader;
    public boolean showDialog = false;
    private ShaderView shaderView;
    public RelativeLayout rel_seek_container;
    private SeekBar threshold_seekbar;
    MultiTouchListener multiTouchListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_photo_erase);

        Toolbar toolbar = findViewById(R.id.photo_edit_toolbar);
        toolbar.setBackgroundColor(Color.BLACK);
        toolbar.setTitleTextColor(Color.WHITE);
        //setSupportActionBar(toolbar);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int i = displayMetrics.heightPixels;
        this.width = displayMetrics.widthPixels;
        this.height = i - ImageUtils.dpToPx(this, 120);

        initializeActionButtons();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false);

            if (toolbar.getNavigationIcon() != null) {
                toolbar.getNavigationIcon().setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_ATOP);
            }

        }

        Button doneButton = findViewById(R.id.done);

        doneButton.setOnClickListener(v -> startSaveDrawingTask());

        start();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                setResult(RESULT_CANCELED);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private Uri getExtraSource() {
        return getIntent().hasExtra(CutOut.CUTOUT_EXTRA_SOURCE) ? (Uri) getIntent().getParcelableExtra(CutOut.CUTOUT_EXTRA_SOURCE) : null;
    }

    private void start() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {

            Uri uri = getExtraSource();
            if (uri != null) {
                this.main_rel.postDelayed(new Runnable() {
                    public void run() {
                        CutOutActivity.this.tbg_img.setImageBitmap(ImageUtils.getTiledBitmap(CutOutActivity.this, R.drawable.tbg, CutOutActivity.this.width, CutOutActivity.this.height));
                        CutOutActivity.bgCircleBit = ImageUtils.getBgCircleBit(CutOutActivity.this, R.drawable.tbg);
                        CutOutActivity.this.importImageFromUri(uri);
                    }
                }, 1000);
            }
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    WRITE_EXTERNAL_STORAGE_CODE);
        }
    }

    private void startSaveDrawingTask() {
        SaveDrawingTask task = new SaveDrawingTask(this);
        try{
            int borderColor;
            if ((borderColor = getIntent().getIntExtra(CutOut.CUTOUT_EXTRA_BORDER_COLOR, -1)) != -1) {
                bitmap = BitmapUtility.getBorderedBitmap(this.drawingdv.getFinalBitmap(), borderColor, BORDER_SIZE);
                task.execute(bitmap);
            } else {
                bitmap = this.drawingdv.getFinalBitmap();
                task.execute(bitmap);
            }
        }catch (Exception e){
            exitWithError(e);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            start();
        } else {
            setResult(Activity.RESULT_CANCELED);
            finish();
        }
    }


    private void initializeActionButtons() {
        multiTouchListener = new MultiTouchListener();
        undoButton = findViewById(R.id.undo);
        redoButton = findViewById(R.id.redo);
        back = findViewById(R.id.back);
        this.rel_seek_container = (RelativeLayout) findViewById(R.id.rel_seek_container);
        radio_auto = (RadioButton) findViewById(R.id.radio_auto);
        radio_erase = (RadioButton) findViewById(R.id.radio_erase);
        radio_restore = (RadioButton) findViewById(R.id.radio_restore);
        radio_zoom = (RadioButton) findViewById(R.id.radio_zoom);
        radio_auto.setOnClickListener(radio_listener);
        radio_erase.setOnClickListener(radio_listener);
        radio_restore.setOnClickListener(radio_listener);
        radio_zoom.setOnClickListener(radio_listener);

        this.tbg_img = (ImageView) findViewById(R.id.tbg_img);
        main_rel = (RelativeLayout) findViewById(R.id.main_rel);
        lay_threshold_seek = (LinearLayout) findViewById(R.id.lay_threshold_seek);
        lay_offset_seek = (LinearLayout) findViewById(R.id.lay_offset_seek);
        offset_seekbar = (SeekBar) findViewById(R.id.offset_seekbar);
        offset_seekbar1 = (SeekBar) findViewById(R.id.offset_seekbar1);

        SeekBar.OnSeekBarChangeListener r0 = new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (CutOutActivity.this.drawingdv != null) {
                    CutOutActivity.this.drawingdv.setOffset(i - 150);
                    CutOutActivity.this.drawingdv.invalidate();
                }
            }
        };
        this.offset_seekbar.setOnSeekBarChangeListener(r0);
        this.offset_seekbar1.setOnSeekBarChangeListener(r0);
        this.radius_seekbar = (SeekBar) findViewById(R.id.radius_seekbar);
        this.radius_seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (CutOutActivity.this.drawingdv != null) {
                    CutOutActivity.this.drawingdv.setRadius(i + 2);
                    CutOutActivity.this.drawingdv.invalidate();
                }
            }
        });
        this.threshold_seekbar = (SeekBar) findViewById(R.id.threshold_seekbar);
        this.threshold_seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                if (CutOutActivity.this.drawingdv != null) {
                    CutOutActivity.this.drawingdv.setThreshold(seekBar.getProgress() + 10);
                    CutOutActivity.this.drawingdv.updateThreshHold();
                }
            }
        });


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        undoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ProgressDialog show2 = new ProgressDialog(CutOutActivity.this,R.style.AlertDialog);
                show2.setCancelable(false);
                show2.setMessage("Processing...");
                show2.show();
                new Thread(() -> {
                    try {
                        CutOutActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                CutOutActivity.this.drawingdv.undoChange();
                            }
                        });
                        Thread.sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    show2.dismiss();
                }).start();
            }
        });

        redoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ProgressDialog pshow = new ProgressDialog(CutOutActivity.this,R.style.AlertDialog);
                pshow.setCancelable(false);
                pshow.setMessage("Processing...");
                pshow.show();
                new Thread(() -> {
                    try {
                        CutOutActivity.this.runOnUiThread(new Runnable() {
                            public void run() {
                                CutOutActivity.this.drawingdv.redoChange();
                            }
                        });
                        Thread.sleep(500);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    pshow.dismiss();
                }).start();
            }
        });
    }

    View.OnClickListener radio_listener = new View.OnClickListener() {
        @SuppressLint("NewApi")
        public void onClick(View v) {
            if (CutOutActivity.this.drawingdv != null) {
                if (v == radio_auto) {
                    setSelected(R.id.radio_auto);
                    CutOutActivity.this.main_rel.setOnTouchListener(null);
                    CutOutActivity.this.drawingdv.enableTouchClear(true);
                    CutOutActivity.this.drawingdv.setMODE(DrawingView.TARGET);
                    CutOutActivity.this.drawingdv.invalidate();

                } else if (v == radio_erase) {
                    setSelected(R.id.radio_erase);
                    CutOutActivity.this.main_rel.setOnTouchListener(null);
                    CutOutActivity.this.drawingdv.enableTouchClear(true);
                    CutOutActivity.this.drawingdv.setMODE(DrawingView.ERASE);
                    CutOutActivity.this.drawingdv.invalidate();

                } else if (v == radio_restore) {
                    setSelected(R.id.radio_restore);
                    CutOutActivity.this.main_rel.setOnTouchListener(null);
                    CutOutActivity.this.drawingdv.enableTouchClear(true);
                    CutOutActivity.this.drawingdv.setMODE(DrawingView.REDRAW);
                    CutOutActivity.this.drawingdv.invalidate();

                } else if (v == radio_zoom) {
                    CutOutActivity.this.drawingdv.enableTouchClear(false);
                    CutOutActivity.this.main_rel.setOnTouchListener(multiTouchListener);
                    setSelected(R.id.radio_zoom);
                    CutOutActivity.this.drawingdv.setMODE(DrawingView.NONE);
                    CutOutActivity.this.drawingdv.invalidate();
                }
            }
        }
    };

    @Override
    public void onBackPressed() {
        setResult(RESULT_CANCELED);
        finish();
    }

    public void onDestroy() {
        if (this.mainbitmap != null) {
            this.mainbitmap.recycle();
            this.mainbitmap = null;
        }
        if (bitmap != null) {
            bitmap.recycle();
            bitmap = null;
        }
        super.onDestroy();
    }

    void exitWithError(Exception e) {
        Intent intent = new Intent();
        intent.putExtra(CutOut.CUTOUT_EXTRA_RESULT, e);
        setResult(CutOut.CUTOUT_ACTIVITY_RESULT_ERROR_CODE, intent);
        finish();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {


    }


    public void setSelected(int i) {
        if (i == R.id.radio_auto) {
            this.offset_seekbar.setProgress(this.drawingdv.getOffset() + 20);
            this.lay_offset_seek.setVisibility(View.GONE);
            this.lay_threshold_seek.setVisibility(View.VISIBLE);
        }
        if (i == R.id.radio_erase) {
            this.offset_seekbar1.setProgress(this.drawingdv.getOffset() + 20);
            this.lay_offset_seek.setVisibility(View.VISIBLE);
            this.lay_threshold_seek.setVisibility(View.GONE);
        }
        if (i == R.id.radio_restore) {
            this.offset_seekbar.setProgress(this.drawingdv.getOffset() + 20);
            this.lay_offset_seek.setVisibility(View.VISIBLE);
            this.lay_threshold_seek.setVisibility(View.GONE);
        }
        if (i == R.id.radio_zoom) {
            this.lay_offset_seek.setVisibility(View.GONE);
            this.lay_threshold_seek.setVisibility(View.GONE);
        }
        if (i == R.id.radio_restore) {
            this.dv1.setVisibility(View.VISIBLE);
        } else {
            this.dv1.setVisibility(View.GONE);
        }
        if (i != R.id.radio_zoom) {
            this.drawingdv.updateOnScale(this.main_rel.getScaleX());
        }
    }


    public void importImageFromUri(Uri uri) {
        selectedImageUri = uri;
        this.showDialog = false;

        final ProgressDialog pshow = new ProgressDialog(CutOutActivity.this,R.style.AlertDialog);
        pshow.setCancelable(false);
        pshow.setMessage("Image Processing...");
        pshow.show();
        new Thread(() -> {
            try {
                CutOutActivity.this.mainbitmap = ImageUtils.getResampleImageBitmap(CutOutActivity.selectedImageUri, CutOutActivity.this, CutOutActivity.this.width > CutOutActivity.this.height ? CutOutActivity.this.width : CutOutActivity.this.height);
               // Log.e("gettingwidthandheight","getActivity width and height ==> w : "+ width+" ,  h : "+ height +  "   ,,,,get bitmap width and height ==> w : "+ mainbitmap.getWidth()+" ,  h : "+ mainbitmap.getHeight() );
//                if (CutOutActivity.this.mainbitmap.getWidth() <= CutOutActivity.this.width) {
//                    if (CutOutActivity.this.mainbitmap.getHeight() <= CutOutActivity.this.height) {
//                        if (CutOutActivity.this.mainbitmap.getWidth() > CutOutActivity.this.width || CutOutActivity.this.mainbitmap.getHeight() > CutOutActivity.this.height || (CutOutActivity.this.mainbitmap.getWidth() < CutOutActivity.this.width && CutOutActivity.this.mainbitmap.getHeight() < CutOutActivity.this.height)) {
//                            CutOutActivity.this.mainbitmap = ImageUtils.resizeBitmap(CutOutActivity.this.mainbitmap, CutOutActivity.this.width, CutOutActivity.this.height);
//                        }
//                    }
//                }
               // CutOutActivity.this.mainbitmap = ImageUtils.resizeBitmap(CutOutActivity.this.mainbitmap, CutOutActivity.this.width, CutOutActivity.this.height);

                if (CutOutActivity.this.mainbitmap == null) {
                    CutOutActivity.this.showDialog = true;
                }
                Thread.sleep(1000);
            } catch (Exception | OutOfMemoryError e) {
                Log.e("getting_catch",e.getMessage()+"       :::   "+e.toString());
                e.printStackTrace();
                CutOutActivity.this.showDialog = true;
            }
            pshow.dismiss();
        }).start();

        pshow.setOnDismissListener(new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialogInterface) {
                if (CutOutActivity.this.showDialog) {
                    Toast.makeText(CutOutActivity.this, "import error", Toast.LENGTH_SHORT).show();
                    CutOutActivity.this.finish();
                    return;
                }
                CutOutActivity.this.setImageBitmap();
            }
        });
    }


    public void setImageBitmap() {
        this.drawingdv = new DrawingView(this);
        this.dv1 = new ImageView(this);
        this.drawingdv.setImageBitmap(this.mainbitmap);
        this.dv1.setImageBitmap(getGreenLayerBitmap(this.mainbitmap));
        this.drawingdv.enableTouchClear(false);
        this.drawingdv.setMODE(0);
        this.drawingdv.invalidate();
        this.offset_seekbar.setProgress(225);
        this.radius_seekbar.setProgress(18);
        this.threshold_seekbar.setProgress(20);
        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.main_rel_parent);
        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) relativeLayout.getLayoutParams();
        this.shaderView = new ShaderView(this);
        this.shaderView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        relativeLayout.addView(this.shaderView);
        this.drawingdv.setShaderView(this.shaderView);
        this.main_rel.removeAllViews();
        this.main_rel.setScaleX(1.0f);
        this.main_rel.setScaleY(1.0f);
        this.main_rel.addView(this.dv1);
        this.main_rel.addView(this.drawingdv);
        relativeLayout.setLayoutParams(layoutParams);
        this.drawingdv.invalidate();
        this.dv1.setVisibility(View.GONE);
        this.drawingdv.setUndoRedoListener(new DrawingView.UndoRedoListener() {
            public void enableUndo(boolean z, int i) {
                if (z) {
                    CutOutActivity.this.setBGDrawable(CutOutActivity.this.undoButton, R.drawable.ic_undo, z);
                    return;
                }
                CutOutActivity.this.setBGDrawable(CutOutActivity.this.undoButton, R.drawable.ic_undo_inactive, z);
            }

            public void enableRedo(boolean z, int i) {
                if (z) {
                    CutOutActivity.this.setBGDrawable(CutOutActivity.this.redoButton, R.drawable.ic_redo, z);
                    return;
                }
                CutOutActivity.this.setBGDrawable(CutOutActivity.this.redoButton, R.drawable.ic_redo_inactive, z);
            }
        });
        this.mainbitmap.recycle();

        this.drawingdv.setActionListener(new DrawingView.ActionListener() {
            public void onActionCompleted(final int i) {
            }

            public void onAction(final int i) {
                CutOutActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        if (i == 0) {
                            CutOutActivity.this.rel_seek_container.setVisibility(View.GONE);
                        }
                        if (i == 1) {
                            CutOutActivity.this.rel_seek_container.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }
        });

    }

    public void setBGDrawable(Button imageView, int i2, boolean z) {
        final Button imageView2 = imageView;
        final int i3 = i2;
        final boolean z2 = z;
        Runnable r0 = new Runnable() {
            public void run() {
                imageView2.setBackgroundResource(i3);
                imageView2.setEnabled(z2);
            }
        };
        runOnUiThread(r0);
    }


    public Bitmap getGreenLayerBitmap(Bitmap bitmap2) {
        Bitmap createBitmap = Bitmap.createBitmap(bitmap2.getWidth(), bitmap2.getHeight(), bitmap2.getConfig());
        Canvas canvas = new Canvas(createBitmap);
        canvas.drawColor(0);
        canvas.drawBitmap(bitmap2, 0.0f, 0.0f, null);
        patternBMPshader = new BitmapShader(createBitmap, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT);
        Bitmap createBitmap2 = Bitmap.createBitmap(bitmap2.getWidth(), bitmap2.getHeight(), bitmap2.getConfig());
        Canvas canvas2 = new Canvas(createBitmap2);
        Paint paint = new Paint();
        paint.setColor(-16711936);
        paint.setAlpha(80);
        canvas2.drawBitmap(bitmap2, 0.0f, 0.0f, null);
        canvas2.drawPaint(paint);
        return createBitmap2;
    }
}
