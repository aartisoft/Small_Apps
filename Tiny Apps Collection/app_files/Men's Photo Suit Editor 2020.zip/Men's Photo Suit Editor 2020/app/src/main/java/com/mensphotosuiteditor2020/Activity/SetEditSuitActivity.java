package com.mensphotosuiteditor2020.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.mensphotosuiteditor2020.Constant;
import com.mensphotosuiteditor2020.Eraser_Tools.CutOut;
import com.mensphotosuiteditor2020.R;
import com.mensphotosuiteditor2020.Editortools.SandboxView;
import com.mensphotosuiteditor2020.widgets.BackgroundviewAdapter;
import com.mensphotosuiteditor2020.widgets.FrameViewAdapter;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


public class SetEditSuitActivity extends AppCompatActivity implements FrameViewAdapter.FrameListener, BackgroundviewAdapter.BackgroundListener {


    public static final String TEMP_PHOTO_FILE_NAME = "temp_photo.jpg";
    Animation in, out;
    RelativeLayout rlmain, savelayout;
    ImageView image,image_background;
    SandboxView view;
    private RecyclerView mRvBackground, msuitView;
    File mFileTemp;
    RelativeLayout relative_edit;
    Constant constantfile;
    AlertDialog alert;
    private BackgroundviewAdapter mFilterViewAdapter = new BackgroundviewAdapter(this);
    private FrameViewAdapter mFrameViewAdapter = new FrameViewAdapter(this);
    RadioButton radio_erase, radio_background, radio_suits, radio_face, radio_flip;
    Button back,done;

    private boolean mIsFilterVisible = false;
    private boolean mIsFrameVisible = false;

    public static void copyStream(InputStream input, OutputStream output)
            throws IOException {

        byte[] buffer = new byte[1024];
        int bytesRead;
        while ((bytesRead = input.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
    }

    @SuppressLint("NewApi")
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editsuit_activity_background);

        constantfile = new Constant();


        try {
            relative_edit = (RelativeLayout) findViewById(R.id.relative_edit);
            savelayout = (RelativeLayout) findViewById(R.id.savelayout123);

            rlmain = (RelativeLayout) findViewById(R.id.rlchange3454);
            image = (ImageView) findViewById(R.id.image);
            image_background = (ImageView) findViewById(R.id.image_background);
            back = (Button) findViewById(R.id.back);
            done = (Button) findViewById(R.id.done);

            mRvBackground = (RecyclerView) findViewById(R.id.rvBackgroundView);

            LinearLayoutManager llmFilters = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
            mRvBackground.setLayoutManager(llmFilters);
            mRvBackground.setAdapter(mFilterViewAdapter);

            msuitView = (RecyclerView) findViewById(R.id.rvsuitView);
            LinearLayoutManager llmFrame = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
            msuitView.setLayoutManager(llmFrame);
            msuitView.setAdapter(mFrameViewAdapter);

            LoadFrame();
            LoadBackground();

            setimageinView();

            showBackground(false);
            showFrame(false);

            radio_face = (RadioButton) findViewById(R.id.radio_face);
            radio_suits = (RadioButton) findViewById(R.id.radio_suits);
            radio_background = (RadioButton) findViewById(R.id.radio_background);
            radio_erase = (RadioButton) findViewById(R.id.radio_erase);
            radio_flip = (RadioButton) findViewById(R.id.radio_flip);

            radio_face.setOnClickListener(radio_listener);
            radio_suits.setOnClickListener(radio_listener);
            radio_background.setOnClickListener(radio_listener);
            radio_erase.setOnClickListener(radio_listener);
            radio_flip.setOnClickListener(radio_listener);

            in = AnimationUtils.loadAnimation(this, R.anim.in);
            out = AnimationUtils.loadAnimation(this, R.anim.out);

        } catch (NullPointerException e) {

        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (ActivityNotFoundException e) {

        } catch (ClassCastException e) {

        } catch (NoClassDefFoundError e) {
            // TODO: handle exception
        } catch (Exception e) {
            // TODO: handle exception
        }
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            mFileTemp = new File(Environment.getExternalStorageDirectory(), TEMP_PHOTO_FILE_NAME);
        } else {
            mFileTemp = new File(getFilesDir(), TEMP_PHOTO_FILE_NAME);
        }

        back.setOnClickListener(v -> onBackPressed());

        done.setOnClickListener(v -> saveImage());

    }

    public void LoadFrame() {
        Glide.with(SetEditSuitActivity.this)
                .load(Uri.parse("file:///android_asset/image/" + Constant.arrayofimages.get(Constant.selectedframe)))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                        return false; // important to return false so the error placeholder can be placed
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
//                        if (beginning) {
//                            finalHeight = resource.getIntrinsicHeight();
//                        }
//                        savelayout.requestLayout();
//                        savelayout.getLayoutParams().height = finalHeight;
                        return false;
                    }
                }).into(image);


    }

    public void LoadBackground() {
        Glide.with(SetEditSuitActivity.this)
                .load(Uri.parse("file:///android_asset/background/" + Constant.arrayofbackground.get(Constant.selectedbackground)))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                        return false; // important to return false so the error placeholder can be placed
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        return false;
                    }
                }).into(image_background);


    }

    View.OnClickListener radio_listener = new View.OnClickListener() {
        @SuppressLint("NewApi")
        public void onClick(View v) {
            //perform your action here
            showBackground(false);
            showFrame(false);
            if (v == radio_face) {
                EditChangeFace();
            } else if (v == radio_suits) {
                showFrame(true);
            } else if (v == radio_background) {
                showBackground(true);
            } else if (v == radio_erase) {
                showEraseImage();
            } else if (v == radio_flip) {
                Matrix matrix = new Matrix();
                matrix.preScale(-1.0f, 1.0f);
                Constant.bmp = Bitmap.createBitmap(Constant.bmp, 0, 0, Constant.bmp.getWidth(), Constant.bmp.getHeight(), matrix, true);
                setimageinView();
            }
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    void showBackground(boolean isVisible) {
        if (isVisible) {
            mRvBackground.setVisibility(View.VISIBLE);
        } else {
            mRvBackground.setVisibility(View.GONE);
        }
        mIsFilterVisible = isVisible;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    void showEraseImage() {
        CutOut.activity()
                .src(Constant.bmpUri)
                .bordered()
                .noCrop()
                .start(this);
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    void showFrame(boolean isVisible) {
        if (isVisible) {
            msuitView.setVisibility(View.VISIBLE);
        } else {
            msuitView.setVisibility(View.GONE);
        }
        mIsFrameVisible = isVisible;
    }


    public void setimageinView(){
        rlmain.removeAllViews();
        view = new SandboxView(SetEditSuitActivity.this, Constant.bmp);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(view.getWidth(), view.getHeight());
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        rlmain.addView(view);
    }



    @SuppressLint("NewApi")
    private void saveImage() {
        if (mIsFilterVisible || mIsFrameVisible) {
            showBackground(false);
            showFrame(false);
        }
        savelayout.setDrawingCacheEnabled(true);
        savelayout.buildDrawingCache(true);
        Constant.getSuitimage = null;
        Constant.getSuitimage = Bitmap.createBitmap(savelayout.getDrawingCache(true));
        if (Constant.getSuitimage != null) {
            savelayout.setDrawingCacheEnabled(false);
            deleteFileFromMediaStore(getContentResolver(), new File(String.valueOf(Constant.bmpUri)));
            Intent intent = new Intent(SetEditSuitActivity.this, EditActivity.class);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        } else {
            savelayout.setDrawingCacheEnabled(false);
            constantfile.snackbarcommonview(SetEditSuitActivity.this, relative_edit, "Please Try Again!");
        }

    }


    @SuppressLint("NewApi")
    @Override
    public void onBackPressed() {
        if (mIsFilterVisible || mIsFrameVisible) {
            showBackground(false);
            showFrame(false);
        } else {
            EditExit();
        }
    }

    public void EditExit() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this,R.style.AlertDialog);
        alertDialogBuilder.setMessage(getResources().getString(R.string.exit_editimage_title));
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        alert.dismiss();
                        Intent intent = new Intent(SetEditSuitActivity.this, MainActivity.class);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });
        alert = alertDialogBuilder.create();
        alert.show();

    }

    public void EditChangeFace() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this,R.style.AlertDialog);
        alertDialogBuilder.setMessage(getResources().getString(R.string.change_faceimage_title));
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        alert.dismiss();
                        Intent intent = new Intent(SetEditSuitActivity.this, MainActivity.class);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });
        alert = alertDialogBuilder.create();
        alert.show();

    }

    @Override
    public void onFrameSelected(int position) {
        Constant.selectedframe = position;
        LoadFrame();
    }

    @Override
    public void onBackgroundSelected(int position) {
        Constant.selectedbackground = position;
        LoadBackground();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CutOut.CUTOUT_ACTIVITY_REQUEST_CODE) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    onCropandRotateResult(data);
                    break;
                case CutOut.CUTOUT_ACTIVITY_RESULT_ERROR_CODE:
                    Exception ex = CutOut.getError(data);
                    break;
                default:
                    System.out.print("User cancelled the CutOut screen");
            }
        }

    }


    @SuppressWarnings("deprecation")
    private void onCropandRotateResult(Intent data) {

        try {
            Constant.bmpUri = CutOut.getUri(data);
            try {
                if (Constant.bmpUri != null) {
                    Constant.bmp = MediaStore.Images.Media.getBitmap(getContentResolver(), Constant.bmpUri);
                    setimageinView();
                }
            } catch (Exception e) {
                //handle exception
            }
        } catch (ArrayIndexOutOfBoundsException e) {

        } catch (IndexOutOfBoundsException e) {
        } catch (OutOfMemoryError e) {
        } catch (NullPointerException e) {
        } catch (NumberFormatException e) {
        } catch (Exception e) {
        }
    }



    public static int deleteFileFromMediaStore(final ContentResolver contentResolver, final File file) {
        String canonicalPath;
        try {
            canonicalPath = file.getCanonicalPath();
        } catch (IOException e) {
            canonicalPath = file.getAbsolutePath();
        }
        final Uri uri = MediaStore.Files.getContentUri("external");
        final int result = contentResolver.delete(uri, MediaStore.Files.FileColumns.DATA + "=?", new String[]{canonicalPath});
        if (result == 0) {
            final String absolutePath = file.getAbsolutePath();
            if (!absolutePath.equals(canonicalPath)) {
                int deletedRow = contentResolver.delete(uri, MediaStore.Files.FileColumns.DATA + "=?", new String[]{absolutePath});
                Log.e("file_deleting","done 1");
                return deletedRow;
            }
        } else {
            Log.e("file_deleting","done 2");
            return result;
        }
        Log.e("file_deleting","done 3");
        return result;
    }
}
