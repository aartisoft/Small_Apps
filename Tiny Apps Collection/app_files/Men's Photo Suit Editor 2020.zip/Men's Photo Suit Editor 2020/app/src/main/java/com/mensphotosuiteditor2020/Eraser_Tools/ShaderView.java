package com.mensphotosuiteditor2020.Eraser_Tools;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.util.AttributeSet;
import android.util.DisplayMetrics;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.internal.view.SupportMenu;

import com.mensphotosuiteditor2020.R;


public class ShaderView extends AppCompatImageView {
    private Paint bPaint = null;
    private Bitmap bit2;
    int bitmappx;
    private int brushSize;
    int canvaspx;
    private Context context;
    private boolean isRectEnable = false;
    private boolean needToDraw = false;
    private boolean onLeft = false;

    /* renamed from: p */
    Paint f150p = new Paint();
    private int screenWidth;
    private Paint shaderPaint = null;

    public ShaderView(Context context2) {
        super(context2);
        initVariables(context2);
    }

    public ShaderView(Context context2, @Nullable AttributeSet attributeSet) {
        super(context2, attributeSet);
        initVariables(context2);
    }

    public ShaderView(Context context2, @Nullable AttributeSet attributeSet, int i) {
        super(context2, attributeSet, i);
        initVariables(context2);
    }

    public void initVariables(Context context2) {
        this.context = context2;
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context2).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.screenWidth = displayMetrics.widthPixels;
        this.bitmappx = ImageUtils.dpToPx(context2, 20);
        this.canvaspx = ImageUtils.dpToPx(context2, 75);
        this.f150p.setColor(SupportMenu.CATEGORY_MASK);
        this.f150p.setStrokeWidth((float) (((double) ImageUtils.dpToPx(getContext(), 1)) * 1.5d));
        this.bPaint = new Paint();
        this.bPaint.setAntiAlias(true);
        this.bPaint.setColor(SupportMenu.CATEGORY_MASK);
        this.bPaint.setAntiAlias(true);
        this.bPaint.setStyle(Style.STROKE);
        this.bPaint.setStrokeJoin(Join.MITER);
        this.bPaint.setStrokeWidth((float) (((double) ImageUtils.dpToPx(getContext(), 2)) * 1.5d));
        this.bit2 = BitmapFactory.decodeResource(context2.getResources(), R.drawable.circle1);
        this.bit2 = Bitmap.createScaledBitmap(this.bit2, this.bitmappx, this.bitmappx, true);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.needToDraw && this.shaderPaint != null) {
            if (this.onLeft) {
                canvas.drawBitmap(CutOutActivity.bgCircleBit, 0.0f, 0.0f, null);
                canvas.drawCircle((float) this.canvaspx, (float) this.canvaspx, (float) this.canvaspx, this.shaderPaint);
                if (DrawingView.MODE == 2 || DrawingView.MODE == 3) {
                    canvas.drawCircle((float) this.canvaspx, (float) this.canvaspx, (float) this.brushSize, this.bPaint);
                    Canvas canvas2 = canvas;
                    canvas2.drawLine((float) (this.canvaspx - this.brushSize), (float) this.canvaspx, (float) (this.canvaspx + this.brushSize), (float) this.canvaspx, this.f150p);
                    canvas2.drawLine((float) this.canvaspx, (float) (this.canvaspx - this.brushSize), (float) this.canvaspx, (float) (this.canvaspx + this.brushSize), this.f150p);
                } else if (this.isRectEnable) {
                    canvas.drawRect((float) (this.canvaspx - this.brushSize), (float) (this.canvaspx - this.brushSize), (float) (this.canvaspx + this.brushSize), (float) (this.canvaspx + this.brushSize), this.bPaint);
                } else {
                    canvas.drawCircle((float) this.canvaspx, (float) this.canvaspx, (float) this.brushSize, this.bPaint);
                }
                canvas.drawBitmap(this.bit2, 0.0f, 0.0f, null);
                return;
            }
            canvas.drawBitmap(CutOutActivity.bgCircleBit, (float) (this.screenWidth - this.bitmappx), 0.0f, null);
            canvas.drawCircle((float) (this.screenWidth - this.canvaspx), (float) this.canvaspx, (float) this.canvaspx, this.shaderPaint);
            if (DrawingView.MODE == 2 || DrawingView.MODE == 3) {
                canvas.drawCircle((float) (this.screenWidth - this.canvaspx), (float) this.canvaspx, (float) this.brushSize, this.bPaint);
                Canvas canvas3 = canvas;
                canvas3.drawLine((float) ((this.screenWidth - this.canvaspx) - this.brushSize), (float) this.canvaspx, (float) ((this.screenWidth - this.canvaspx) + this.brushSize), (float) this.canvaspx, this.f150p);
                canvas3.drawLine((float) (this.screenWidth - this.canvaspx), (float) (this.canvaspx - this.brushSize), (float) (this.screenWidth - this.canvaspx), (float) (this.canvaspx + this.brushSize), this.f150p);
            } else if (this.isRectEnable) {
                canvas.drawRect((float) ((this.screenWidth - this.canvaspx) - this.brushSize), (float) (this.canvaspx - this.brushSize), (float) ((this.screenWidth - this.canvaspx) + this.brushSize), (float) (this.canvaspx + this.brushSize), this.bPaint);
            } else {
                canvas.drawCircle((float) (this.screenWidth - this.canvaspx), (float) this.canvaspx, (float) this.brushSize, this.bPaint);
            }
            canvas.drawBitmap(this.bit2, (float) (this.screenWidth - this.bitmappx), 0.0f, null);
        }
    }

    public void updateShaderView(Paint paint, int i, boolean z, boolean z2, boolean z3) {
        this.needToDraw = z;
        this.onLeft = z2;
        this.isRectEnable = z3;
        this.shaderPaint = paint;
        this.brushSize = i;
        invalidate();
    }
}
