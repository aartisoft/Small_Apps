package com.mensphotosuiteditor2020.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}