package com.traditionalmenphotosuit.Cropimage;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Region;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.traditionalmenphotosuit.PrefManager;
import com.traditionalmenphotosuit.R;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.CountDownLatch;

import static com.traditionalmenphotosuit.Constant.SHARED_CROPHINT_SET;


public class CropImage extends MonitoredActivity {

    public static final String ORIENTATION_IN_DEGREES = "orientation_in_degrees";
    public static final String RETURN_DATA = "return-data";

    public static final int NO_STORAGE_ERROR = -1;
    public static final int CANNOT_STAT_ERROR = -2;
    private static final String TAG = "CropImage";
    final int IMAGE_MAX_SIZE = 1024;
    private final Handler mHandler = new Handler();
    private final BitmapManager.ThreadSet mDecodingThreads = new BitmapManager.ThreadSet();
    private Bitmap.CompressFormat mOutputFormat = Bitmap.CompressFormat.PNG;
    private Uri mSaveUri = null;

    private ContentResolver mContentResolver;
    private Bitmap mBitmap;
    private SomeView mSomeView;
    LinearLayout layout;
    RelativeLayout crop_relative;
    LinearLayout.LayoutParams lp;
    private PrefManager prf;
    RelativeLayout firstTime_hint;
    private String mImagePath;
    int maxWidth,maxHeight;

    public static void showStorageToast(Activity activity) {

        showStorageToast(activity, calculatePicturesRemaining(activity));
    }

    public static void showStorageToast(Activity activity, int remaining) {

        String noStorageText = null;

        if (remaining == NO_STORAGE_ERROR) {

            String state = Environment.getExternalStorageState();
            if (state.equals(Environment.MEDIA_CHECKING)) {

                noStorageText = activity.getString(R.string.preparing_card);
            } else {

                noStorageText = activity.getString(R.string.no_storage_card);
            }
        } else if (remaining < 1) {

            noStorageText = activity.getString(R.string.not_enough_space);
        }

        if (noStorageText != null) {

            Toast.makeText(activity, noStorageText, Toast.LENGTH_SHORT).show();
        }
    }

    public static int calculatePicturesRemaining(Activity activity) {

        try {
            /*
             * if (!ImageManager.hasStorage()) { return NO_STORAGE_ERROR; } else
             * {
             */
            String storageDirectory = "";
            String state = Environment.getExternalStorageState();
            if (Environment.MEDIA_MOUNTED.equals(state)) {
                storageDirectory = Environment.getExternalStorageDirectory().toString();
            } else {
                storageDirectory = activity.getFilesDir().toString();
            }
            StatFs stat = new StatFs(storageDirectory);
            float remaining = ((float) stat.getAvailableBlocks() * (float) stat.getBlockSize()) / 400000F;
            return (int) remaining;
            // }
        } catch (Exception ex) {
            // if we can't stat the filesystem then we don't know how many
            // pictures are remaining. it might be zero but just leave it
            // blank since we really don't know.
            return CANNOT_STAT_ERROR;
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void onCreate(Bundle icicle) {

        super.onCreate(icicle);
        mContentResolver = getContentResolver();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.cropimage);
        prf = new PrefManager(getApplicationContext());

        TypedValue tv = new TypedValue();
        int actionBarHeight = 100;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true))
        {
            int Height = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
            actionBarHeight = Height*2;
        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        maxHeight = displayMetrics.heightPixels-actionBarHeight;
        maxWidth = displayMetrics.widthPixels;
        showStorageToast(this);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) {

            mImagePath = extras.getString("image-path");

            mSaveUri = getImageUri(mImagePath);
            mBitmap = getBitmap(mImagePath);

            mSomeView = new SomeView(this, mBitmap);
            layout = findViewById(R.id.layout);
            crop_relative = findViewById(R.id.crop_relative);
            lp = new LinearLayout.LayoutParams(mBitmap.getWidth(), mBitmap.getHeight());
            lp.gravity = Gravity.CENTER;
            layout.addView(mSomeView, lp);


            firstTime_hint = findViewById(R.id.firstTime_hint);
            firstTime_hint.setVisibility(View.GONE);

            if (prf.getBoolean(SHARED_CROPHINT_SET)) {
                firstTime_hint.setVisibility(View.VISIBLE);
                firstTime_hint.setOnClickListener(v -> {
                    prf.setBoolean(SHARED_CROPHINT_SET, false);
                    firstTime_hint.setVisibility(View.GONE);
                });
            }

        }

        if (mBitmap == null) {

            Log.d(TAG, "finish!!!");
            finish();
            return;
        }

        // Make UI fullscreen.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        findViewById(R.id.backcrop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED);
                finish();
            }
        });

        findViewById(R.id.save_done).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                try {
                    cropImage();
                    //onSaveClicked();
                } catch (Exception e) {
                    finish();
                }
            }
        });
        findViewById(R.id.restore).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        mSomeView.resetView();
                    }
                });
        findViewById(R.id.rotate).setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        //mSomeView.resetView();

                        if (layout != null) {
                            mBitmap = Util.rotateImage(mBitmap, -90);
                            mSomeView = new SomeView(CropImage.this, mBitmap);
                            layout.removeAllViews();
                            lp = new LinearLayout.LayoutParams(mBitmap.getWidth(), mBitmap.getHeight());
                            lp.gravity = Gravity.CENTER;
                            layout.addView(mSomeView, lp);
                        }
                    }
                });


        startFaceDetection();
    }


    private Uri getImageUri(String path) {

        return Uri.fromFile(new File(path));
    }

    private Bitmap getBitmap(String path) {

        Uri uri = getImageUri(path);
        InputStream in = null;
        try {
            in = mContentResolver.openInputStream(uri);

            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;

            BitmapFactory.decodeStream(in, null, o);
            in.close();

//            int width_tmp = o.outWidth, height_tmp = o.outHeight;
//            int scale = 1;
//            while (true) {
//                Log.e("scalevalue", "  ::  " + scale +"  ::  "+width_tmp+"  ::  " +height_tmp);
//                if (width_tmp / 2 < IMAGE_MAX_SIZE || height_tmp / 2 < IMAGE_MAX_SIZE)
//                    break;
//                width_tmp /= 2;
//                height_tmp /= 2;
//                scale++;
//
//            }

//            int scale = 1;
//            if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
//                scale = (int) Math.pow(
//                        2,
//                        (int) Math.round(Math.log(IMAGE_MAX_SIZE
//                                / (double) Math.max(o.outHeight, o.outWidth))
//                                / Math.log(0.5)));
//            }
//
            BitmapFactory.Options o2 = new BitmapFactory.Options();
               // o2.inSampleSize = scale;
//
            in = mContentResolver.openInputStream(uri);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            in.close();

            return scaleBitmap(b);
        } catch (FileNotFoundException e) {
            Log.e(TAG, "file " + path + " not found");
        } catch (IOException e) {
            Log.e(TAG, "file " + path + " not found");
        }
        return null;
    }

    private Bitmap scaleBitmap(Bitmap bm) {
        int width = bm.getWidth();
        int height = bm.getHeight();

        if (width > height) {
            // landscape
            float ratio = (float) width / maxWidth;
            width = maxWidth;
            height = (int)(height / ratio);
        } else if (height > width) {
            // portrait
            float ratio = (float) height / maxHeight;
            height = maxHeight;
            width = (int)(width / ratio);
        } else if (width == height){
            width = maxWidth;
            height = maxWidth;
        } else {
            // square
            height = maxHeight;
            width = maxWidth;
        }

        bm = Bitmap.createScaledBitmap(bm, width, height, true);
        return bm;
    }

    private void startFaceDetection() {

        if (isFinishing()) {
            return;
        }

        Util.startBackgroundJob(this, null, "Please wait\u2026",
                new Runnable() {
                    public void run() {

                        final CountDownLatch latch = new CountDownLatch(1);
                        final Bitmap b = mBitmap;
                        mHandler.post(new Runnable() {
                            public void run() {

                                if (b != mBitmap && b != null) {
                                    // mImageView.setImageBitmapResetBase(b, true);
                                    mBitmap.recycle();
                                    mBitmap = b;
                                }
//                                if (mImageView.getScale() == 1F) {
//                                    mImageView.center(true, true);
//                                }
                                latch.countDown();
                            }
                        });
                        try {
                            latch.await();
                        } catch (InterruptedException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, mHandler);
    }


    private void saveOutput(Bitmap croppedImage) {

        if (mSaveUri != null) {
            OutputStream outputStream = null;
            try {
                outputStream = mContentResolver.openOutputStream(mSaveUri);
                if (outputStream != null) {
                    croppedImage.compress(mOutputFormat, 100, outputStream);

                }
            } catch (IOException ex) {
                Log.e(TAG, "Cannot open file: " + mSaveUri, ex);
                setResult(RESULT_CANCELED);
                finish();
                return;
            } finally {

                Util.closeSilently(outputStream);
            }

            Bundle extras = new Bundle();
            Intent intent = new Intent(mSaveUri.toString());
            intent.putExtras(extras);
            intent.putExtra("image-path", mImagePath);
            intent.putExtra(ORIENTATION_IN_DEGREES, Util.getOrientationInDegree(this));
            setResult(RESULT_OK, intent);
        } else {

            Log.e(TAG, "not defined image url");
        }
        croppedImage.recycle();
        finish();
    }

    @Override
    protected void onPause() {

        super.onPause();
        BitmapManager.instance().cancelThreadDecoding(mDecodingThreads);
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (mBitmap != null) {

            mBitmap.recycle();
        }
    }


    public void cropImage() {

        Bitmap fullScreenBitmap = Bitmap.createBitmap(mSomeView.getWidth(), mSomeView.getHeight(), mBitmap.getConfig());

        Canvas canvas = new Canvas(fullScreenBitmap);
        canvas.drawColor(Color.TRANSPARENT);

        Path path = new Path();
        List<Point> points = mSomeView.getPoints();
        for (int i = 0; i < points.size(); i++) {
            path.lineTo(points.get(i).x, points.get(i).y);
        }

        // Cut out the selected portion of the image...
        Paint paint = new Paint();
        canvas.drawPath(path, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(mBitmap, 0, 0, paint);

        // Frame the cut out portion...
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(0f);
        canvas.drawPath(path, paint);

        Region region = new Region();
        Region clip = new Region(0, 0, fullScreenBitmap.getWidth(), fullScreenBitmap.getHeight());
        region.setPath(path, clip);
        Rect bounds = region.getBounds();
        Bitmap croppedBitmap = Bitmap.createBitmap(fullScreenBitmap, bounds.left, bounds.top, bounds.width(), bounds.height());
        //ImageView imageView = findViewById(R.id.image);
        saveOutput(croppedBitmap);
        //imageView.setImageBitmap(croppedBitmap);
    }

}
