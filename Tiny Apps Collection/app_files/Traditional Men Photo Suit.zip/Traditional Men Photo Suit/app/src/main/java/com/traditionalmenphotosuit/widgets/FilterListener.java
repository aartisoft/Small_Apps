package com.traditionalmenphotosuit.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}