package com.commandophotoeditor.suit2020.widgets;



public enum ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
