package com.commandophotoeditor.suit2020.Eraser_Tools;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.graphics.Point;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader.TileMode;
import android.os.AsyncTask;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.internal.view.SupportMenu;
import androidx.recyclerview.widget.ItemTouchHelper;

import com.commandophotoeditor.suit2020.R;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

public class DrawingView extends AppCompatImageView implements OnTouchListener {
    private static final int INVALID_POINTER_ID = -1;
    public static int MODE = 1;

    /* renamed from: pc */
    private static int f113pc = 0;
    public static float scale = 1.0f;
    Bitmap Bitmap2 = null;
    Bitmap Bitmap3 = null;
    Bitmap Bitmap4 = null;
    public static int ERASE = 1;
    private  int LASSO = 3;
    public static int NONE = 0;
    public static int REDRAW = 4;
    /* access modifiers changed from: private */
    public static int TARGET = 2;
    /* access modifiers changed from: private */
    public int TOLERANCE = 30;

    /* renamed from: X */
    float f114X = 100.0f;

    /* renamed from: Y */
    float f115Y = 100.0f;
    /* access modifiers changed from: private */
    public ActionListener actionListener;
    /* access modifiers changed from: private */
    public ArrayList<Integer> brushIndx = new ArrayList<>();
    /* access modifiers changed from: private */
    public int brushSize = 18;
    private int brushSize1 = 18;
    /* access modifiers changed from: private */
    public ArrayList<Boolean> brushTypeIndx = new ArrayList<>();

    /* renamed from: c2 */
    Canvas f116c2;
    /* access modifiers changed from: private */
    public ArrayList<Path> changesIndx = new ArrayList<>();
    Context ctx;
    /* access modifiers changed from: private */
    public int curIndx = -1;
    private boolean drawLasso = false;
    private boolean drawOnLasso = true;
    Path drawPath = new Path();
    Paint erPaint = new Paint();
    Paint erPaint1 = new Paint();
    int erps = ImageUtils.dpToPx(getContext(), 2);
    int height;
    /* access modifiers changed from: private */
    public boolean insidCutEnable = true;
    /* access modifiers changed from: private */
    public boolean isAutoRunning = false;
    boolean isMoved = false;
    private boolean isNewPath = false;
    /* access modifiers changed from: private */
    public boolean isRectBrushEnable = false;
    public boolean isRotateEnabled = true;
    public boolean isScaleEnabled = true;
    private boolean isSelected = true;
    private boolean isTouched = false;
    public boolean isTranslateEnabled = true;
    Path lPath = new Path();
    /* access modifiers changed from: private */
    public ArrayList<Boolean> lassoIndx = new ArrayList<>();
    private ScaleGestureDetector mScaleGestureDetector;
    public float maximumScale = 8.0f;
    public float minimumScale = 0.5f;
    /* access modifiers changed from: private */
    public ArrayList<Integer> modeIndx = new ArrayList<>();
    private int offset = ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION;
    private int offset1 = ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION;
    private boolean onLeft = true;
    Paint onePxPaint = new Paint();
    Path onePxPath = new Path();
    private Bitmap orgBit;

    /* renamed from: p */
    Paint f117p = new Paint();
    Paint paint = new Paint();
    BitmapShader patternBMPshader;

    /* renamed from: pd */
    public ProgressDialog f118pd = null;
    public Point point;

    /* renamed from: sX */
    float f119sX;

    /* renamed from: sY */
    float f120sY;
    private int screenWidth;
    private ShaderView shaderView = null;
    Path tPath = new Path();
    private int targetBrushSize = 18;
    private int targetBrushSize1 = 18;
    /* access modifiers changed from: private */
    public UndoRedoListener undoRedoListener;
    /* access modifiers changed from: private */
    public boolean updateOnly = false;
    /* access modifiers changed from: private */
    public ArrayList<Vector<Point>> vectorPoints = new ArrayList<>();
    int width;

    public interface ActionListener {
        void onAction(int i);

        void onActionCompleted(int i);
    }

    private class AsyncTaskRunner extends AsyncTask<Void, Void, Bitmap> {

        /* renamed from: ch */
        int f121ch;
        Vector<Point> targetPoints;

        public AsyncTaskRunner(int i) {
            this.f121ch = i;
        }

        /* access modifiers changed from: protected */
        public Bitmap doInBackground(Void... voidArr) {
            if (this.f121ch == 0) {
                return null;
            }
            this.targetPoints = new Vector<>();
            DrawingView.this.Bitmap3 = DrawingView.this.Bitmap2.copy(DrawingView.this.Bitmap2.getConfig(), true);
            FloodFill(DrawingView.this.Bitmap2, new Point(DrawingView.this.point.x, DrawingView.this.point.y), this.f121ch, 0);
            DrawingView.this.changesIndx.add(DrawingView.this.curIndx + 1, new Path());
            DrawingView.this.brushIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.brushSize));
            DrawingView.this.modeIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.TARGET));
            DrawingView.this.brushTypeIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.isRectBrushEnable));
            DrawingView.this.vectorPoints.add(DrawingView.this.curIndx + 1, new Vector(this.targetPoints));
            DrawingView.this.lassoIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.insidCutEnable));
            DrawingView.this.curIndx = DrawingView.this.curIndx + 1;
            clearNextChanges();
            DrawingView.this.updateOnly = true;
            StringBuilder sb = new StringBuilder();
            sb.append("Time : ");
            sb.append(this.f121ch);
            sb.append("  ");
            sb.append(DrawingView.this.curIndx);
            sb.append("   ");
            sb.append(DrawingView.this.changesIndx.size());
            Log.i("testing", sb.toString());
            return null;
        }

        private void FloodFill(Bitmap bitmap, Point point, int i, int i2) {
            if (i != 0) {
                int[] iArr = new int[(DrawingView.this.width * DrawingView.this.height)];
                bitmap.getPixels(iArr, 0, DrawingView.this.width, 0, 0, DrawingView.this.width, DrawingView.this.height);
                LinkedList linkedList = new LinkedList();
                linkedList.add(point);
                while (linkedList.size() > 0) {
                    Point point2 = (Point) linkedList.poll();
                    if (compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)], i)) {
                        Point point3 = new Point(point2.x + 1, point2.y);
                        while (point2.x > 0 && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)], i)) {
                            iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                            if (point2.y > 0 && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y - 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y - 1));
                            }
                            if (point2.y < DrawingView.this.height && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y + 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y + 1));
                            }
                            point2.x--;
                        }
                        if (point2.y > 0 && point2.y < DrawingView.this.height) {
                            iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                        }
                        while (point3.x < DrawingView.this.width && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)], i)) {
                            iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                            if (point3.y > 0 && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y - 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y - 1));
                            }
                            if (point3.y < DrawingView.this.height && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y + 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y + 1));
                            }
                            point3.x++;
                        }
                        if (point3.y > 0 && point3.y < DrawingView.this.height) {
                            iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                        }
                    }
                }
                bitmap.setPixels(iArr, 0, DrawingView.this.width, 0, 0, DrawingView.this.width, DrawingView.this.height);
            }
        }

        public boolean compareColor(int i, int i2) {
            if (i == 0 || i2 == 0) {
                return false;
            }
            if (i == i2) {
                return true;
            }
            return Math.abs(Color.red(i) - Color.red(i2)) <= DrawingView.this.TOLERANCE && Math.abs(Color.green(i) - Color.green(i2)) <= DrawingView.this.TOLERANCE && Math.abs(Color.blue(i) - Color.blue(i2)) <= DrawingView.this.TOLERANCE;
        }

        private void clearNextChanges() {
            int size = DrawingView.this.changesIndx.size();
            StringBuilder sb = new StringBuilder();
            sb.append(" Curindx ");
            sb.append(DrawingView.this.curIndx);
            sb.append(" Size ");
            sb.append(size);
            Log.i("testings", sb.toString());
            int access$300 = DrawingView.this.curIndx + 1;
            while (size > access$300) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(" indx ");
                sb2.append(access$300);
                Log.i("testings", sb2.toString());
                DrawingView.this.changesIndx.remove(access$300);
                DrawingView.this.brushIndx.remove(access$300);
                DrawingView.this.modeIndx.remove(access$300);
                DrawingView.this.brushTypeIndx.remove(access$300);
                DrawingView.this.vectorPoints.remove(access$300);
                DrawingView.this.lassoIndx.remove(access$300);
                size = DrawingView.this.changesIndx.size();
            }
            if (DrawingView.this.undoRedoListener != null) {
                DrawingView.this.undoRedoListener.enableUndo(true, DrawingView.this.curIndx + 1);
                DrawingView.this.undoRedoListener.enableRedo(false, DrawingView.this.modeIndx.size() - (DrawingView.this.curIndx + 1));
            }
            if (DrawingView.this.actionListener != null) {
                DrawingView.this.actionListener.onActionCompleted(DrawingView.MODE);
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            DrawingView.this.f118pd = new ProgressDialog(DrawingView.this.getContext());
            ProgressDialog progressDialog = DrawingView.this.f118pd;
            StringBuilder sb = new StringBuilder();
            sb.append(DrawingView.this.ctx.getResources().getString(R.string.processing));
            sb.append("...");
            progressDialog.setMessage(sb.toString());
            DrawingView.this.f118pd.setCancelable(false);
            DrawingView.this.f118pd.show();
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Bitmap bitmap) {
            DrawingView.this.f118pd.dismiss();
            DrawingView.this.f118pd = null;
            DrawingView.this.invalidate();
            DrawingView.this.isAutoRunning = false;
        }
    }

    private class AsyncTaskRunner1 extends AsyncTask<Void, Void, Bitmap> {

        /* renamed from: ch */
        int f122ch;
        Vector<Point> targetPoints;

        public AsyncTaskRunner1(int i) {
            this.f122ch = i;
        }

        /* access modifiers changed from: protected */
        public Bitmap doInBackground(Void... voidArr) {
            if (this.f122ch == 0) {
                return null;
            }
            this.targetPoints = new Vector<>();
            FloodFill(new Point(DrawingView.this.point.x, DrawingView.this.point.y), this.f122ch, 0);
            if (DrawingView.this.curIndx < 0) {
                DrawingView.this.changesIndx.add(DrawingView.this.curIndx + 1, new Path());
                DrawingView.this.brushIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.brushSize));
                DrawingView.this.modeIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.TARGET));
                DrawingView.this.brushTypeIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.isRectBrushEnable));
                DrawingView.this.vectorPoints.add(DrawingView.this.curIndx + 1, new Vector(this.targetPoints));
                DrawingView.this.lassoIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.insidCutEnable));
                DrawingView.this.curIndx = DrawingView.this.curIndx + 1;
                clearNextChanges();
            } else if (((Integer) DrawingView.this.modeIndx.get(DrawingView.this.curIndx)).intValue() == DrawingView.this.TARGET && DrawingView.this.curIndx == DrawingView.this.modeIndx.size() - 1) {
                DrawingView.this.vectorPoints.add(DrawingView.this.curIndx, new Vector(this.targetPoints));
            } else {
                DrawingView.this.changesIndx.add(DrawingView.this.curIndx + 1, new Path());
                DrawingView.this.brushIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.brushSize));
                DrawingView.this.modeIndx.add(DrawingView.this.curIndx + 1, Integer.valueOf(DrawingView.this.TARGET));
                DrawingView.this.brushTypeIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.isRectBrushEnable));
                DrawingView.this.vectorPoints.add(DrawingView.this.curIndx + 1, new Vector(this.targetPoints));
                DrawingView.this.lassoIndx.add(DrawingView.this.curIndx + 1, Boolean.valueOf(DrawingView.this.insidCutEnable));
                DrawingView.this.curIndx = DrawingView.this.curIndx + 1;
                clearNextChanges();
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Time : ");
            sb.append(this.f122ch);
            sb.append("  ");
            sb.append(DrawingView.this.curIndx);
            sb.append("   ");
            sb.append(DrawingView.this.changesIndx.size());
            Log.i("testing", sb.toString());
            return null;
        }

        private void FloodFill(Point point, int i, int i2) {
            if (i != 0) {
                int[] iArr = new int[(DrawingView.this.width * DrawingView.this.height)];
                DrawingView.this.Bitmap3.getPixels(iArr, 0, DrawingView.this.width, 0, 0, DrawingView.this.width, DrawingView.this.height);
                LinkedList linkedList = new LinkedList();
                linkedList.add(point);
                while (linkedList.size() > 0) {
                    Point point2 = (Point) linkedList.poll();
                    if (compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)], i)) {
                        Point point3 = new Point(point2.x + 1, point2.y);
                        while (point2.x > 0 && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)], i)) {
                            iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                            if (point2.y > 0 && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y - 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y - 1));
                            }
                            if (point2.y < DrawingView.this.height && compareColor(iArr[DrawingView.this.getIndex(point2.x, point2.y + 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point2.x, point2.y + 1));
                            }
                            point2.x--;
                        }
                        if (point2.y > 0 && point2.y < DrawingView.this.height) {
                            iArr[DrawingView.this.getIndex(point2.x, point2.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point2.x, point2.y));
                        }
                        while (point3.x < DrawingView.this.width && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)], i)) {
                            iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                            if (point3.y > 0 && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y - 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y - 1));
                            }
                            if (point3.y < DrawingView.this.height && compareColor(iArr[DrawingView.this.getIndex(point3.x, point3.y + 1, DrawingView.this.width)], i)) {
                                linkedList.add(new Point(point3.x, point3.y + 1));
                            }
                            point3.x++;
                        }
                        if (point3.y > 0 && point3.y < DrawingView.this.height) {
                            iArr[DrawingView.this.getIndex(point3.x, point3.y, DrawingView.this.width)] = i2;
                            this.targetPoints.add(new Point(point3.x, point3.y));
                        }
                    }
                }
                DrawingView.this.Bitmap2.setPixels(iArr, 0, DrawingView.this.width, 0, 0, DrawingView.this.width, DrawingView.this.height);
            }
        }

        public boolean compareColor(int i, int i2) {
            if (i == 0 || i2 == 0) {
                return false;
            }
            if (i == i2) {
                return true;
            }
            return Math.abs(Color.red(i) - Color.red(i2)) <= DrawingView.this.TOLERANCE && Math.abs(Color.green(i) - Color.green(i2)) <= DrawingView.this.TOLERANCE && Math.abs(Color.blue(i) - Color.blue(i2)) <= DrawingView.this.TOLERANCE;
        }

        private void clearNextChanges() {
            int size = DrawingView.this.changesIndx.size();
            StringBuilder sb = new StringBuilder();
            sb.append(" Curindx ");
            sb.append(DrawingView.this.curIndx);
            sb.append(" Size ");
            sb.append(size);
            Log.i("testings", sb.toString());
            int access$300 = DrawingView.this.curIndx + 1;
            while (size > access$300) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append(" indx ");
                sb2.append(access$300);
                Log.i("testings", sb2.toString());
                DrawingView.this.changesIndx.remove(access$300);
                DrawingView.this.brushIndx.remove(access$300);
                DrawingView.this.modeIndx.remove(access$300);
                DrawingView.this.brushTypeIndx.remove(access$300);
                DrawingView.this.vectorPoints.remove(access$300);
                DrawingView.this.lassoIndx.remove(access$300);
                size = DrawingView.this.changesIndx.size();
            }
            if (DrawingView.this.undoRedoListener != null) {
                DrawingView.this.undoRedoListener.enableUndo(true, DrawingView.this.curIndx + 1);
                DrawingView.this.undoRedoListener.enableRedo(false, DrawingView.this.modeIndx.size() - (DrawingView.this.curIndx + 1));
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            super.onPreExecute();
            DrawingView.this.f118pd = new ProgressDialog(DrawingView.this.getContext());
            ProgressDialog progressDialog = DrawingView.this.f118pd;
            StringBuilder sb = new StringBuilder();
            sb.append(DrawingView.this.ctx.getResources().getString(R.string.processing));
            sb.append("...");
            progressDialog.setMessage(sb.toString());
            DrawingView.this.f118pd.setCancelable(false);
            DrawingView.this.f118pd.show();
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Bitmap bitmap) {
            DrawingView.this.f118pd.dismiss();
            DrawingView.this.invalidate();
            DrawingView.this.isAutoRunning = false;
        }
    }

    private class ScaleGestureListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
        private float mPivotX;
        private float mPivotY;
        private Vector2D mPrevSpanVector;

        private ScaleGestureListener() {
            this.mPrevSpanVector = new Vector2D();
        }

        public boolean onScaleBegin(View view, ScaleGestureDetector scaleGestureDetector) {
            this.mPivotX = scaleGestureDetector.getFocusX();
            this.mPivotY = scaleGestureDetector.getFocusY();
            this.mPrevSpanVector.set(scaleGestureDetector.getCurrentSpanVector());
            return true;
        }

        public boolean onScale(View view, ScaleGestureDetector scaleGestureDetector) {
            TransformInfo transformInfo = new TransformInfo();
            transformInfo.deltaScale = DrawingView.this.isScaleEnabled ? scaleGestureDetector.getScaleFactor() : 1.0f;
            float f = 0.0f;
            transformInfo.deltaAngle = DrawingView.this.isRotateEnabled ? Vector2D.getAngle(this.mPrevSpanVector, scaleGestureDetector.getCurrentSpanVector()) : 0.0f;
            transformInfo.deltaX = DrawingView.this.isTranslateEnabled ? scaleGestureDetector.getFocusX() - this.mPivotX : 0.0f;
            if (DrawingView.this.isTranslateEnabled) {
                f = scaleGestureDetector.getFocusY() - this.mPivotY;
            }
            transformInfo.deltaY = f;
            transformInfo.pivotX = this.mPivotX;
            transformInfo.pivotY = this.mPivotY;
            transformInfo.minimumScale = DrawingView.this.minimumScale;
            transformInfo.maximumScale = DrawingView.this.maximumScale;
            DrawingView.this.move(view, transformInfo);
            return false;
        }
    }

    private class TransformInfo {
        public float deltaAngle;
        public float deltaScale;
        public float deltaX;
        public float deltaY;
        public float maximumScale;
        public float minimumScale;
        public float pivotX;
        public float pivotY;

        private TransformInfo() {
        }
    }

    public interface UndoRedoListener {
        void enableRedo(boolean z, int i);

        void enableUndo(boolean z, int i);
    }

    public int getIndex(int i, int i2, int i3) {
        return i2 == 0 ? i : i + (i3 * (i2 - 1));
    }

    public float updatebrushsize(int i, float f) {
        return ((float) i) / f;
    }

    public void setUndoRedoListener(UndoRedoListener undoRedoListener2) {
        this.undoRedoListener = undoRedoListener2;
    }

    public void setActionListener(ActionListener actionListener2) {
        this.actionListener = actionListener2;
    }

    public DrawingView(Context context) {
        super(context);
        initPaint(context);
    }

    public DrawingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        initPaint(context);
    }

    private void initPaint(Context context) {
        MODE = 1;
        this.mScaleGestureDetector = new ScaleGestureDetector(new ScaleGestureListener());
        this.ctx = context;
        setFocusable(true);
        setFocusableInTouchMode(true);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        this.screenWidth = displayMetrics.widthPixels;
        this.brushSize = ImageUtils.dpToPx(getContext(), this.brushSize);
        this.brushSize1 = ImageUtils.dpToPx(getContext(), this.brushSize);
        this.targetBrushSize = ImageUtils.dpToPx(getContext(), 50);
        this.targetBrushSize1 = ImageUtils.dpToPx(getContext(), 50);
        this.paint.setAlpha(0);
        this.paint.setColor(0);
        this.paint.setStyle(Style.STROKE);
        this.paint.setStrokeJoin(Join.ROUND);
        this.paint.setStrokeCap(Cap.ROUND);
        this.paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
        this.paint.setAntiAlias(true);
        this.paint.setStrokeWidth(updatebrushsize(this.brushSize1, scale));
        this.erPaint = new Paint();
        this.erPaint.setAntiAlias(true);
        this.erPaint.setColor(SupportMenu.CATEGORY_MASK);
        this.erPaint.setAntiAlias(true);
        this.erPaint.setStyle(Style.STROKE);
        this.erPaint.setStrokeJoin(Join.MITER);
        this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
        this.erPaint1 = new Paint();
        this.erPaint1.setAntiAlias(true);
        this.erPaint1.setColor(SupportMenu.CATEGORY_MASK);
        this.erPaint1.setAntiAlias(true);
        this.erPaint1.setStyle(Style.STROKE);
        this.erPaint1.setStrokeJoin(Join.MITER);
        this.erPaint1.setStrokeWidth(updatebrushsize(this.erps, scale));
        this.erPaint1.setPathEffect(new DashPathEffect(new float[]{10.0f, 20.0f}, 0.0f));
        this.onePxPaint.setAlpha(0);
        this.onePxPaint.setStyle(Style.STROKE);
        this.onePxPaint.setStrokeJoin(Join.MITER);
        this.onePxPaint.setStrokeCap(Cap.SQUARE);
        this.onePxPaint.setStrokeWidth(1.0f);
        this.onePxPaint.setColor(0);
        this.onePxPaint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
    }

    public void setImageBitmap(Bitmap bitmap) {
        if (bitmap != null) {
            if (this.orgBit == null) {
                this.orgBit = bitmap.copy(bitmap.getConfig(), true);
            }
            this.width = bitmap.getWidth();
            this.height = bitmap.getHeight();
            this.Bitmap2 = Bitmap.createBitmap(this.width, this.height, bitmap.getConfig());
            this.f116c2 = new Canvas();
            this.f116c2.setBitmap(this.Bitmap2);
            this.f116c2.drawBitmap(bitmap, 0.0f, 0.0f, null);
            if (this.isSelected) {
                enableTouchClear(this.isSelected);
            }
            this.onePxPath.reset();
            this.onePxPath.moveTo(0.0f, 0.0f);
            this.onePxPath.lineTo((float) (this.Bitmap2.getWidth() - 1), 0.0f);
            this.onePxPath.lineTo((float) (this.Bitmap2.getWidth() - 1), (float) (this.Bitmap2.getHeight() - 1));
            this.onePxPath.lineTo(0.0f, (float) (this.Bitmap2.getHeight() - 1));
            this.onePxPath.lineTo(0.0f, 0.0f);
            this.onePxPath.close();
            super.setImageBitmap(this.Bitmap2);
        }
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f116c2 != null) {
            if (!this.updateOnly && this.isTouched) {
                this.paint = getPaintByMode(MODE, this.brushSize, this.isRectBrushEnable);
                if (this.tPath != null) {
                    this.f116c2.drawPath(this.tPath, this.paint);
                }
                this.isTouched = false;
            }
            if (MODE == this.TARGET) {
                this.f117p = new Paint();
                this.f117p.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                canvas.drawCircle(this.f114X, this.f115Y, (float) (this.targetBrushSize / 2), this.erPaint);
                canvas.drawCircle(this.f114X, this.f115Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7), scale), this.f117p);
                this.f117p.setStrokeWidth(updatebrushsize(ImageUtils.dpToPx(getContext(), 1), scale));
                Canvas canvas2 = canvas;
                canvas2.drawLine(this.f114X - ((float) (this.targetBrushSize / 2)), this.f115Y, ((float) (this.targetBrushSize / 2)) + this.f114X, this.f115Y, this.f117p);
                Canvas canvas3 = canvas;
                canvas3.drawLine(this.f114X, this.f115Y - ((float) (this.targetBrushSize / 2)), this.f114X, ((float) (this.targetBrushSize / 2)) + this.f115Y, this.f117p);
                this.drawOnLasso = true;
            }
            if (MODE == this.LASSO) {
                this.f117p = new Paint();
                this.f117p.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                canvas.drawCircle(this.f114X, this.f115Y, (float) (this.targetBrushSize / 2), this.erPaint);
                canvas.drawCircle(this.f114X, this.f115Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7), scale), this.f117p);
                this.f117p.setStrokeWidth(updatebrushsize(ImageUtils.dpToPx(getContext(), 1), scale));
                Canvas canvas4 = canvas;
                canvas4.drawLine(this.f114X - ((float) (this.targetBrushSize / 2)), this.f115Y, ((float) (this.targetBrushSize / 2)) + this.f114X, this.f115Y, this.f117p);
                Canvas canvas5 = canvas;
                canvas5.drawLine(this.f114X, this.f115Y - ((float) (this.targetBrushSize / 2)), this.f114X, ((float) (this.targetBrushSize / 2)) + this.f115Y, this.f117p);
                if (!this.drawOnLasso) {
                    this.erPaint1.setStrokeWidth(updatebrushsize(this.erps, scale));
                    canvas.drawPath(this.lPath, this.erPaint1);
                }
            }
            if (MODE == this.ERASE || MODE == this.REDRAW) {
                this.f117p = new Paint();
                this.f117p.setColor(SupportMenu.CATEGORY_MASK);
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                if (this.isRectBrushEnable) {
                    float f = (float) (this.brushSize / 2);
                    canvas.drawRect(this.f114X - f, this.f115Y - f, this.f114X + f, this.f115Y + f, this.erPaint);
                } else {
                    canvas.drawCircle(this.f114X, this.f115Y, (float) (this.brushSize / 2), this.erPaint);
                }
                canvas.drawCircle(this.f114X, this.f115Y + ((float) this.offset), updatebrushsize(ImageUtils.dpToPx(getContext(), 7), scale), this.f117p);
            }
            this.updateOnly = false;
        }
    }

    public boolean onTouch(View view, MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        if (motionEvent.getPointerCount() == 1) {
            if (this.actionListener != null) {
                this.actionListener.onAction(motionEvent.getAction());
            }
            if (MODE == this.TARGET) {
                this.drawOnLasso = false;
                this.f114X = motionEvent.getX();
                this.f115Y = motionEvent.getY() - ((float) this.offset);
                updateShader1(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), true);
                switch (action) {
                    case 0:
                        invalidate();
                        break;
                    case 1:
                        if (this.f114X >= 0.0f && this.f115Y >= 0.0f && this.f114X < ((float) this.Bitmap2.getWidth()) && this.f115Y < ((float) this.Bitmap2.getHeight())) {
                            this.point = new Point((int) this.f114X, (int) this.f115Y);
                            f113pc = this.Bitmap2.getPixel((int) this.f114X, (int) this.f115Y);
                            if (!this.isAutoRunning) {
                                this.isAutoRunning = true;
                                new AsyncTaskRunner(f113pc).execute(new Void[0]);
                            }
                        }
                        updateShader1(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), false);
                        invalidate();
                        break;
                    case 2:
                        invalidate();
                        break;
                }
            }
            if (MODE == this.LASSO) {
                this.f114X = motionEvent.getX();
                this.f115Y = motionEvent.getY() - ((float) this.offset);
                switch (action) {
                    case 0:
                        this.isNewPath = true;
                        this.drawOnLasso = false;
                        this.f119sX = this.f114X;
                        this.f120sY = this.f115Y;
                        this.lPath = new Path();
                        this.lPath.moveTo(this.f114X, this.f115Y);
                        updateShader1(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), true);
                        invalidate();
                        break;
                    case 1:
                        this.lPath.lineTo(this.f114X, this.f115Y);
                        this.lPath.lineTo(this.f119sX, this.f120sY);
                        this.drawLasso = true;
                        updateShader1(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), false);
                        invalidate();
                        if (this.actionListener != null) {
                            this.actionListener.onActionCompleted(5);
                            break;
                        }
                        break;
                    case 2:
                        this.lPath.lineTo(this.f114X, this.f115Y);
                        updateShader1(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), true);
                        invalidate();
                        break;
                    default:
                        return false;
                }
            }
            if (MODE == this.ERASE || MODE == this.REDRAW) {
                int i = this.brushSize / 2;
                this.f114X = motionEvent.getX();
                this.f115Y = motionEvent.getY() - ((float) this.offset);
                this.isTouched = true;
                this.erPaint.setStrokeWidth(updatebrushsize(this.erps, scale));
                updateShader(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), true);
                switch (action) {
                    case 0:
                        this.paint.setStrokeWidth((float) this.brushSize);
                        this.tPath = new Path();
                        if (this.isRectBrushEnable) {
                            float f = (float) i;
                            this.tPath.addRect(this.f114X - f, this.f115Y - f, this.f114X + f, this.f115Y + f, Direction.CW);
                        } else {
                            this.tPath.moveTo(this.f114X, this.f115Y);
                        }
                        invalidate();
                        break;
                    case 1:
                        updateShader(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), false);
                        if (this.tPath != null) {
                            if (this.isRectBrushEnable) {
                                float f2 = (float) i;
                                this.tPath.addRect(this.f114X - f2, this.f115Y - f2, this.f114X + f2, this.f115Y + f2, Direction.CW);
                            } else {
                                this.tPath.lineTo(this.f114X, this.f115Y);
                            }
                            invalidate();
                            this.changesIndx.add(this.curIndx + 1, new Path(this.tPath));
                            this.brushIndx.add(this.curIndx + 1, Integer.valueOf(this.brushSize));
                            this.modeIndx.add(this.curIndx + 1, Integer.valueOf(MODE));
                            this.brushTypeIndx.add(this.curIndx + 1, Boolean.valueOf(this.isRectBrushEnable));
                            this.vectorPoints.add(this.curIndx + 1, null);
                            this.lassoIndx.add(this.curIndx + 1, Boolean.valueOf(this.insidCutEnable));
                            this.tPath.reset();
                            this.curIndx++;
                            clearNextChanges();
                            this.tPath = null;
                            break;
                        }
                        break;
                    case 2:
                        if (this.tPath != null) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(" In Action Move ");
                            sb.append(this.f114X);
                            sb.append(" ");
                            sb.append(this.f115Y);
                            Log.e("movetest", sb.toString());
                            if (this.isRectBrushEnable) {
                                float f3 = (float) i;
                                this.tPath.addRect(this.f114X - f3, this.f115Y - f3, this.f114X + f3, this.f115Y + f3, Direction.CW);
                            } else {
                                this.tPath.lineTo(this.f114X, this.f115Y);
                            }
                            invalidate();
                            this.isMoved = true;
                            break;
                        }
                        break;
                    default:
                        return false;
                }
            }
        } else {
            if (this.tPath != null) {
                if (!this.isMoved || !(MODE == this.ERASE || MODE == this.REDRAW)) {
                    this.tPath.reset();
                    invalidate();
                    this.tPath = null;
                } else {
                    int i2 = this.brushSize / 2;
                    if (this.isRectBrushEnable) {
                        float f4 = (float) i2;
                        this.tPath.addRect(this.f114X - f4, this.f115Y - f4, this.f114X + f4, this.f115Y + f4, Direction.CW);
                    } else {
                        this.tPath.lineTo(this.f114X, this.f115Y);
                    }
                    invalidate();
                    this.changesIndx.add(this.curIndx + 1, new Path(this.tPath));
                    this.brushIndx.add(this.curIndx + 1, Integer.valueOf(this.brushSize));
                    this.modeIndx.add(this.curIndx + 1, Integer.valueOf(MODE));
                    this.brushTypeIndx.add(this.curIndx + 1, Boolean.valueOf(this.isRectBrushEnable));
                    this.vectorPoints.add(this.curIndx + 1, null);
                    this.lassoIndx.add(this.curIndx + 1, Boolean.valueOf(this.insidCutEnable));
                    this.tPath.reset();
                    this.curIndx++;
                    clearNextChanges();
                    this.tPath = null;
                    this.isMoved = false;
                }
            }
            this.mScaleGestureDetector.onTouchEvent((View) view.getParent(), motionEvent);
            invalidate();
            updateShader(this.f114X, this.f115Y, motionEvent.getRawX(), motionEvent.getRawY(), false);
        }
        return true;
    }

    private void updateShader(float f, float f2, float f3, float f4, boolean z) {
        if (this.shaderView != null) {
            Paint paint2 = new Paint();
            if (f4 - ((float) this.offset) < ((float) ImageUtils.dpToPx(this.ctx, 100))) {
                if (f3 < ((float) ImageUtils.dpToPx(this.ctx, 180))) {
                    this.onLeft = false;
                }
                if (f3 > ((float) (this.screenWidth - ImageUtils.dpToPx(this.ctx, 180)))) {
                    this.onLeft = true;
                }
            }
            Bitmap createBitmap = Bitmap.createBitmap(this.Bitmap2.getWidth(), this.Bitmap2.getHeight(), this.Bitmap2.getConfig());
            Canvas canvas = new Canvas(createBitmap);
            canvas.drawBitmap(this.Bitmap2, 0.0f, 0.0f, null);
            canvas.drawPath(this.onePxPath, this.onePxPaint);
            BitmapShader bitmapShader = new BitmapShader(createBitmap, TileMode.CLAMP, TileMode.CLAMP);
            paint2.setShader(bitmapShader);
            Matrix matrix = new Matrix();
            matrix.postScale(scale * 1.5f, scale * 1.5f, f, f2);
            if (this.onLeft) {
                matrix.postTranslate(-(f - ((float) ImageUtils.dpToPx(this.ctx, 75))), -(f2 - ((float) ImageUtils.dpToPx(this.ctx, 75))));
            } else {
                matrix.postTranslate(-(f - ((float) (this.screenWidth - ImageUtils.dpToPx(this.ctx, 75)))), -(f2 - ((float) ImageUtils.dpToPx(this.ctx, 75))));
            }
            bitmapShader.setLocalMatrix(matrix);
            this.shaderView.updateShaderView(paint2, (int) (((double) (this.brushSize1 / 2)) * 1.5d), z, this.onLeft, this.isRectBrushEnable);
        }
    }

    private void updateShader1(float f, float f2, float f3, float f4, boolean z) {
        BitmapShader bitmapShader;
        if (this.shaderView != null) {
            Paint paint2 = new Paint();
            if (f4 - ((float) this.offset) < ((float) ImageUtils.dpToPx(this.ctx, 100))) {
                if (f3 < ((float) ImageUtils.dpToPx(this.ctx, 180))) {
                    this.onLeft = false;
                }
                if (f3 > ((float) (this.screenWidth - ImageUtils.dpToPx(this.ctx, 180)))) {
                    this.onLeft = true;
                }
            }
            if (MODE == this.LASSO) {
                Bitmap createBitmap = Bitmap.createBitmap(this.Bitmap2.getWidth(), this.Bitmap2.getHeight(), this.Bitmap2.getConfig());
                Canvas canvas = new Canvas(createBitmap);
                canvas.drawBitmap(this.Bitmap2, 0.0f, 0.0f, null);
                this.erPaint1.setStrokeWidth(updatebrushsize(this.erps, scale));
                canvas.drawPath(this.lPath, this.erPaint1);
                bitmapShader = new BitmapShader(createBitmap, TileMode.CLAMP, TileMode.CLAMP);
            } else {
                bitmapShader = new BitmapShader(this.Bitmap2, TileMode.CLAMP, TileMode.CLAMP);
            }
            paint2.setShader(bitmapShader);
            Matrix matrix = new Matrix();
            matrix.postScale(scale * 1.5f, scale * 1.5f, f, f2);
            if (this.onLeft) {
                matrix.postTranslate(-(f - ((float) ImageUtils.dpToPx(this.ctx, 75))), -(f2 - ((float) ImageUtils.dpToPx(this.ctx, 75))));
            } else {
                matrix.postTranslate(-(f - ((float) (this.screenWidth - ImageUtils.dpToPx(this.ctx, 75)))), -(f2 - ((float) ImageUtils.dpToPx(this.ctx, 75))));
            }
            bitmapShader.setLocalMatrix(matrix);
            this.shaderView.updateShaderView(paint2, (int) (((double) ((((float) this.targetBrushSize) * scale) / 2.0f)) * 1.5d), z, this.onLeft, this.isRectBrushEnable);
        }
    }

    /* access modifiers changed from: private */
    public void move(View view, TransformInfo transformInfo) {
        computeRenderOffset(view, transformInfo.pivotX, transformInfo.pivotY);
        adjustTranslation(view, transformInfo.deltaX, transformInfo.deltaY);
        float max = Math.max(transformInfo.minimumScale, Math.min(transformInfo.maximumScale, view.getScaleX() * transformInfo.deltaScale));
        view.setScaleX(max);
        view.setScaleY(max);
        updateOnScale(max);
        invalidate();
    }

    private static void adjustTranslation(View view, float f, float f2) {
        float[] fArr = {f, f2};
        view.getMatrix().mapVectors(fArr);
        view.setTranslationX(view.getTranslationX() + fArr[0]);
        view.setTranslationY(view.getTranslationY() + fArr[1]);
    }

    private static void computeRenderOffset(View view, float f, float f2) {
        if (view.getPivotX() != f || view.getPivotY() != f2) {
            float[] fArr = {0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr);
            view.setPivotX(f);
            view.setPivotY(f2);
            float[] fArr2 = {0.0f, 0.0f};
            view.getMatrix().mapPoints(fArr2);
            float f3 = fArr2[0] - fArr[0];
            float f4 = fArr2[1] - fArr[1];
            view.setTranslationX(view.getTranslationX() - f3);
            view.setTranslationY(view.getTranslationY() - f4);
        }
    }

    private void clearNextChanges() {
        int size = this.changesIndx.size();
        StringBuilder sb = new StringBuilder();
        sb.append("ClearNextChange Curindx ");
        sb.append(this.curIndx);
        sb.append(" Size ");
        sb.append(size);
        Log.i("testings", sb.toString());
        int i = this.curIndx + 1;
        while (size > i) {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(" indx ");
            sb2.append(i);
            Log.i("testings", sb2.toString());
            this.changesIndx.remove(i);
            this.brushIndx.remove(i);
            this.modeIndx.remove(i);
            this.brushTypeIndx.remove(i);
            this.vectorPoints.remove(i);
            this.lassoIndx.remove(i);
            size = this.changesIndx.size();
        }
        if (this.undoRedoListener != null) {
            this.undoRedoListener.enableUndo(true, this.curIndx + 1);
            this.undoRedoListener.enableRedo(false, this.modeIndx.size() - (this.curIndx + 1));
        }
        if (this.actionListener != null) {
            this.actionListener.onActionCompleted(MODE);
        }
    }

    public void setMODE(int i) {
        MODE = i;
        if (!(i == this.TARGET || this.Bitmap3 == null)) {
            this.Bitmap3.recycle();
            this.Bitmap3 = null;
        }
        if (i != this.LASSO) {
            this.drawOnLasso = true;
            this.drawLasso = false;
            if (this.Bitmap4 != null) {
                this.Bitmap4.recycle();
                this.Bitmap4 = null;
            }
        }
    }

    private Paint getPaintByMode(int i, int i2, boolean z) {
        this.paint = new Paint();
        this.paint.setAlpha(0);
        if (z) {
            this.paint.setStyle(Style.FILL_AND_STROKE);
            this.paint.setStrokeJoin(Join.MITER);
            this.paint.setStrokeCap(Cap.SQUARE);
        } else {
            this.paint.setStyle(Style.STROKE);
            this.paint.setStrokeJoin(Join.ROUND);
            this.paint.setStrokeCap(Cap.ROUND);
            this.paint.setStrokeWidth((float) i2);
        }
        this.paint.setAntiAlias(true);
        if (i == this.ERASE) {
            this.paint.setColor(0);
            this.paint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
        }
        if (i == this.REDRAW) {
            this.paint.setColor(-1);
            this.patternBMPshader = CutOutActivity.patternBMPshader;
            this.paint.setShader(this.patternBMPshader);
        }
        return this.paint;
    }

    public void updateThreshHold() {
        if (this.Bitmap3 != null && !this.isAutoRunning) {
            this.isAutoRunning = true;
            new AsyncTaskRunner1(f113pc).execute(new Void[0]);
        }
    }

    public int getLastChangeMode() {
        if (this.curIndx < 0) {
            return this.NONE;
        }
        return ((Integer) this.modeIndx.get(this.curIndx)).intValue();
    }

    public void setOffset(int i) {
        this.offset1 = i;
        this.offset = (int) updatebrushsize(ImageUtils.dpToPx(this.ctx, i), scale);
        this.updateOnly = true;
    }

    public int getOffset() {
        return this.offset1;
    }

    public void setRadius(int i) {
        this.brushSize1 = ImageUtils.dpToPx(getContext(), i);
        this.brushSize = (int) updatebrushsize(this.brushSize1, scale);
        this.updateOnly = true;
    }

    public void updateOnScale(float f) {
        StringBuilder sb = new StringBuilder();
        sb.append("Scale ");
        sb.append(f);
        sb.append("  Brushsize  ");
        sb.append(this.brushSize);
        Log.i("testings", sb.toString());
        scale = f;
        this.brushSize = (int) updatebrushsize(this.brushSize1, f);
        this.targetBrushSize = (int) updatebrushsize(this.targetBrushSize1, f);
        this.offset = (int) updatebrushsize(ImageUtils.dpToPx(this.ctx, this.offset1), f);
    }

    public void setThreshold(int i) {
        this.TOLERANCE = i;
        if (this.curIndx >= 0) {
            int intValue = ((Integer) this.modeIndx.get(this.curIndx)).intValue();
            String str = "testings";
            StringBuilder sb = new StringBuilder();
            sb.append(" Threshold ");
            sb.append(i);
            sb.append("  ");
            sb.append(intValue == this.TARGET);
            Log.i(str, sb.toString());
        }
    }

    public boolean isTouchEnable() {
        return this.isSelected;
    }

    public void enableTouchClear(boolean z) {
        this.isSelected = z;
        if (z) {
            setOnTouchListener(this);
        } else {
            setOnTouchListener(null);
        }
    }

    public void enableInsideCut(boolean z) {
        this.insidCutEnable = z;
        if (this.drawLasso) {
            Log.i("testings", " draw lassso   on up ");
            if (this.isNewPath) {
                this.Bitmap4 = this.Bitmap2.copy(this.Bitmap2.getConfig(), true);
                drawLassoPath(this.lPath, this.insidCutEnable);
                this.changesIndx.add(this.curIndx + 1, new Path(this.lPath));
                this.brushIndx.add(this.curIndx + 1, Integer.valueOf(this.brushSize));
                this.modeIndx.add(this.curIndx + 1, Integer.valueOf(MODE));
                this.brushTypeIndx.add(this.curIndx + 1, Boolean.valueOf(this.isRectBrushEnable));
                this.vectorPoints.add(this.curIndx + 1, null);
                this.lassoIndx.add(this.curIndx + 1, Boolean.valueOf(this.insidCutEnable));
                this.curIndx++;
                clearNextChanges();
                invalidate();
                this.isNewPath = false;
                return;
            }
            Log.i("testings", " New PAth false ");
            setImageBitmap(this.Bitmap4);
            drawLassoPath(this.lPath, this.insidCutEnable);
            this.lassoIndx.add(this.curIndx, Boolean.valueOf(this.insidCutEnable));
            return;
        }
        Toast.makeText(this.ctx, "please draw path", Toast.LENGTH_SHORT).show();
    }

    public boolean isRectBrushEnable() {
        return this.isRectBrushEnable;
    }

    public void enableRectBrush(boolean z) {
        this.isRectBrushEnable = z;
        this.updateOnly = true;
    }

    public void undoChange() {
        this.drawLasso = false;
        setImageBitmap(this.orgBit);
        StringBuilder sb = new StringBuilder();
        sb.append("Performing UNDO Curindx ");
        sb.append(this.curIndx);
        sb.append("  ");
        sb.append(this.changesIndx.size());
        Log.i("testings", sb.toString());
        if (this.curIndx >= 0) {
            this.curIndx--;
            redrawCanvas();
            StringBuilder sb2 = new StringBuilder();
            sb2.append(" Curindx ");
            sb2.append(this.curIndx);
            sb2.append("  ");
            sb2.append(this.changesIndx.size());
            Log.i("testings", sb2.toString());
            if (this.undoRedoListener != null) {
                this.undoRedoListener.enableUndo(true, this.curIndx + 1);
                this.undoRedoListener.enableRedo(true, this.modeIndx.size() - (this.curIndx + 1));
            }
            if (this.curIndx < 0 && this.undoRedoListener != null) {
                this.undoRedoListener.enableUndo(false, this.curIndx + 1);
            }
        }
    }

    public void redoChange() {
        this.drawLasso = false;
        String str = "testings";
        StringBuilder sb = new StringBuilder();
        sb.append(this.curIndx + 1 >= this.changesIndx.size());
        sb.append(" Curindx ");
        sb.append(this.curIndx);
        sb.append(" ");
        sb.append(this.changesIndx.size());
        Log.i(str, sb.toString());
        if (this.curIndx + 1 < this.changesIndx.size()) {
            setImageBitmap(this.orgBit);
            this.curIndx++;
            redrawCanvas();
            if (this.undoRedoListener != null) {
                this.undoRedoListener.enableUndo(true, this.curIndx + 1);
                this.undoRedoListener.enableRedo(true, this.modeIndx.size() - (this.curIndx + 1));
            }
            if (this.curIndx + 1 >= this.changesIndx.size() && this.undoRedoListener != null) {
                this.undoRedoListener.enableRedo(false, this.modeIndx.size() - (this.curIndx + 1));
            }
        }
    }

    private void redrawCanvas() {
        for (int i = 0; i <= this.curIndx; i++) {
            if (((Integer) this.modeIndx.get(i)).intValue() == this.ERASE || ((Integer) this.modeIndx.get(i)).intValue() == this.REDRAW) {
                this.tPath = new Path((Path) this.changesIndx.get(i));
                this.paint = getPaintByMode(((Integer) this.modeIndx.get(i)).intValue(), ((Integer) this.brushIndx.get(i)).intValue(), ((Boolean) this.brushTypeIndx.get(i)).booleanValue());
                this.f116c2.drawPath(this.tPath, this.paint);
                this.tPath.reset();
            }
            if (((Integer) this.modeIndx.get(i)).intValue() == this.TARGET) {
                Vector vector = (Vector) this.vectorPoints.get(i);
                int[] iArr = new int[(this.width * this.height)];
                this.Bitmap2.getPixels(iArr, 0, this.width, 0, 0, this.width, this.height);
                for (int i2 = 0; i2 < vector.size(); i2++) {
                    Point point2 = (Point) vector.get(i2);
                    iArr[getIndex(point2.x, point2.y, this.width)] = 0;
                }
                this.Bitmap2.setPixels(iArr, 0, this.width, 0, 0, this.width, this.height);
            }
            if (((Integer) this.modeIndx.get(i)).intValue() == this.LASSO) {
                Log.i("testings", " onDraw Lassoo ");
                drawLassoPath(new Path((Path) this.changesIndx.get(i)), ((Boolean) this.lassoIndx.get(i)).booleanValue());
            }
        }
    }

    private void drawLassoPath(Path path, boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append(z);
        sb.append(" New PAth false ");
        sb.append(path.isEmpty());
        Log.i("testings", sb.toString());
        if (z) {
            Paint paint2 = new Paint();
            paint2.setAntiAlias(true);
            paint2.setColor(0);
            paint2.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
            this.f116c2.drawPath(path, paint2);
        } else {
            Bitmap copy = this.Bitmap2.copy(this.Bitmap2.getConfig(), true);
            new Canvas(copy).drawBitmap(this.Bitmap2, 0.0f, 0.0f, null);
            this.f116c2.drawColor(this.NONE, Mode.CLEAR);
            Paint paint3 = new Paint();
            paint3.setAntiAlias(true);
            this.f116c2.drawPath(path, paint3);
            paint3.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
            this.f116c2.drawBitmap(copy, 0.0f, 0.0f, paint3);
            copy.recycle();
        }
        this.drawOnLasso = true;
    }

    public Bitmap getFinalBitmap() {
        return this.Bitmap2.copy(this.Bitmap2.getConfig(), true);
    }

    public void setShaderView(ShaderView shaderView2) {
        this.shaderView = shaderView2;
    }
}
