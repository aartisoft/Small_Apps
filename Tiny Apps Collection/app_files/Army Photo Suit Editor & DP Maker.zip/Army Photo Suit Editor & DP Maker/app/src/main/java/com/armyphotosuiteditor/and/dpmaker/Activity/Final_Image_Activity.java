package com.armyphotosuiteditor.and.dpmaker.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.armyphotosuiteditor.and.dpmaker.ConnectionDetector;
import com.armyphotosuiteditor.and.dpmaker.Constant;
import com.armyphotosuiteditor.and.dpmaker.R;
import com.armyphotosuiteditor.and.dpmaker.Utility;

import java.io.File;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Final_Image_Activity extends AppCompatActivity implements Constant.Callingafterads{


    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    RelativeLayout relaivelayout;
    ImageView share_whatsapp,share_insta,share_facebook,share_common;
    ImageView final_image;
    AlertDialog alertDialog;
    String Actiontype = "";
    AlertDialog alert;
    private AdView adViewbanner;
    private String type = "image/*";
    private static final String WHATSAPP_ID = "com.whatsapp";
    private static final String FACEBOOK_ID="com.facebook.katana";
    private static final String INSTAGRAM_ID="com.instagram.android";
    private static final String SHARE_ID="com.android.all";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalimage);

        constantfile = new Constant();
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        ActionBar action = getSupportActionBar();
        action.setTitle(getResources().getString(R.string.share_image));
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        relaivelayout = (RelativeLayout) findViewById(R.id.relaivelayout);
        final_image = (ImageView) findViewById(R.id.final_image);

        final_image.setImageURI(Uri.fromFile(new File(Constant.finalimagepath)));

        share_whatsapp = findViewById(R.id.share_whatsapp);
        share_insta = findViewById(R.id.share_insta);
        share_facebook = findViewById(R.id.share_facebook);
        share_common = findViewById(R.id.share_common);

        share_whatsapp.setOnClickListener(v -> {
            Actiontype = WHATSAPP_ID;
            callads();
        });

        share_insta.setOnClickListener(v -> {
            Actiontype = INSTAGRAM_ID;
            callads();
        });

        share_facebook.setOnClickListener(v -> {
            Actiontype = FACEBOOK_ID;
            callads();
        });

        share_common.setOnClickListener(v -> {
            Actiontype = SHARE_ID;
            callads();
        });

        adViewbanner = new AdView(this, getResources().getString(R.string.facebook_banner_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.ads);
        adContainer.addView(adViewbanner);
        adViewbanner.loadAd();
        adViewbanner.setAdListener(new AdListener() {
            @Override
            public void onError(Ad ad, AdError adError) {
                Log.e("gettingerror"," get error of ads :: " + adError.getErrorMessage());
            }

            @Override
            public void onAdLoaded(Ad ad) {

            }

            @Override
            public void onAdClicked(Ad ad) {

            }

            @Override
            public void onLoggingImpression(Ad ad) {

            }
        });



    }


    public void callads() {
        Opensharingdialog(Actiontype,Constant.finalimagepath);
        //constantfile.loadRewardadsAd(Final_Image_Activity.this, this);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        ActivityExit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    //code for deny
                }
                break;
        }
    }

    public void ActivityExit() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, R.style.AlertDialog);
        alertDialogBuilder.setMessage(getResources().getString(R.string.exit_main_title));
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        alert.dismiss();
                        Intent intent = new Intent(Final_Image_Activity.this, MainActivity.class);
                        intent.addCategory(Intent.CATEGORY_HOME);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();

                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alert.dismiss();
            }
        });
        alert = alertDialogBuilder.create();
        alert.show();

    }

    @Override
    public void onAdsresponce(Boolean showing) {
        Opensharingdialog(Actiontype,Constant.finalimagepath);
    }


    public void Opensharingdialog(String share_app,String getpath){
        if (getpath == null) {
            try {
                constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, getResources().getString(R.string.share_failed));
            } catch (Exception e) {

            }
        } else {
            constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, "Processing");
            switch (share_app) {
                case WHATSAPP_ID:
                    sharetodirectapp(WHATSAPP_ID,getpath);
                    break;
                 case INSTAGRAM_ID:
                     sharetodirectapp(INSTAGRAM_ID,getpath);
                    break;
                 case FACEBOOK_ID:
                     sharetodirectapp(FACEBOOK_ID,getpath);
                    break;
                case SHARE_ID:
                    share(getpath);
                    break;
            }
        }
    }



    public void sharetodirectapp(String appname,String path) {

        Uri imageUri = FileProvider.getUriForFile(Final_Image_Activity.this, Final_Image_Activity.this.getApplicationContext().getPackageName() + ".provider", new File(path));
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.setPackage(appname);

        final String final_text = getResources().getString(R.string.download_more_from_link) + "\n\n" + Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()).toString();

        shareIntent.putExtra(Intent.EXTRA_TEXT, final_text);
        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);

        shareIntent.setType(type);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(shareIntent);
        } catch (android.content.ActivityNotFoundException ex) {
            switch (appname) {
                case WHATSAPP_ID:
                    constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, getResources().getString(R.string.whatsapp_not_installed));
                    break;
                case INSTAGRAM_ID:
                    constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, getResources().getString(R.string.instagram_not_installed));
                    break;
                case FACEBOOK_ID:
                    constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, getResources().getString(R.string.facebook_not_installed));
                    break;
            }

        }
    }

    public void share(String path) {
        Uri imageUri = FileProvider.getUriForFile(Final_Image_Activity.this, Final_Image_Activity.this.getApplicationContext().getPackageName() + ".provider", new File(path));
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);

        final String final_text = getResources().getString(R.string.download_more_from_link) + "\n\n" + Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName()).toString();

        shareIntent.putExtra(Intent.EXTRA_TEXT, final_text);
        shareIntent.putExtra(Intent.EXTRA_STREAM, imageUri);

        shareIntent.setType(type);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(shareIntent, getResources().getString(R.string.share_via) + " " + getResources().getString(R.string.app_name)));
        } catch (android.content.ActivityNotFoundException ex) {
            constantfile.snackbarcommonview(Final_Image_Activity.this, relaivelayout, getResources().getString(R.string.app_not_installed));
        }
    }
}
