package com.armyphotosuiteditor.and.dpmaker.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}