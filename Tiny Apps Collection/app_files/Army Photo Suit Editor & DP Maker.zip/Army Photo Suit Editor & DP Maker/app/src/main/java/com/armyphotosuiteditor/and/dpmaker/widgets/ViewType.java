package com.armyphotosuiteditor.and.dpmaker.widgets;



public enum ViewType {
    BRUSH_DRAWING,
    TEXT,
    IMAGE,
    EMOJI
}
