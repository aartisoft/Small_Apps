package com.armyphotosuiteditor.and.dpmaker.Activity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.ads.AudienceNetworkAds;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallState;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.OnSuccessListener;
import com.armyphotosuiteditor.and.dpmaker.ConnectionDetector;
import com.armyphotosuiteditor.and.dpmaker.Constant;
import com.armyphotosuiteditor.and.dpmaker.R;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.armyphotosuiteditor.and.dpmaker.Constant.arrayofimages;
import static com.armyphotosuiteditor.and.dpmaker.Constant.arrayofshowimages;
import static com.armyphotosuiteditor.and.dpmaker.Constant.arrayofbackground;
import static com.armyphotosuiteditor.and.dpmaker.Constant.arrayoffont;
import static com.armyphotosuiteditor.and.dpmaker.Constant.arrayofsticker;

public class MainActivity extends AppCompatActivity {
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    RelativeLayout content_main, start_rl;
    TextView rateus_tv, share_tv, exit_tv;
    private AlertDialog alert;

    AppUpdateManager appUpdateManager;
    private final static int MY_REQUEST_CODE = 111;
    com.google.android.play.core.tasks.Task<AppUpdateInfo> appUpdateInfoTask;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar action = getSupportActionBar();
        action.setTitle(getResources().getString(R.string.app_name));

        if (!AudienceNetworkAds.isInAdsProcess(MainActivity.this)){
            AudienceNetworkAds.initialize(MainActivity.this);
        }

        this.conn = null;
        constantfile = new Constant();
        content_main = (RelativeLayout) findViewById(R.id.content_main);
        start_rl = (RelativeLayout) findViewById(R.id.start_rl);
        rateus_tv = (TextView) findViewById(R.id.rateus_tv);
        share_tv = (TextView) findViewById(R.id.share_tv);
        exit_tv = (TextView) findViewById(R.id.exit_tv);

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());



        arrayofimages = new ArrayList<String>();
        arrayofshowimages = new ArrayList<String>();
        arrayofbackground = new ArrayList<String>();
        arrayoffont = new ArrayList<String>();
        arrayofsticker = new ArrayList<String>();

        try {
            arrayofimages.addAll(getImage(MainActivity.this));
            arrayofshowimages.addAll(getShowImage(MainActivity.this));
            arrayofbackground.addAll(getbackground(MainActivity.this));
            arrayoffont.addAll(getfont(MainActivity.this));
            arrayofsticker.addAll(getSticker(MainActivity.this));
        } catch (IOException e) {
            e.printStackTrace();
        }

        initAction();

        appUpdateManager = AppUpdateManagerFactory.create(MainActivity.this);

        appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        // Checks that the platform will allow the specified type of update.
        appUpdateInfoTask.addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                    updatestart(appUpdateInfo);
                }
            }
        });

    }

    private List<String> getImage(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        String[] files = assetManager.list("image");
        List<String> it = Arrays.asList(files);
        return it;
    }

    private List<String> getShowImage(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        String[] files = assetManager.list("showimage");
        List<String> it = Arrays.asList(files);
        return it;
    }

    private List<String> getbackground(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        String[] files = assetManager.list("background");
        List<String> it = Arrays.asList(files);
        return it;
    }

    private List<String> getfont(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        String[] files = assetManager.list("font");
        List<String> it = Arrays.asList(files);
        return it;
    }
    private List<String> getSticker(Context context) throws IOException {
        AssetManager assetManager = context.getAssets();
        String[] files = assetManager.list("sticker");
        List<String> it = Arrays.asList(files);
        return it;
    }



    public void initAction() {

        start_rl.setOnClickListener(v -> {
            Intent openselect = new Intent(MainActivity.this, SelectSuitActivity.class);
            startActivity(openselect);
        });

        rateus_tv.setOnClickListener(v -> CallRateAppCounter());

        share_tv.setOnClickListener(v -> CallShareCounter());

        exit_tv.setOnClickListener(v -> AppExit());

    }


    @Override
    public void onBackPressed() {
        AppExit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_privacy) {
            getopenPrivacypolicy();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void AppExit() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this,R.style.AlertDialog);
        alertDialogBuilder.setMessage(getResources().getString(R.string.exit_main_title));
        alertDialogBuilder.setPositiveButton("Yes",
                (arg0, arg1) -> {
                    alert.dismiss();
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_HOME);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                    System.exit(0);

                });

        alertDialogBuilder.setNegativeButton("No", (dialog, which) -> alert.dismiss());
        alert = alertDialogBuilder.create();
        alert.show();

    }

    public void CallRateAppCounter() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void getopenPrivacypolicy() {
        String url = "https://tinyappscollection.blogspot.com/2019/10/privacy-policy.html";
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    public void CallShareCounter() {
        constantfile.snackbarcommonview(MainActivity.this, content_main, "Processing");
        String whatsAppMessage = getResources().getString(R.string.share_message) + "\n\n";
        whatsAppMessage = whatsAppMessage + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName() + "\n";
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);

    }

    @Override
    protected void onResume() {
        super.onResume();

        appUpdateManager.getAppUpdateInfo().addOnSuccessListener(new OnSuccessListener<AppUpdateInfo>() {
            @Override
            public void onSuccess(AppUpdateInfo appUpdateInfo) {
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                    popupSnackbarForCompleteUpdate();
                }
                if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                    // If an in-app update is already running, resume the update.
                    updatestart(appUpdateInfo);
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MY_REQUEST_CODE) {
            if (resultCode != RESULT_OK) {
                Log.e("Update flow"," failed! Result code: " + resultCode);
                // If the update is cancelled or fails,
                // you can request to start the update again.
            }
        }
    }


    public void updatestart(AppUpdateInfo appUpdateInfo){
        InstallStateUpdatedListener listener = new InstallStateUpdatedListener() {
            @Override
            public void onStateUpdate(InstallState installState) {
                if (installState.installStatus() == InstallStatus.DOWNLOADED) {
                    // After the update is downloaded, show a notification
                    // and request user confirmation to restart the app.
                    popupSnackbarForCompleteUpdate();
                }
            }
        };
        appUpdateManager.registerListener(listener);
        try {
            appUpdateManager.startUpdateFlowForResult(
                    appUpdateInfo,
                    AppUpdateType.FLEXIBLE,
                    this,
                    MY_REQUEST_CODE);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    private void popupSnackbarForCompleteUpdate() {
        Snackbar snackbar = Snackbar.make(findViewById(R.id.content_main), "An update has just been downloaded.", Snackbar.LENGTH_INDEFINITE);
        snackbar.setAction("RESTART", new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                appUpdateManager.completeUpdate();
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(MainActivity.this, R.color.white));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(Color.BLACK);
        textaction.setTextColor(Color.BLACK);
        snackbar.show();
    }


}