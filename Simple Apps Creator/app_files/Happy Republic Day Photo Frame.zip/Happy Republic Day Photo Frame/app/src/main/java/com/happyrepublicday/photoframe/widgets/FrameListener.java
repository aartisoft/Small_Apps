package com.happyrepublicday.photoframe.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}