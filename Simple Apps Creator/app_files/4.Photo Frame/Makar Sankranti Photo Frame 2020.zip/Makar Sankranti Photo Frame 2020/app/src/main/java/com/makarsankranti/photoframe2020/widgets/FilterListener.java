package com.makarsankranti.photoframe2020.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}