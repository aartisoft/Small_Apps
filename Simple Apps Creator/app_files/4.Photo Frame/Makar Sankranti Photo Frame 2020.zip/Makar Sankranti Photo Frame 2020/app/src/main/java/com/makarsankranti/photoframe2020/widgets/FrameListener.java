package com.makarsankranti.photoframe2020.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}