package com.christmasphotoframesand.photoeditor.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}