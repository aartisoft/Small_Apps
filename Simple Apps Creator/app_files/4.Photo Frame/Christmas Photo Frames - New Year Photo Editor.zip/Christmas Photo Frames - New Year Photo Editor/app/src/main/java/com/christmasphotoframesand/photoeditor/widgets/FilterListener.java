package com.christmasphotoframesand.photoeditor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}