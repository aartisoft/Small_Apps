package com.tinyapps.mothersdayphotoframe.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}