package com.tinyapps.mothersdayphotoframe.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}