package com.navratriphotoframeand.editor.Activity;

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.navratriphotoframeand.editor.ConnectionDetector;
import com.navratriphotoframeand.editor.Constant;
import com.navratriphotoframeand.editor.R;
import com.navratriphotoframeand.editor.Utility;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Final_Image_Activity extends AppCompatActivity{


    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    RelativeLayout relaivelayout;
    LinearLayout download_ll, share_ll;
    ImageView final_image;
    AlertDialog alertDialog;
    String Actiontype = "";
    private static final String actiondownload = "download";
    private static final String actionshare = "share";

    private AdView adViewbanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalimage);

        constantfile = new Constant();
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        ActionBar action = getSupportActionBar();
        action.setTitle(getResources().getString(R.string.download_image_title));
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        adViewbanner = new AdView(this, getResources().getString(R.string.facebook_banner_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.ads);
        adContainer.addView(adViewbanner);
        adViewbanner.loadAd();

        relaivelayout = (RelativeLayout) findViewById(R.id.relaivelayout);
        final_image = (ImageView) findViewById(R.id.final_image);
        Bitmap bm = Bitmap.createBitmap(Constant.getfinalimage, 0, 0, (int) Constant.getfinalimage.getWidth(), (int) Constant.getfinalimage.getHeight());
        final_image.setImageBitmap(bm);
        download_ll = (LinearLayout) findViewById(R.id.download_ll);
        share_ll = (LinearLayout) findViewById(R.id.share_ll);

        download_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Actiontype = actiondownload;
                callaction();
            }
        });

        share_ll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Actiontype = actionshare;
                callaction();
            }
        });


    }

//    public void showdownloaddialog() {
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(getResources().getString(R.string.see_alert_title));
//        alertDialogBuilder.setPositiveButton("Yes",
//                new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface arg0, int arg1) {
//                        alertDialog.dismiss();
//                        callads();
//                    }
//                });
//
//        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                alertDialog.dismiss();
//            }
//        });
//        alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//
//    }

//    public void callads() {
//        constantfile.loadRewardadsAd(Final_Image_Activity.this, this);
//    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        this.finish();
    }


    @Override
    protected void onDestroy() {
        if (adViewbanner != null) {
            adViewbanner.destroy();
        }
        super.onDestroy();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    //code for deny
                }
                break;
        }
    }

    public void callaction(){
        if (Actiontype.equals(actiondownload)) {
            constantfile.download_image(Final_Image_Activity.this, Constant.getfinalimage, relaivelayout);
        } else if (Actiontype.equals(actionshare)) {
            constantfile.share_image(Final_Image_Activity.this, Constant.getfinalimage, relaivelayout);
        }
    }


//    @Override
//    public void onAdsresponce(Boolean showing) {
//        if (Actiontype.equals(actiondownload)) {
//            constantfile.download_image(Final_Image_Activity.this, Constant.getfinalimage, relaivelayout);
//        } else if (Actiontype.equals(actionshare)) {
//            constantfile.share_image(Final_Image_Activity.this, Constant.getfinalimage, relaivelayout);
//        }
//    }
}
