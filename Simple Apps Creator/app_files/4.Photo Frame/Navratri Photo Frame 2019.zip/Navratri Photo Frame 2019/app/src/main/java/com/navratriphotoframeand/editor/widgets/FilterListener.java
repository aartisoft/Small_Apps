package com.navratriphotoframeand.editor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}