package com.navratriphotoframeand.editor.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}