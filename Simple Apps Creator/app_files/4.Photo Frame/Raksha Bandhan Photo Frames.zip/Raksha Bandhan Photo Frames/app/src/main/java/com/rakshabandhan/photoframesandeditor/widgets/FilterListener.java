package com.rakshabandhan.photoframesandeditor.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}