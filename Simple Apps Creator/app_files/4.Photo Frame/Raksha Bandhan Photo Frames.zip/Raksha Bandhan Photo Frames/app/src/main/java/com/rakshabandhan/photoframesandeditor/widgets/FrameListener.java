package com.rakshabandhan.photoframesandeditor.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}