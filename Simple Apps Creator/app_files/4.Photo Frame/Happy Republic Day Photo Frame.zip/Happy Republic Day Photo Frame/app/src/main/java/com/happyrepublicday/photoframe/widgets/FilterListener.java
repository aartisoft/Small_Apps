package com.happyrepublicday.photoframe.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}