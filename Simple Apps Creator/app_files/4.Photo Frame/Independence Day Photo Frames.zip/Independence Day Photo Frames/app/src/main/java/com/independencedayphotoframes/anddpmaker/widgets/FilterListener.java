package com.independencedayphotoframes.anddpmaker.widgets;


public interface FilterListener {
    void onFilterSelected(PhotoFilter photoFilter);
}