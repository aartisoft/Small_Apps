package com.independencedayphotoframes.anddpmaker.widgets;


public interface FrameListener {
    void onFrameSelected(int position);
}