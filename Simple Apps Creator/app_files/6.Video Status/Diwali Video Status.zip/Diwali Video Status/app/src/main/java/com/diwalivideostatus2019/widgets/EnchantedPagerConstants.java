package com.diwalivideostatus2019.widgets;


public class EnchantedPagerConstants {
    public final static float BIG_SCALE = 1.0f;
    public final static float SMALL_SCALE = 1.0f;
    public final static float DIFF_SCALE = BIG_SCALE - SMALL_SCALE;
}
