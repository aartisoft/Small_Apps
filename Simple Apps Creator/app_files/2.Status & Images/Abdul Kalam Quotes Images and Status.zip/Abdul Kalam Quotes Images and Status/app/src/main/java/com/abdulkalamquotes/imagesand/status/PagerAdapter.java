package com.abdulkalamquotes.imagesand.status;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.util.ArrayList;


import in.galaxyofandroid.awesometablayout.AwesomeTabBarAdapter;

/**
 * Created by Md Farhan Raja on 2/16/2017.
 */

public class PagerAdapter extends AwesomeTabBarAdapter
{
    ArrayList<Fragment> fragments=new ArrayList<>();
    ArrayList<String> titles=new ArrayList<>();
    int[] colors={R.color.white,R.color.white};
    int[] textColors={android.R.color.black};
    int[] icons={R.drawable.ic_status_icon,R.drawable.ic_image_icon};

    public PagerAdapter(FragmentManager fragmentManager)
    {
        super(fragmentManager);
        fragments.add(new StatusFragment());
        fragments.add(new ImageFragment());

        titles.add("Status");
        titles.add("Images");

    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return titles.get(position);
    }

    @Override
    public int getColorResource(int position) {
        return colors[position];
    }

    @Override
    public int getTextColorResource(int position) {
        return textColors[0];
    }

    @Override
    public int getIconResource(int position) {
        return icons[position];
    }
}
