package com.abdulkalamquotes.imagesand.status;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.abdulkalamquotes.imagesand.status.Float.FloatingActionButton;

import java.util.ArrayList;

import static com.abdulkalamquotes.imagesand.status.CheckForSDCard.isConnectingToInternet;

public class ImageSingleActivity extends AppCompatActivity {
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    ArrayList<String> mData;
    int cposition;
    String actiontype = "";
    String actiondownload = "download";
    String actionsetas = "setas";
    String actionshare = "share";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_single);
        //   imageDownloader = new AltexImageDownloader(this);

        mData = getIntent().getExtras().getStringArrayList("MYDATA");
        cposition = getIntent().getExtras().getInt("position");
        init();
    }

    private void init() {

        ImageView back = (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        ShapeDrawable drawable = new ShapeDrawable(new OvalShape());
        drawable.getPaint().setColor(getResources().getColor(android.R.color.white));

        final FloatingActionButton action_download = (FloatingActionButton) findViewById(R.id.action_download);
        action_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actiontype = actiondownload;
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        Actiontodownshareset();
                    }
                }else{
                    Actiontodownshareset();
                }

            }
        });
        final FloatingActionButton action_setas = (FloatingActionButton) findViewById(R.id.action_setas);
        action_setas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actiontype = actionsetas;
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        Actiontodownshareset();
                    }
                }else{
                    Actiontodownshareset();
                }
            }
        });
        final FloatingActionButton action_share = (FloatingActionButton) findViewById(R.id.action_share);
        action_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                actiontype = actionshare;
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        Actiontodownshareset();
                    }
                }else{
                    Actiontodownshareset();
                }
            }
        });

        mPager = (ViewPager) findViewById(R.id.pager);
        mPager.setAdapter(new SlidingImage_Adapter(ImageSingleActivity.this, mData));
        mPager.setCurrentItem(cposition);

        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                cposition = i;
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });
        NUM_PAGES = mData.size();

    }


    public void Actiontodownshareset() {
        if (isConnectingToInternet(ImageSingleActivity.this)) {
            if (actiontype.equals(actiondownload)) {
                new DownloadTask(ImageSingleActivity.this, mData.get(cposition), "download");
            } else if (actiontype.equals(actionsetas)) {
                new DownloadTask(ImageSingleActivity.this, mData.get(cposition), "setas");
            } else if (actiontype.equals(actionshare)) {
                new DownloadTask(ImageSingleActivity.this, mData.get(cposition), "share");
            }
        } else {
            Toast.makeText(ImageSingleActivity.this, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 101: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Actiontodownshareset();
                } else {
                    Toast.makeText(ImageSingleActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    private boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);

    }
}
