package com.abdulkalamquotes.imagesand.status;

/**
 * Created by SONU on 29/10/15.
 */
public class Utils {
    public static final String SHARED_PREF = "ah_firebase";
    // global topic to receive app wide push notifications
    public static final String TOPIC_GLOBAL = "global";
    // broadcast receiver intent filters
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    /*
    public static final String mainUrl = "http://androhub.com/demo/";
    public static final String downloadPdfUrl = "http://androhub.com/demo/demo.pdf";
    public static final String downloadDocUrl = "http://androhub.com/demo/demo.doc";
    public static final String downloadZipUrl = "http://androhub.com/demo/demo.zip";
    public static final String downloadVideoUrl = "http://androhub.com/demo/demo.mp4";
    public static final String downloadMp3Url = "http://androhub.com/demo/demo.mp3";*/
}
