package com.vivekanandaquotes.images.andanmolvachan;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;

import java.util.ArrayList;
import java.util.Collections;

//import com.google.android.gms.ads.AdListener;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.InterstitialAd;

public class ImageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<String> mImageThum, mImagePath;
    private Context context;
    public static final int VIEW_TYPE_ITEM = 0;
    public static final int VIEW_TYPE_LOADING = 1;


    public void setnomoredata() {
        this.mImageThum.remove(mImageThum.size() - 1);
        this.mImagePath.remove(mImagePath.size() - 1);
        notifyDataSetChanged();
    }


    public void adddata(ArrayList<String> mImageThum, ArrayList<String> mImagePath, int pagenumber) {
        if (pagenumber == 0) {
            this.mImageThum.clear();
            this.mImageThum.addAll(mImageThum);
            this.mImagePath.clear();
            this.mImagePath.addAll(mImagePath);
            this.mImageThum.add(null);
            this.mImagePath.add(null);
        } else {
            this.mImageThum.removeAll(Collections.singleton(null));
            this.mImagePath.removeAll(Collections.singleton(null));
            this.mImageThum.addAll(mImageThum);
            this.mImagePath.addAll(mImagePath);
            this.mImageThum.add(null);
            this.mImagePath.add(null);
        }
        notifyDataSetChanged();
    }

    public ImageAdapter(Context context) {
        this.context = context;
        this.mImageThum = new ArrayList<>();
        this.mImagePath = new ArrayList<>();
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.image_row, parent, false);
            return new ViewHolderRow(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_progressbar, parent, false);
            return new ViewHolderLoading(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolderRow) {

            ViewHolderRow userViewHolder = (ViewHolderRow) holder;
            Glide.with(context)
                    .load(mImageThum.get(position))
                    .placeholder(R.drawable.placeholder)
                    .error(R.drawable.error)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            // log exception
                            Log.e("TAG", "Error loading image", e);
                            return false; // important to return false so the error placeholder can be placed
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            return false;
                        }
                    })
                    .into(userViewHolder.image_item);

            userViewHolder.bind(position);
        } else if (holder instanceof ViewHolderLoading) {
            ViewHolderLoading loadingViewHolder = (ViewHolderLoading) holder;
            loadingViewHolder.progressBar.setIndeterminate(true);
        }

    }

    @Override
    public int getItemCount() {
        return mImageThum == null ? 0 : mImageThum.size();
    }

    @Override
    public int getItemViewType(int position) {
        return mImageThum.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    private class ViewHolderLoading extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public ViewHolderLoading(View view) {
            super(view);
            progressBar = (ProgressBar) view.findViewById(R.id.itemProgressbar);
        }
    }

    public class ViewHolderRow extends RecyclerView.ViewHolder {
        public ImageView image_item;

        public ViewHolderRow(View v) {
            super(v);
            image_item = (ImageView) v.findViewById(R.id.image_item);
        }

        public void bind(final int pos) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    loadInterstitialAd(pos);
                }
            });
        }
    }

    private void loadInterstitialAd(final int pos) {
        final ProgressDialog progress = new ProgressDialog(context, R.style.MyAlertDialogStyle);
        progress.setMessage("Loading Ad");
        progress.setCancelable(false);
        progress.show();
        final InterstitialAd interstitialAd = new InterstitialAd(context, context.getResources().getString(R.string.facebook_interstitial_id));
        interstitialAd.loadAd();
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                Intent intent = new Intent(context, ImageSingleActivity.class);
                intent.putStringArrayListExtra("MYDATA", mImagePath);
                intent.putExtra("position", pos);
                context.startActivity(intent);
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                Intent intent = new Intent(context, ImageSingleActivity.class);
                intent.putStringArrayListExtra("MYDATA", mImagePath);
                intent.putExtra("position", pos);
                context.startActivity(intent);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd.isAdLoaded()) {
                    interstitialAd.show();
                }
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });

    }

}
