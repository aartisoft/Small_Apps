package babasaheb.ambedkarstatus.andstatus;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.AudienceNetworkAds;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;


/**
 * A simple {@link Fragment} subclass.
 */
public class StatusFragment extends Fragment {
    RecyclerView status_list;
    StatusAdapter  mAdapter;
    ArrayList<String> statusList;
    private int currentpage = 0;
    private boolean mIsLoadingMore;
    private static final int TOTAL_ITEM_EACH_LOAD = 15;
    String oldestKeyYouveSeen = null;

    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference().child("babasaheb_status");
    ProgressDialog pd;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true);
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        statusList = new ArrayList<>();
        pd = new ProgressDialog(getActivity());
        pd.setMessage("Loading");
        pd.setCancelable(false);
        pd.show();
        this.currentpage = 0;
        this.mIsLoadingMore = false;

        AudienceNetworkAds.initialize(getActivity());
        status_list  = (RecyclerView)view.findViewById(R.id.status_list);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        status_list.setLayoutManager(mLayoutManager);
        status_list.setItemAnimator(new DefaultItemAnimator());
        status_list.setHasFixedSize(true);
        status_list.setOnScrollListener(new EndlessRecyclerOnScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int current_page) {
                if (mIsLoadingMore) {
                    currentpage = current_page;
                    LoadImagedata(current_page);
                }
            }
        });
        mAdapter = new StatusAdapter(getActivity());
        status_list.setAdapter(mAdapter);

        return  view;
    }

    public void LoadImagedata(final int pagenumber) {
        Query jokesQuery;
        if (oldestKeyYouveSeen != null){
            jokesQuery = ref.orderByKey().endAt(oldestKeyYouveSeen).limitToLast(TOTAL_ITEM_EACH_LOAD+1);
        }else{
            jokesQuery = ref.orderByKey().limitToLast(TOTAL_ITEM_EACH_LOAD);
        }

        jokesQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.getChildrenCount() < TOTAL_ITEM_EACH_LOAD) {
                    mIsLoadingMore = false;
                } else {
                    mIsLoadingMore = true;
                }
                Boolean getkeybool = true;
                statusList = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String value=snapshot.child("message").getValue().toString();
                    statusList.add(value);
                    if (getkeybool){
                        getkeybool = false;
                        oldestKeyYouveSeen = snapshot.getKey();
                    }
                }
                if (statusList.size() > 0){
                    Collections.reverse(statusList);
                    if (mIsLoadingMore){
                        statusList.remove(statusList.size() - 1);
                    }
                    mAdapter.adddata(statusList, pagenumber);
                    if (!mIsLoadingMore){
                        mAdapter.setnomoredata();
                    }
                }
                if (pd.isShowing())
                    pd.dismiss();
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
                if (pd.isShowing())
                    pd.dismiss();
            }
        });

    }


    @Override
    public void onResume() {
        super.onResume();
        mIsLoadingMore = true;
        oldestKeyYouveSeen = null;
        currentpage = 0;
        LoadImagedata(currentpage);
    }

}