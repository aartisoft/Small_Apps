package babasaheb.ambedkarstatus.andstatus;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.AudienceNetworkAds;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;


/**
 * A simple {@link Fragment} subclass.
 */
public class ImageFragment extends Fragment {

    RecyclerView status_list;
    ImageAdapter  mAdapter;
    ArrayList<String> mImageThum;
    ArrayList<String> mImagePath;
    private int currentpage = 0;
    private boolean mIsLoadingMore;
    private static final int TOTAL_ITEM_EACH_LOAD = 15;
    String oldestKeyYouveSeen = null;


    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference().child("babasaheb_images");


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        setHasOptionsMenu(true);
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        mImageThum = new ArrayList<>();
        mImagePath = new ArrayList<>();
        AudienceNetworkAds.initialize(getActivity());
        this.currentpage = 0;
        this.mIsLoadingMore = false;
        status_list = view.findViewById(R.id.status_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 2);

        status_list.setLayoutManager(mLayoutManager);
        status_list.setItemAnimator(new DefaultItemAnimator());
        status_list.setHasFixedSize(true);
        status_list.setOnScrollListener(new EndlessRecyclerOnScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int current_page) {
                if (mIsLoadingMore) {
                    currentpage = current_page;
                    LoadImagedata(current_page);
                }
            }
        });
        mAdapter = new ImageAdapter(getActivity());
        status_list.setAdapter(mAdapter);
        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch(mAdapter.getItemViewType(position)){
                    case ImageAdapter.VIEW_TYPE_ITEM:
                        return 1;
                    case ImageAdapter.VIEW_TYPE_LOADING:
                        return 2;
                    default:
                        return -1;
                }
            }
        });

        return view;
    }


    public void LoadImagedata(final int pagenumber) {
        Query jokesQuery;
        if (oldestKeyYouveSeen != null){
            jokesQuery = ref.orderByKey().endAt(oldestKeyYouveSeen).limitToLast(TOTAL_ITEM_EACH_LOAD);
        }else{
            jokesQuery = ref.orderByKey().limitToLast(TOTAL_ITEM_EACH_LOAD);
        }

        jokesQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                mIsLoadingMore = dataSnapshot.getChildrenCount() >= TOTAL_ITEM_EACH_LOAD;
                Boolean getkeybool = true;
                mImageThum = new ArrayList<>();
                mImagePath = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String thum = snapshot.child("thumb").getValue().toString();
                    mImageThum.add(thum);
                    String value = snapshot.child("url").getValue().toString();
                    mImagePath.add(value);
                    if (getkeybool){
                        getkeybool = false;
                        oldestKeyYouveSeen = snapshot.getKey();
                    }
                }
                if (mImageThum.size() > 0) {
                    Collections.reverse(mImageThum);
                    Collections.reverse(mImagePath);
                    if (mIsLoadingMore) {
                        mImageThum.remove(mImageThum.size() - 1);
                        mImagePath.remove(mImagePath.size() - 1);
                    }
                    mAdapter.adddata(mImageThum, mImagePath, pagenumber);
                    if (!mIsLoadingMore) {
                        mAdapter.setnomoredata();
                    }
                }
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }

    @Override
    public void onResume() {
        super.onResume();
        mIsLoadingMore = true;
        oldestKeyYouveSeen = null;
        currentpage = 0;
        LoadImagedata(currentpage);
    }

}