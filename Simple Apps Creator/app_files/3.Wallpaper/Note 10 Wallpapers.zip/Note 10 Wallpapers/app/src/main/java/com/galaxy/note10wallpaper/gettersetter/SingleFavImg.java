package com.galaxy.note10wallpaper.gettersetter;

public class SingleFavImg {


    private String responce;
    private String fav_id;
    private String error;

    public String getResponce() {
        return responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }

    public String getFav_id() {
        return fav_id;
    }

    public void setFav_id(String fav_id) {
        this.fav_id = fav_id;
    }


    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }



    public String toString() {
        return "ClassPojo [responce = " + this.responce + ", fav_id = " + this.fav_id  + ", error = " +   this.error +"]";
    }

}
