package com.galaxy.note10wallpaper.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.galaxy.note10wallpaper.Activity.Home_SingleItem_Activity;
import com.galaxy.note10wallpaper.Adapter.ImageAdapter;
import com.galaxy.note10wallpaper.ConnectionDetector;
import com.galaxy.note10wallpaper.Constant;
import com.galaxy.note10wallpaper.R;
import com.galaxy.note10wallpaper.gettersetter.Item_collection;

import java.util.ArrayList;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class HomemainFragment extends Fragment implements ImageAdapter.MyClickListener {

    Context context;
    private ConnectionDetector detectorconn;
    Boolean conn;
    ArrayList<Item_collection> arrayofimages;
    private ProgressBar progressBar;
    TextView no_data_text;
    Constant constantfile;
    RelativeLayout relaivelayout;
    RecyclerView Image_list;
    ImageAdapter  mAdapter;


    InterstitialAd mInterstitialAd;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference().child("image_collection");

    public HomemainFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.homemainfragment, container, false);
        this.conn = null;

        constantfile = new Constant();
        relaivelayout = (RelativeLayout) rootView.findViewById(R.id.relaivelayout);


        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);

        Image_list = (RecyclerView) rootView.findViewById(R.id.Image_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(),2);
        Image_list.setLayoutManager(mLayoutManager);
        Image_list.setItemAnimator(new DefaultItemAnimator());
        arrayofimages = new ArrayList<Item_collection>();

        mAdapter = new ImageAdapter(getActivity(),arrayofimages);
        mAdapter.setClickListener(this);
        Image_list.setAdapter(mAdapter);

        if (conn.booleanValue()) {
            progressBar.setVisibility(View.VISIBLE);
            Image_list.setVisibility(View.VISIBLE);
            no_data_text.setVisibility(View.GONE);

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    arrayofimages.clear();
                    for (DataSnapshot snapshot:dataSnapshot.getChildren())
                    {
                        Log.e("getfirebasedata",":::  "+snapshot.child("image_thumb").getValue().toString());
                        String key= snapshot.getKey();
                        Item_collection temp = new Item_collection(snapshot.child("image_thumb").getValue().toString().replace("http://","https://"),snapshot.child("image_url").getValue().toString().replace("http://","https://"));
                        arrayofimages.add(0,temp);
                    }
                    progressBar.setVisibility(View.GONE);
                    mAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    progressBar.setVisibility(View.GONE);
                    Image_list.setVisibility(View.GONE);
                    no_data_text.setVisibility(View.VISIBLE);
                    no_data_text.setText("No Images Found");
                }
            });
        } else {
            noInternetConnectionDialog();
        }

        return rootView;
    }


    public void noInternetConnectionDialog() {
        AlertDialog.Builder errorDialog = new AlertDialog.Builder(getActivity());
        errorDialog.setTitle((CharSequence) "Error");
        errorDialog.setMessage((CharSequence) "No internet connection.");
        errorDialog.setNeutralButton((CharSequence) "OK", new dialogclicklistner());
        AlertDialog errorAlert = errorDialog.create();
        errorAlert.show();
        errorAlert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.BLACK);
    }

    @Override
    public void onItemClick(int position, View v) {
        loadInterstitialAd(position);
    }

    class dialogclicklistner implements DialogInterface.OnClickListener {
        dialogclicklistner() {
        }

        public void onClick(DialogInterface dialog, int id) {
            HomemainFragment.this.detectorconn = new ConnectionDetector(HomemainFragment.this.getActivity());
            HomemainFragment.this.conn = Boolean.valueOf(HomemainFragment.this.detectorconn.isConnectingToInternet());
            dialog.dismiss();
        }
    }

    private void loadInterstitialAd(final int pos) {
        final ProgressDialog progress = new ProgressDialog(getActivity());
        progress.setMessage("Loading Ad");
        progress.setCancelable(false);
        progress.show();
        mInterstitialAd = new InterstitialAd(getActivity());
        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstial_id));
        mInterstitialAd.setAdListener(new AdListener() {

            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                progress.dismiss();
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                }
            }

            @Override
            public void onAdFailedToLoad(int i) {
                super.onAdFailedToLoad(i);
                if (progress.isShowing()){
                    progress.dismiss();
                }
                Intent catwise = new Intent(getActivity(), Home_SingleItem_Activity.class);
                catwise.putExtra("image_url", arrayofimages.get(pos).getImage_url() + "");
                startActivity(catwise);
                progress.dismiss();
            }

            @Override
            public void onAdClosed() {
                super.onAdClosed();
                if (progress.isShowing()){
                    progress.dismiss();
                }
                Intent catwise = new Intent(getActivity(), Home_SingleItem_Activity.class);
                catwise.putExtra("image_url", arrayofimages.get(pos).getImage_url() + "");
                startActivity(catwise);
                progress.dismiss();
            }
        });

        AdRequest adRequest = new AdRequest.Builder().build();
        mInterstitialAd.loadAd(adRequest);
    }

}
