package com.galaxy.note10wallpaper.gettersetter;

public class SingleLikeImg {


    private String responce;
    private String like_id;
    private String error;

    public String getResponce() {
        return responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }

    public String getLike_id() {
        return like_id;
    }

    public void setLike_id(String like_id) {
        this.like_id = like_id;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }



    public String toString() {
        return "ClassPojo [responce = " + this.responce + ", like_id = " +   this.like_id  + ", error = " +   this.error +"]";
    }

}
