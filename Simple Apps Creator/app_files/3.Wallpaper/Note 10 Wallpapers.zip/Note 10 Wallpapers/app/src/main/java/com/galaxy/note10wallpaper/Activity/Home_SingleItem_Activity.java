package com.galaxy.note10wallpaper.Activity;

import android.Manifest;
import android.app.WallpaperManager;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.galaxy.note10wallpaper.ConnectionDetector;
import com.galaxy.note10wallpaper.Constant;
import com.galaxy.note10wallpaper.DownloadTask;
import com.galaxy.note10wallpaper.R;
import com.squareup.picasso.Picasso;

import java.io.IOException;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Home_SingleItem_Activity extends AppCompatActivity {


    ImageView image_full, back;
    Button submit_download, submit_setwall;
    ProgressBar progressBar;
    private ConnectionDetector detectorconn;
    Boolean conn;
    String image_url;
    RelativeLayout relative;
    Constant constantfile;
    //InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_single_item_activity);

        constantfile = new Constant();
        //Constant.Adscount++;
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                image_url = null;
            } else {
                image_url = extras.getString("image_url");
            }
        } else {
            image_url = (String) savedInstanceState.getSerializable("image_url");
        }


        relative = (RelativeLayout) findViewById(R.id.relative);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        image_full = (ImageView) findViewById(R.id.image_full);
        back = (ImageView) findViewById(R.id.back);
        submit_download = (Button) findViewById(R.id.submit_download);
        submit_setwall = (Button) findViewById(R.id.submit_setwall);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        submit_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        //      imageDownloader.writeToDisk(ImageSingleActivity.this, mData.get(cposition), "FathersDay");

                        if (conn.booleanValue()) {
                            new DownloadTask(Home_SingleItem_Activity.this, image_url, "download");
                        } else {
                            constantfile.snackbarcommonrelative(Home_SingleItem_Activity.this, relative, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.");
                        }
                        //Toast.makeText(ImageSingleActivity.this, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.", Toast.LENGTH_SHORT).show();


                    }
                }
            }
        });

        submit_setwall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        if (conn.booleanValue()){
                            new DownloadTask(Home_SingleItem_Activity.this, image_url, "setas");
                        }
                        else {
                            constantfile.snackbarcommonrelative(Home_SingleItem_Activity.this, relative, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.");
                        }

                    }
                }
            }
        });

        Glide.with(Home_SingleItem_Activity.this)
                .load(image_url)
                .error(R.drawable.error)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        // log exception
                        progressBar.setVisibility(View.GONE);
                        return false; // important to return false so the error placeholder can be placed
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                        progressBar.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(image_full);

//        mInterstitialAd = new InterstitialAd(Home_SingleItem_Activity.this);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstial_id));
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                requestNewInterstitial();
//            }
//        });
//
//        if (Constant.Adscount == 2) {
//            requestNewInterstitial();
//            mInterstitialAd.setAdListener(new AdListener() {
//                public void onAdLoaded() {
//                    if (mInterstitialAd.isLoaded()) {
//                        mInterstitialAd.show();
//                    }
//                }
//            });
//            Constant.Adscount = 0;
//        }


    }

    private boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }


    @Override
    public void onBackPressed() {
        this.finish();
    }

//
//    private void requestNewInterstitial() {
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mInterstitialAd.loadAd(adRequest);
//    }

}
