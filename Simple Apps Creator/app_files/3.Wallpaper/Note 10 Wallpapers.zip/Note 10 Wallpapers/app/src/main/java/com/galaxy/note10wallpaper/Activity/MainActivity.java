package com.galaxy.note10wallpaper.Activity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.galaxy.note10wallpaper.ConnectionDetector;
import com.galaxy.note10wallpaper.Constant;
import com.galaxy.note10wallpaper.CustomTypefaceSpan;
import com.galaxy.note10wallpaper.Fragment.FeedbackFragment;
import com.galaxy.note10wallpaper.Fragment.HomemainFragment;
import com.galaxy.note10wallpaper.Fragment.PrivacyPolicyFragment;
import com.galaxy.note10wallpaper.R;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    TextView tool_title;
    ImageView drawer_back;
    Toolbar toolbar;
    private ConnectionDetector detectorconn;
    Boolean conn;
    private int fragmentposition = 0;
    Constant constantfile;
    String title_text = "Note 10 Wallpaper";
    DrawerLayout drawer_layout;
    private AlertDialog alert;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        tool_title = (TextView) toolbar.findViewById(R.id.tool_title);

        this.conn = null;
        constantfile = new Constant();
        drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        drawer_back = (ImageView) navigationView.findViewById(R.id.drawer_back);

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        Menu m = navigationView.getMenu();
        for (int i = 0; i < m.size(); i++) {
            MenuItem mi = m.getItem(i);

            SubMenu subMenu = mi.getSubMenu();
            if (subMenu != null && subMenu.size() > 0) {
                for (int j = 0; j < subMenu.size(); j++) {
                    MenuItem subMenuItem = subMenu.getItem(j);
                    applyFontToMenuItem(subMenuItem);
                }
            }

            applyFontToMenuItem(mi);
        }

        SelectItem(title_text,fragmentposition);
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            AppExit();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();


        if (id == R.id.nav_home) {
            fragmentposition = 0;
            title_text = "Note 10 Wallpaper";
        } else if (id == R.id.nav_rate_us) {
            getRateAppCounter();
        } else if (id == R.id.nav_share_app) {
            getShareCounter();
        } else if (id == R.id.nav_contact_us) {
            fragmentposition = 1;
            title_text = "Contact Us";
        } else if (id == R.id.nav_policy) {
            fragmentposition = 2;
            title_text = "Privacy Policy";
        } else if (id == R.id.nav_exit_app) {
            AppExit();
        }
        SelectItem(title_text,fragmentposition);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void SelectItem(String title,int fragmentpos) {
        fragmentposition = fragmentpos;
        tool_title.setText(title);
        Fragment fragment = null;
        if (fragmentpos < 0) {
            return;
        } else {
            if (fragmentpos == 0) {
                fragment = new HomemainFragment();
            } else if (fragmentpos == 1) {
                fragment = new FeedbackFragment();
            } else if (fragmentpos == 2) {
                fragment = new PrivacyPolicyFragment();
            }

        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_main, fragment).commit();
        }

    }

    private void applyFontToMenuItem(MenuItem mi) {
        Typeface font = Typeface.createFromAsset(getAssets(), "the_brooklyn.ttf");
        SpannableString mNewTitle = new SpannableString(mi.getTitle());
        mNewTitle.setSpan(new CustomTypefaceSpan("", font), 0, mNewTitle.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE);
        mi.setTitle(mNewTitle);

    }


    public void getRateAppCounter() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void getShareCounter() {
        constantfile.snackbarcommondrawerLayout(MainActivity.this, drawer_layout, "Processing");
        String whatsAppMessage = "This Message From Note 10 Wallpaper:\n\n";
        whatsAppMessage = whatsAppMessage + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName() + "\n";
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);

    }


    public void AppExit() {
        LayoutInflater inflater = getLayoutInflater().from(MainActivity.this);
        View promptView1 = inflater.inflate(R.layout.alert_logout, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);

        alert = alertDialogBuilder.create();
        alert.setView(promptView1);
        alert.setCancelable(true);
        TextView tv_dmsg = (TextView) promptView1.findViewById(R.id.tv_dmsg);
        Button bt_yes = (Button) promptView1.findViewById(R.id.bt_yes);
        Button bt_no = (Button) promptView1.findViewById(R.id.bt_no);
        bt_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                System.exit(0);
            }
        });
        bt_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alert.dismiss();
            }
        });
        alert.show();
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.
                INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        return true;
    }


}