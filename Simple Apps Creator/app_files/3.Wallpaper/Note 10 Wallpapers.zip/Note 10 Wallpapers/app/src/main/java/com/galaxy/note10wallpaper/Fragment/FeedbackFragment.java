package com.galaxy.note10wallpaper.Fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.galaxy.note10wallpaper.Activity.MainActivity;
import com.galaxy.note10wallpaper.Constant;
import com.galaxy.note10wallpaper.R;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

/**
 * Created by Kakadiyas on 12-03-2017.
 */

public class FeedbackFragment extends Fragment {


    EditText feedback_subject, feedback_edit;
    Button submit_feedback;
    RelativeLayout relaivelayout;
    Constant constantfile;


    public FeedbackFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.feedbackfragment, container, false);

        constantfile = new Constant();
        relaivelayout = (RelativeLayout) rootView.findViewById(R.id.relaivelayout);
        feedback_subject = (EditText) rootView.findViewById(R.id.feedback_subject);
        feedback_edit = (EditText) rootView.findViewById(R.id.feedback_edit);
        submit_feedback = (Button) rootView.findViewById(R.id.submit_feedback);

        AdView mAdView = (AdView) rootView.findViewById(R.id.adView);
        //     mAdView.setAdSize(AdSize.SMART_BANNER);
        //   mAdView.setAdUnitId(getString(R.string.banner_id));
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        submit_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (feedback_edit.getText().length() > 10) {
                    Intent email = new Intent(Intent.ACTION_SEND);
                    email.putExtra(Intent.EXTRA_EMAIL, new String[]{"simpleappscreator@gmail.com"});
                    email.putExtra(Intent.EXTRA_SUBJECT, feedback_subject.getText().toString() + "");
                    email.putExtra(Intent.EXTRA_TEXT, feedback_edit.getText().toString() + "");
                    //need this to prompts email client only
                    email.setType("message/rfc822");
                    startActivity(Intent.createChooser(email, "Choose an Email client :"));
                } else {
                    constantfile.snackbarcommonrelative(getActivity(), relaivelayout, "please write feedback");
                }
            }
        });


        return rootView;
    }


    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity) getActivity()).SelectItem("Note 10 Wallpaper", 0);
                }
                return true;
            }
        });

    }
}

