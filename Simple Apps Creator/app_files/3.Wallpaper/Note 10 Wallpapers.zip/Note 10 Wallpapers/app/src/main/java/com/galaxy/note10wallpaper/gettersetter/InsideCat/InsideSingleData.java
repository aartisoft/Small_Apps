package com.galaxy.note10wallpaper.gettersetter.InsideCat;

import java.util.ArrayList;

public class InsideSingleData {

    private String owner_name;
    private String owner_contact;
    private ArrayList<InsideSingle> data;
    private ArrayList<String> extra_image;
    private String paymentcash;
    private String business_like;
    private String like_id;
    private String business_fav;
    private String fav_id;
    private String renewal_type;
    private String responce;


    public String getOwner_name() {
        return owner_name;
    }

    public void setOwner_name(String owner_name) {
        this.owner_name = owner_name;
    }

    public String getOwner_contact() {
        return owner_contact;
    }

    public void setOwner_contact(String owner_contact) {
        this.owner_contact = owner_contact;
    }

    public ArrayList<InsideSingle> getData() {
        return data;
    }

    public void setData(ArrayList<InsideSingle> data) {
        this.data = data;
    }

    public ArrayList<String> getExtra_image() {
        return extra_image;
    }

    public void setExtra_image(ArrayList<String> extra_image) {
        this.extra_image = extra_image;
    }

    public String getPaymentcash() {
        return paymentcash;
    }

    public void setPaymentcash(String paymentcash) {
        this.paymentcash = paymentcash;
    }

    public String getBusiness_like() {
        return business_like;
    }

    public void setBusiness_like(String business_like) {
        this.business_like = business_like;
    }

    public String getLike_id() {
        return like_id;
    }

    public void setLike_id(String like_id) {
        this.like_id = like_id;
    }

    public String getBusiness_fav() {
        return business_fav;
    }

    public void setBusiness_fav(String business_fav) {
        this.business_fav = business_fav;
    }

    public String getFav_id() {
        return fav_id;
    }

    public void setFav_id(String fav_id) {
        this.fav_id = fav_id;
    }

    public String getRenewal_type() {
        return renewal_type;
    }

    public void setRenewal_type(String renewal_type) {
        this.renewal_type = renewal_type;
    }

    public String getResponce() {
        return responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }



    public String toString() {
        return "ClassPojo [data = " + this.data + ", extra_image = " + this.extra_image +   ", paymentcash = " + this.paymentcash +    ", owner_name = " + this.owner_name +   ", owner_contact = " + this.owner_contact +  ", business_like = " + this.business_like +  ", like_id = " + this.like_id +  ", business_fav = " + this.business_fav +  ", fav_id = " + this.fav_id +  ", renewal_type = " + this.renewal_type  +  ", responce = " + this.responce + "]";
    }
}
