package com.galaxy.note10wallpaper.gettersetter.Home;

public class HomeCatImg {

    private String categories_id;
    private String categories_name;
    private String categories_img;
    private String city;
    private String timestamp;


    public String getCategories_id() {
        return categories_id;
    }

    public void setCategories_id(String categories_id) {
        this.categories_id = categories_id;
    }

    public String getCategories_name() {
        return categories_name;
    }

    public void setCategories_name(String categories_name) {
        this.categories_name = categories_name;
    }

    public String getCategories_img() {
        return categories_img;
    }

    public void setCategories_img(String categories_img) {
        this.categories_img = categories_img;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }


    public String toString() {
        return "ClassPojo [categories_id = " + this.categories_id + ", categories_name = " + this.categories_name +  ", categories_img = " + this.categories_img +  ", city = " + this.city + ", timestamp = " + this.timestamp + "]";
    }

}
