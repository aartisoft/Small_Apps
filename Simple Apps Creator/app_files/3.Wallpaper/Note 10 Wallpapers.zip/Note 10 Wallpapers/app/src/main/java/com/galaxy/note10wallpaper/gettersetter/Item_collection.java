package com.galaxy.note10wallpaper.gettersetter;

public class Item_collection {

	private String image_thumb;
	private String image_url;

	public Item_collection(String image_thumb,String image_url) {
		this.image_thumb=image_thumb;
		this.image_url=image_url;
	}

	public Item_collection() {
	}


	public String getImage_thumb() {
		return image_thumb;
	}

	public void setImage_thumb(String image_thumb) {
		this.image_thumb = image_thumb;
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

}
