package com.galaxy.note10wallpaper.gettersetter.Home;

import java.util.ArrayList;

public class HomeCatimgData {


    private ArrayList<HomeCatImg> data;
    private String responce;

    public ArrayList<HomeCatImg> getData() {
        return data;
    }

    public void setData(ArrayList<HomeCatImg> data) {
        this.data = data;
    }

    public String getResponce() {
        return this.responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }


    public String toString() {
        return "ClassPojo [data = " + this.data + ", responce = " + this.responce + "]";
    }
}
