package com.galaxy.note10wallpaper.gettersetter;

public class RateusData {

    private String responce;
    private String error;

    public String getResponce() {
        return this.responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }


    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }



    public String toString() {
        return "ClassPojo [error = " + this.error + ", responce = " + this.responce + "]";
    }
}
