package com.redmik30.wallpapers.amoled.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdListener;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.redmik30.wallpapers.amoled.Adapter.FavItemsAdapter;
import com.redmik30.wallpapers.amoled.ConnectionDetector;
import com.redmik30.wallpapers.amoled.Constant;
import com.redmik30.wallpapers.amoled.DbAdapter;
import com.redmik30.wallpapers.amoled.EndlessRecyclerOnScrollListener;
import com.redmik30.wallpapers.amoled.Float.FloatingActionButton;
import com.redmik30.wallpapers.amoled.R;
import com.redmik30.wallpapers.amoled.Utility;
import com.redmik30.wallpapers.amoled.gettersetter.ItemUpdate;
import com.redmik30.wallpapers.amoled.gettersetter.Item_collections;

import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

import static com.redmik30.wallpapers.amoled.Constant.actiondownload;
import static com.redmik30.wallpapers.amoled.Constant.actionsetas;
import static com.redmik30.wallpapers.amoled.Constant.passing_object;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class FavoriteList_Activity extends AppCompatActivity implements FavItemsAdapter.MyClickListener{


    ImageView back;
    ProgressBar progressBar;
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    RelativeLayout content_favorite;
    ArrayList<Item_collections> fav_item_list;
    RecyclerView Image_list;
    TextView no_data_text;
    FavItemsAdapter mainAdapter;
    DbAdapter db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorite_list_activity);

        constantfile = new Constant();

        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());


        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        back = (ImageView) findViewById(R.id.back);
        no_data_text = (TextView) findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);

        Image_list = (RecyclerView) findViewById(R.id.Image_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(FavoriteList_Activity.this,3);
        Image_list.setLayoutManager(mLayoutManager);
        Image_list.setItemAnimator(new DefaultItemAnimator());
        Image_list.setHasFixedSize(true);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });



    }


    private void showData() {
        db = new DbAdapter(FavoriteList_Activity.this);
        db.open();
        fav_item_list = new ArrayList<Item_collections>();
        Cursor row = db.fetchAllData();
        for (row.moveToFirst(); !row.isAfterLast(); row.moveToNext()) {
            Item_collections temp_item = new Item_collections();
            temp_item.setId(row.getString(row.getColumnIndex("item_id")));
            temp_item.setWall_name(row.getString(row.getColumnIndex("item_name")));
            temp_item.setWallpaper_image(row.getString(row.getColumnIndex("image")));
            temp_item.setWallpaper_image_thumb(row.getString(row.getColumnIndex("image_thumb")));
            temp_item.setTotal_views("total_views");
            temp_item.setTotal_download("total_downloads");
            temp_item.setDate("date");
            temp_item.setWall_tags("wall_tags");

            fav_item_list.add(temp_item);
        }

        int ii = fav_item_list.size();
        if (ii <= 0) {
            no_data_text.setVisibility(View.VISIBLE);
            Image_list.setVisibility(View.GONE);
        } else {
            Image_list.setVisibility(View.VISIBLE);
            no_data_text.setVisibility(View.GONE);
            setAdapterToListview();
        }
        progressBar.setVisibility(View.GONE);
    }

    public void setAdapterToListview() {
        mainAdapter = new FavItemsAdapter(FavoriteList_Activity.this, fav_item_list);
        mainAdapter.setClickListener(this);
        Image_list.setAdapter(mainAdapter);
    }


    @Override
    public void onResume() {
        super.onResume();
        showData();

    }


    @Override
    public void onBackPressed() {
        this.finish();
    }


    @Override
    public void onItemClick(int position, String ImgUrl, ArrayList<Item_collections> passarray, View v) {
        passing_object = new Item_collections();
        passing_object = passarray.get(position);
        callnextscreen(ImgUrl);
    }

    public void callnextscreen(String imgURL){
        Intent catwise = new Intent(FavoriteList_Activity.this, Fav_SingleItem_Activity.class);
        catwise.putExtra("image_url", imgURL + "");
        startActivity(catwise);
    }
}
