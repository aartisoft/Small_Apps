package com.mi9t.k20prowallpapers.gettersetter.login;

public class TermsData {

    private String error;
    private String responce;
    private String data;

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getResponce() {
        return this.responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }


    public String toString() {
        return "ClassPojo [error = " + this.error + ", responce = " + this.responce + ", data = " + this.data + "]";
    }
}
