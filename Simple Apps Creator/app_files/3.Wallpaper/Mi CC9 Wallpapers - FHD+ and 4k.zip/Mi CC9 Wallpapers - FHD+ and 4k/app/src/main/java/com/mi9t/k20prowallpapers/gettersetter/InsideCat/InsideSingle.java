package com.mi9t.k20prowallpapers.gettersetter.InsideCat;

public class InsideSingle {

    private String business_id;
    private String member_id;
    private String business_logo;
    private String business_name;
    private String business_discount;
    private String business_offer_detail;
    private String business_category;
    private String business_subcategory;
    private String business_address;
    private String business_area;
    private String business_city;
    private String business_status;
    private String business_payment_status;
    private String business_favorite;
    private String business_like;
    private String timestamp;


    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getBusiness_id() {
        return business_id;
    }

    public void setBusiness_id(String business_id) {
        this.business_id = business_id;
    }

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public String getBusiness_logo() {
        return business_logo;
    }

    public void setBusiness_logo(String business_logo) {
        this.business_logo = business_logo;
    }

    public String getBusiness_name() {
        return business_name;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    public String getBusiness_discount() {
        return business_discount;
    }

    public void setBusiness_discount(String business_discount) {
        this.business_discount = business_discount;
    }

    public String getBusiness_offer_detail() {
        return business_offer_detail;
    }

    public void setBusiness_offer_detail(String business_offer_detail) {
        this.business_offer_detail = business_offer_detail;
    }

    public String getBusiness_category() {
        return business_category;
    }

    public void setBusiness_category(String business_category) {
        this.business_category = business_category;
    }

    public String getBusiness_subcategory() {
        return business_subcategory;
    }

    public void setBusiness_subcategory(String business_subcategory) {
        this.business_subcategory = business_subcategory;
    }

    public String getBusiness_address() {
        return business_address;
    }

    public void setBusiness_address(String business_address) {
        this.business_address = business_address;
    }

    public String getBusiness_area() {
        return business_area;
    }

    public void setBusiness_area(String business_area) {
        this.business_area = business_area;
    }

    public String getBusiness_city() {
        return business_city;
    }

    public void setBusiness_city(String business_city) {
        this.business_city = business_city;
    }

    public String getBusiness_status() {
        return business_status;
    }

    public void setBusiness_status(String business_status) {
        this.business_status = business_status;
    }

    public String getBusiness_payment_status() {
        return business_payment_status;
    }

    public void setBusiness_payment_status(String business_payment_status) {
        this.business_payment_status = business_payment_status;
    }

    public String getBusiness_favorite() {
        return business_favorite;
    }

    public void setBusiness_favorite(String business_favorite) {
        this.business_favorite = business_favorite;
    }

    public String getBusiness_like() {
        return business_like;
    }

    public void setBusiness_like(String business_like) {
        this.business_like = business_like;
    }


    public String toString() {
        return "ClassPojo [business_id = " + this.business_id + ", member_id = " + this.member_id +  ", business_logo = " + this.business_logo +  ", business_name = " + this.business_name + ", business_discount = " + this.business_discount +  ", business_offer_detail = " + this.business_offer_detail +  ", business_category = " + this.business_category + ", business_subcategory = " + this.business_subcategory +  ", business_address = " + this.business_address +  ", business_area = " + this.business_area + ", business_city = " + this.business_city +  ", business_status = " + this.business_status +  ", business_payment_status = " + this.business_payment_status +  ", business_favorite = " + this.business_favorite + ", business_like = " + this.business_like + ", timestamp = " + this.timestamp + "]";
    }

}
