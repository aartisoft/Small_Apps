package com.mi9t.k20prowallpapers.gettersetter;

public class SingleUnFavImg {


    private String responce;
    private String error;

    public String getResponce() {
        return responce;
    }

    public void setResponce(String responce) {
        this.responce = responce;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }



    public String toString() {
        return "ClassPojo [responce = " + this.responce + ", error = " + this.error + "]";
    }


}
