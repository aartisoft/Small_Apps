package com.mi9t.k20prowallpapers.gettersetter.login;

public class LoginInfo {
    private String member_id;
    private String member_name;
    private String member_photo;
    private String member_phone;
    private String member_email;
    private String member_status;
    private String member_unique_no;
    private String city_name;
    private String member_city_id;
    private String area_name;
    private String member_area_id;

    public String getMember_id() {
        return member_id;
    }

    public void setMember_id(String member_id) {
        this.member_id = member_id;
    }

    public String getMember_name() {
        return member_name;
    }

    public void setMember_name(String member_name) {
        this.member_name = member_name;
    }

    public String getMember_photo() {
        return member_photo;
    }

    public void setMember_photo(String member_photo) {
        this.member_photo = member_photo;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getMember_phone() {
        return member_phone;
    }

    public void setMember_phone(String member_phone) {
        this.member_phone = member_phone;
    }

    public String getMember_email() {
        return member_email;
    }

    public void setMember_email(String member_email) {
        this.member_email = member_email;
    }

    public String getMember_status() {
        return member_status;
    }

    public void setMember_status(String member_status) {
        this.member_status = member_status;
    }

    public String getMember_unique_no() {
        return member_unique_no;
    }

    public void setMember_unique_no(String member_unique_no) {
        this.member_unique_no = member_unique_no;
    }



    public String getMember_city_id() {
        return member_city_id;
    }

    public void setMember_city_id(String member_city_id) {
        this.member_city_id = member_city_id;
    }


    public String getMember_area_id() {
        return member_area_id;
    }

    public void setMember_area_id(String member_area_id) {
        this.member_area_id = member_area_id;
    }



    public String toString() {
        return "ClassPojo [member_id = " + this.member_id + ", member_name = " + this.member_name + ", member_photo = " + this.member_photo + ", member_phone = " + this.member_phone + ", member_email = " + this.member_email + ", member_status = " + this.member_status + ", member_unique_no = " + this.member_unique_no + ", member_city = " + this.city_name + ", city_name = " + this.member_city_id + ", area_name = " + this.area_name + ", member_area_id = " + this.member_area_id + "]";
    }
}
