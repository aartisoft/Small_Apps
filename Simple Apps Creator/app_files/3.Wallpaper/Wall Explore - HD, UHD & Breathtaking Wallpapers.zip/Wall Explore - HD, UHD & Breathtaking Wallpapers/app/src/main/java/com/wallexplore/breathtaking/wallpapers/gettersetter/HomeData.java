package com.wallexplore.breathtaking.wallpapers.gettersetter;

import java.util.ArrayList;

public class HomeData {

    private boolean status;
    private String message;
    private String dope_background;
    private ArrayList<Item_collections> trending_list;
    private ArrayList<Item_collections> latest_list;
    private ArrayList<Item_category> category_list;


    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDope_background() {
        return dope_background;
    }

    public void setDope_background(String dope_background) {
        this.dope_background = dope_background;
    }

    public ArrayList<Item_collections> getTrending_list() {
        return trending_list;
    }

    public void setTrending_list(ArrayList<Item_collections> trending_list) {
        this.trending_list = trending_list;
    }

    public ArrayList<Item_collections> getLatest_list() {
        return latest_list;
    }

    public void setLatest_list(ArrayList<Item_collections> latest_list) {
        this.latest_list = latest_list;
    }

    public ArrayList<Item_category> getCategory_list() {
        return category_list;
    }

    public void setCategory_list(ArrayList<Item_category> category_list) {
        this.category_list = category_list;
    }



    public String toString() {
        return "ClassPojo [status = " + this.status + ", message = " + this.message +  ", dope_background = " + this.dope_background +  ", trending_list = " + this.trending_list +  ", latest_list = " + this.latest_list + ", category_list = " + this.category_list + "]";
    }
}
