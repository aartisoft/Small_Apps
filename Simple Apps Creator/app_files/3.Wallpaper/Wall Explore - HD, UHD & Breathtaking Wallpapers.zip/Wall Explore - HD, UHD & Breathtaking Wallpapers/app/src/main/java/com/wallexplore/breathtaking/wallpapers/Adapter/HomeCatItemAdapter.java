package com.wallexplore.breathtaking.wallpapers.Adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.wallexplore.breathtaking.wallpapers.R;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_category;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HomeCatItemAdapter extends RecyclerView.Adapter<HomeCatItemAdapter.DataObjectHolder> {

    List<Item_category> mRecyclerViewItems = new ArrayList<>();

    private static String LOG_TAG = "HomeCatItemAdapter";
    private static MyClickListener myClickListener;
    private Context context;
    int[] androidColors;

    public static class DataObjectHolder extends RecyclerView.ViewHolder {

        ImageView category_back;
        TextView category_name;

        public DataObjectHolder(View itemView) {
            super(itemView);
            category_back = (ImageView) itemView.findViewById(R.id.category_back);
            category_name = (TextView) itemView.findViewById(R.id.category_name);

        }

    }

    public HomeCatItemAdapter(Context context) {
        this.context = context;
        mRecyclerViewItems = new ArrayList<>();
        androidColors = context.getResources().getIntArray(R.array.colors);
    }

    public void adddata(List<Item_category> data, int pagenumber) {
        if (pagenumber == 1) {
            mRecyclerViewItems.clear();
            mRecyclerViewItems.addAll(data);
        } else {
            mRecyclerViewItems.addAll(data);
        }
        notifyDataSetChanged();
    }


    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_item_category, parent, false);
        ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        int width = (int) (parent.getWidth() / 4.9);
        layoutParams.width = width;
        v.setLayoutParams(layoutParams);
        DataObjectHolder dataobject = new DataObjectHolder(v);
        return dataobject;
    }


    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {


        final Item_category itemobj = (Item_category) mRecyclerViewItems.get(position);

        holder.category_name.setText(itemobj.getCategory_name());
        //int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
        int randomAndroidColor = androidColors[position % androidColors.length];
        //holder.category_back.setBackgroundColor(randomAndroidColor);
        holder.category_back.setColorFilter(randomAndroidColor, android.graphics.PorterDuff.Mode.MULTIPLY);

        holder.category_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myClickListener.onCatItemClick(position, itemobj,v);
            }
        });


    }



    @Override
    public int getItemCount() {
        return mRecyclerViewItems.size();
    }


    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    public interface MyClickListener {
        public void onCatItemClick(int position, Item_category passdata, View v);
    }

}
