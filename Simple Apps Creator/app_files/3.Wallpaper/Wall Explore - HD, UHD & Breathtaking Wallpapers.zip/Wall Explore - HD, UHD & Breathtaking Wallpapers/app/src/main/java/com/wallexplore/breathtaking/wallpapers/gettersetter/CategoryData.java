package com.wallexplore.breathtaking.wallpapers.gettersetter;

import java.util.ArrayList;

public class CategoryData {

    private boolean status;
    private String message;
    private ArrayList<Item_category> category_list;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<Item_category> getCategory_list() {
        return category_list;
    }

    public void setCategory_list(ArrayList<Item_category> category_list) {
        this.category_list = category_list;
    }



    public String toString() {
        return "ClassPojo [status = " + this.status + ", message = " + this.message + ", category_list = " + this.category_list + "]";
    }
}
