package com.wallexplore.breathtaking.wallpapers.Activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.android.material.snackbar.Snackbar;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wallexplore.breathtaking.wallpapers.ConnectionDetector;
import com.wallexplore.breathtaking.wallpapers.Constant;
import com.wallexplore.breathtaking.wallpapers.DbAdapter;
import com.wallexplore.breathtaking.wallpapers.R;
import com.wallexplore.breathtaking.wallpapers.Utility;
import com.wallexplore.breathtaking.wallpapers.gettersetter.ItemUpdate;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_Favgetset;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_collections;
import com.wallexplore.breathtaking.wallpapers.widgets.EnchantedViewPager;

import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;


public class FavDetailActivity extends Activity  implements Constant.Callingafterads{

    public static final String EXTRA_IMAGE_URL = "detailImageUrl";

    public static final String IMAGE_TRANSITION_NAME = "transitionImage";

    private ImageView goto_back, goto_favorite;
    private TextView action_download, action_share;
    private RelativeLayout actionset_rl;
    private LinearLayout detail_rl;

    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;

    AlertDialog alertDialog;

    RelativeLayout topbar_rl;
    LinearLayout action_ll;

    EnchantedViewPager mViewPager;
    CustomViewPagerAdapter mAdapter;
    ArrayList<Item_Favgetset> detail_item_list;
    int detail_position;
    String ActionTypepass = "";
    DbAdapter db;
    Boolean isFullsreen = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        this.conn = null;
        constantfile = new Constant();
        this.detectorconn = new ConnectionDetector(FavDetailActivity.this);
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        db = new DbAdapter(FavDetailActivity.this);
        db.open();

        mViewPager = findViewById(R.id.viewPager);
        action_ll = (LinearLayout) findViewById(R.id.action_ll);
        topbar_rl = (RelativeLayout) findViewById(R.id.topbar_rl);
        detail_rl = (LinearLayout) findViewById(R.id.detail_rl);
        actionset_rl = (RelativeLayout) findViewById(R.id.actionset_rl);
        goto_back = (ImageView) findViewById(R.id.goto_back);
        goto_favorite = (ImageView) findViewById(R.id.goto_favorite);
        action_download = (TextView) findViewById(R.id.action_download);
        action_share = (TextView) findViewById(R.id.action_share);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        showSystemUI();

        goto_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        goto_favorite.setImageResource(R.drawable.ic_favorite_done);

        goto_favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Item_Favgetset temp_get = detail_item_list.get(detail_position);
                String uniqueid = temp_get.getId();
                if(db.isExist(uniqueid)){
                    db.delete(uniqueid);
                    detail_item_list.remove(detail_position);
                    mAdapter.notifyDataSetChanged();
                    if (detail_item_list.size() <= 0){
                        onBackPressed();
                    }else{
                        mAdapter.notifyDataSetChanged();
                        detail_position = mViewPager.getCurrentItem();
                    }
                    constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, "Remove from Favourite Successfully!");
                }else{
                    constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, "No Image Found!");
                }
            }
        });

        action_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setdisableclick();
                ActionTypepass = Constant.share_download;
                Actionclickworking();
            }
        });

        action_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setdisableclick();
                ActionTypepass = Constant.share_other;
                Actionclickworking();
            }
        });

        actionset_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setdisableclick();
                ActionTypepass = Constant.share_set;
                Actionclickworking();
            }
        });

        showData();
    }

    public void setdisableclick(){
        action_download.setClickable(false);
        action_share.setClickable(false);
        actionset_rl.setClickable(false);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                action_download.setClickable(true);
                action_share.setClickable(true);
                actionset_rl.setClickable(true);
            }
        }, 2000);
    }




    private void showData() {
        detail_item_list = new ArrayList<>();
        detail_item_list.addAll(Constant.Passing_item_favorite);
        int ii = detail_item_list.size();
        if (ii == 0) {
            onBackPressed();
        }
        detail_position = getIndexByProperty(Constant.Passing_item_id);
        setAdapterToListview();
    }


    public void setAdapterToListview() {
        mAdapter = new CustomViewPagerAdapter();
        mViewPager.useScale();
        mViewPager.removeAlpha();
        mViewPager.setAdapter(mAdapter);

        if (detail_position != -1) {
            mViewPager.setCurrentItem(detail_position);
            goto_favorite.setImageResource(R.drawable.ic_favorite_done);
        }

        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                detail_position = i;
            }

            @Override
            public void onPageScrollStateChanged(int i) {
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    public void Actionclickworking() {

        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (this.conn.booleanValue()) {
            boolean result = Utility.checkPermission(FavDetailActivity.this);
            if (result) {
                if (Constant.Passing_type.equals("1")){
                    showAdsPredialog();
                }else {
                    constantfile.showporgressdialog(FavDetailActivity.this, ActionTypepass);
                    if (ActionTypepass.equals(Constant.share_set)) {
                        constantfile.share_image(FavDetailActivity.this, Constant.share_set, detail_item_list.get(detail_position).getWallpaper_image(), detail_rl);

                    } else if (ActionTypepass.equals(Constant.share_other)) {
                        constantfile.share_image(FavDetailActivity.this, Constant.share_other, detail_item_list.get(detail_position).getWallpaper_image(), detail_rl);

                    } else if (ActionTypepass.equals(Constant.share_download)) {
                        CallAddDownload(detail_item_list.get(detail_position).getId());
                    }
                }
            } else {
                constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, "Please give the permission to download Image!");
            }
        } else {
            snackbarcommonrelativeLong(FavDetailActivity.this, detail_rl, getResources().getString(R.string.no_internet));

        }


    }


    public void calling_hideandshow() {
        if (isFullsreen) {
            isFullsreen = false;
            showSystemUI();
            constantfile.slideUp(action_ll);
            constantfile.slideDownforTop(topbar_rl);
        } else {
            isFullsreen = true;
            hideSystemUI();
            constantfile.slideDown(action_ll);
            constantfile.slideUpforTop(topbar_rl);
        }
    }


    private void hideSystemUI() {
        clickable(false);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private void showSystemUI() {
        clickable(true);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        |View.SYSTEM_UI_FLAG_IMMERSIVE);


    }

    public void clickable(Boolean getvalue){
        actionset_rl.setClickable(getvalue);
        action_share.setClickable(getvalue);
        action_download.setClickable(getvalue);
        goto_favorite.setClickable(getvalue);
        goto_back.setClickable(getvalue);
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Utility.MY_PERMISSIONS_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Actionclickworking();
                } else {
                    constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, "Permission denied to read your External storage!");
                }
                return;
            }
        }
    }

    public void CallAddDownload(String PassID) {
        RequestParams params = new RequestParams();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        client.setTimeout(60000);
        params.put("wallpaper_download_id", PassID);
        client.get(Constant.GET_ADD_DOWNLOAD, params, new AsynchronouseDownloadData());
    }


    class AsynchronouseDownloadData extends JsonHttpResponseHandler {

        AsynchronouseDownloadData() { }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headers, JSONObject bytes) {
            try {

                ItemUpdate statusData = new ItemUpdate();
                statusData.setStatus(bytes.getBoolean("status"));
                statusData.setMessage(bytes.getString("message"));
                if (statusData.isStatus()) {
                    constantfile.share_image(FavDetailActivity.this, Constant.share_download, detail_item_list.get(detail_position).getWallpaper_image(), detail_rl);
                } else {
                    constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, getResources().getString(R.string.not_download));
                }
            } catch (Exception e) {
                constantfile.snackbarcommonlinear(FavDetailActivity.this, detail_rl, getResources().getString(R.string.not_download));
            }


        }

        public void onFailure(int i, Header[] headers, JSONObject bytes, Throwable throwable) {

        }
    }

    @Override
    public void onAdsresponce(Boolean showing) {
        constantfile.showporgressdialog(FavDetailActivity.this,ActionTypepass);
        if (ActionTypepass.equals(Constant.share_set)) {
            constantfile.share_image(FavDetailActivity.this, Constant.share_set, detail_item_list.get(detail_position).getWallpaper_image(), detail_rl);

        } else if (ActionTypepass.equals(Constant.share_other)) {
            constantfile.share_image(FavDetailActivity.this, Constant.share_other, detail_item_list.get(detail_position).getWallpaper_image(), detail_rl);

        } else if (ActionTypepass.equals(Constant.share_download)) {
            CallAddDownload(detail_item_list.get(detail_position).getId());
        }
    }


    public void snackbarcommonrelativeLong(Context mcontext, LinearLayout coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Actionclickworking();
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.white));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_action);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(Color.BLACK);
        textaction.setTextColor(Color.BLACK);
        snackbar.show();
    }

    private class CustomViewPagerAdapter extends PagerAdapter {
        private LayoutInflater inflater;

        private CustomViewPagerAdapter() {
            inflater = getLayoutInflater();
        }

        @Override
        public int getCount() {
            return detail_item_list.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            View detailLayout = inflater.inflate(R.layout.fullscreenitem_layout, container, false);
            assert detailLayout != null;
            final ProgressBar progressBar = (ProgressBar) detailLayout.findViewById(R.id.itemProgressbar);
            progressBar.setVisibility(View.VISIBLE);
            ImageView imageView = (ImageView) detailLayout.findViewById(R.id.image_full);
            Glide.with(FavDetailActivity.this)
                    .load(detail_item_list.get(position).getWallpaper_image())
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            progressBar.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(imageView);

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    calling_hideandshow();
                }
            });

            container.addView(detailLayout, 0);
            return detailLayout;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            (container).removeView((View) object);
        }
    }

    private int getIndexByProperty(String yourString) {
        for (int i = 0; i < detail_item_list.size(); i++) {
            if (detail_item_list != null && detail_item_list.get(i).getId().equals(yourString)) {
                return i;
            }
        }
        return -1;
    }


    public void showAdsPredialog() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this,R.style.MyAlertDialogStyle);
        alertDialogBuilder.setMessage(getResources().getString(R.string.see_alert_title));
        alertDialogBuilder.setPositiveButton("Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        alertDialog.dismiss();
                        callads();
                    }
                });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                alertDialog.dismiss();
            }
        });
        alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }

    public void callads(){
        constantfile.loadRewardadsAd(FavDetailActivity.this,this);
    }
}
