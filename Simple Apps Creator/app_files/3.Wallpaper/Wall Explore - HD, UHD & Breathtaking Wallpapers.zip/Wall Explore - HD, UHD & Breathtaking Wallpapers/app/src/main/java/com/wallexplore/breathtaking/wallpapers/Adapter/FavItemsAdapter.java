package com.wallexplore.breathtaking.wallpapers.Adapter;


import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.wallexplore.breathtaking.wallpapers.R;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_Favgetset;

import java.util.ArrayList;
import java.util.List;

public class FavItemsAdapter extends RecyclerView.Adapter<FavItemsAdapter.DataObjectHolder> {
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private ArrayList<Item_Favgetset> itemsList = new ArrayList<>();
    Activity main;
    private static MyClickListener myClickListener;
    private Context context;

    public static class DataObjectHolder extends RecyclerView.ViewHolder{

        public ImageView image_latest;


        public DataObjectHolder(View itemView) {
            super(itemView);
            image_latest = (ImageView) itemView.findViewById(R.id.image_latest);

        }

    }

    public FavItemsAdapter(Context context, ArrayList<Item_Favgetset> subcategoryList) {
        this.context = context;
        this.itemsList.addAll(subcategoryList);
        notifyDataSetChanged();
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_item_latest, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        int height = (int) (parent.getHeight() / 2.7);
        layoutParams.height = height;
        view.setLayoutParams(layoutParams);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {

        final Item_Favgetset itemobj = (Item_Favgetset) itemsList.get(position);
        Glide.with(context)
                .load(itemobj.getWallpaper_image_thumb())
                .thumbnail(0.10f)
                .placeholder(R.drawable.image_placeholder)
                .into(holder.image_latest);

        holder.image_latest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myClickListener.onItemClick(position,itemobj, v);
            }
        });
    }



    @Override
    public int getItemCount() {
        return itemsList.size();
    }

    public interface MyClickListener {
        void onItemClick(int position,Item_Favgetset pass_getset, View v);
    }

}
