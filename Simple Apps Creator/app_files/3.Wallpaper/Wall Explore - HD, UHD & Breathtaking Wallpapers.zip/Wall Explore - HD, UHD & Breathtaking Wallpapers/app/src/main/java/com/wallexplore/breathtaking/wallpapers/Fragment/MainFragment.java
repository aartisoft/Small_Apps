package com.wallexplore.breathtaking.wallpapers.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wallexplore.breathtaking.wallpapers.Activity.DetailActivity;
import com.wallexplore.breathtaking.wallpapers.Activity.MainActivity;
import com.wallexplore.breathtaking.wallpapers.Adapter.HomeCatItemAdapter;
import com.wallexplore.breathtaking.wallpapers.Adapter.HomeLatestAdapter;
import com.wallexplore.breathtaking.wallpapers.Adapter.HomeTrendingAdapter;
import com.wallexplore.breathtaking.wallpapers.ConnectionDetector;
import com.wallexplore.breathtaking.wallpapers.Constant;
import com.wallexplore.breathtaking.wallpapers.PullRefreshLayout;
import com.wallexplore.breathtaking.wallpapers.R;
import com.wallexplore.breathtaking.wallpapers.gettersetter.HomeData;
import com.wallexplore.breathtaking.wallpapers.gettersetter.ItemData;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_category;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_collections;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class MainFragment extends Fragment implements HomeCatItemAdapter.MyClickListener,Constant.Callingafterads, HomeTrendingAdapter.MyClickListener, HomeLatestAdapter.MyClickListener {

    public static final String TAG = "Main_list";
    private ConnectionDetector detectorconn;
    Boolean conn;
    private Gson gson;
    Constant constantfile;
    private AlertDialog alert;
    private RelativeLayout content_home;
    TextView no_data_text;
    RecyclerView trending_recycler, categories_recycler, latest_recycler;
    TextView trending_viewall, categories_viewall, latest_viewall;
    ProgressBar progressbar,progressbar_latest,progressbar_trending;
    RelativeLayout top_dope_rl;

    HomeCatItemAdapter homecatadapter;
    HomeTrendingAdapter hometrendingadapter;
    HomeLatestAdapter homelatestadapter;
    PullRefreshLayout swipeRefreshLayout;
    ImageView dope_background;
    View rootView;

    public MainFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LoadImagedata();
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView  = inflater.inflate(R.layout.mainhome_fragment, container, false);

        gson = new Gson();
        this.conn = null;
        constantfile = new Constant();
        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_home = (RelativeLayout) rootView.findViewById(R.id.content_mainfragment);
        trending_recycler = (RecyclerView) rootView.findViewById(R.id.trending_recycler);
        categories_recycler = (RecyclerView) rootView.findViewById(R.id.categories_recycler);
        latest_recycler = (RecyclerView) rootView.findViewById(R.id.latest_recycler);
        trending_viewall = (TextView) rootView.findViewById(R.id.trending_viewall);
        categories_viewall = (TextView) rootView.findViewById(R.id.categories_viewall);
        latest_viewall = (TextView) rootView.findViewById(R.id.latest_viewall);
        dope_background = (ImageView) rootView.findViewById(R.id.dope_background);
        progressbar = (ProgressBar) rootView.findViewById(R.id.progressbar);
        progressbar_latest = (ProgressBar) rootView.findViewById(R.id.progressbar_latest);
        progressbar_trending = (ProgressBar) rootView.findViewById(R.id.progressbar_trending);
        progressbar_latest.setVisibility(View.GONE);
        progressbar_trending.setVisibility(View.GONE);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;

        ViewGroup.LayoutParams params = trending_recycler.getLayoutParams();
        params.height = (int) (width / 2.2);
        trending_recycler.setLayoutParams(params);

        ViewGroup.LayoutParams paramscat = categories_recycler.getLayoutParams();
        paramscat.height = (int) (width / 4.9);
        categories_recycler.setLayoutParams(paramscat);

        ViewGroup.LayoutParams paramstrend = latest_recycler.getLayoutParams();
        //paramstrend.height = (int) (width * 0.9);
        paramstrend.height = (int) (height / 1.8);
        latest_recycler.setLayoutParams(paramstrend);

        LinearLayoutManager horizontaltrendingManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        trending_recycler.setLayoutManager(horizontaltrendingManager);
        trending_recycler.setHasFixedSize(true);
        trending_recycler.setItemAnimator(new DefaultItemAnimator());
        hometrendingadapter = new HomeTrendingAdapter(getActivity());
        hometrendingadapter.setClickListener(this);
        trending_recycler.setAdapter(hometrendingadapter);


        LinearLayoutManager horizontalCatManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        categories_recycler.setLayoutManager(horizontalCatManager);
        categories_recycler.setHasFixedSize(true);
        categories_recycler.setItemAnimator(new DefaultItemAnimator());
        homecatadapter = new HomeCatItemAdapter(getActivity());
        homecatadapter.setClickListener(this);
        categories_recycler.setAdapter(homecatadapter);


        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        latest_recycler.setLayoutManager(mLayoutManager);
        latest_recycler.setHasFixedSize(true);
        latest_recycler.setItemAnimator(new DefaultItemAnimator());
        homelatestadapter = new HomeLatestAdapter(getActivity());
        homelatestadapter.setClickListener(this);
        latest_recycler.setAdapter(homelatestadapter);



        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        top_dope_rl = (RelativeLayout) rootView.findViewById(R.id.top_dope_rl);


        top_dope_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).changetitle(getActivity().getResources().getString(R.string.title_dope));
                Fragment fragment = new DopeListingFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.add(R.id.fragment_container, fragment);
                ft.addToBackStack("MainFragment");
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.commit();

            }
        });

        trending_viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).changetitle(getActivity().getResources().getString(R.string.title_trending));
                Fragment fragment = new TrendingListingFragment();
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction ft = fragmentManager.beginTransaction();
                ft.add(R.id.fragment_container, fragment);
                ft.addToBackStack("MainFragment");
                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                ft.commit();
            }
        });
        categories_viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constant.Passing_selected_fragment = 3;
                ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.title_categories),0);
            }
        });
        latest_viewall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Constant.Passing_selected_fragment = 1;
                ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.title_latest),0);
            }
        });


        if (Constant.Passing_from_notification){
            Constant.Passing_From = "MainFragment";
            Fragment fragment = new CategoryWiseListingFragment();
            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
            FragmentTransaction ft = fragmentManager.beginTransaction();
            ft.add(R.id.fragment_container, fragment);
            ft.addToBackStack(Constant.Passing_From);
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
            ft.commit();
        }



        return rootView;
    }



    @Override
    public void onResume() {
        super.onResume();

//        showData();
//
//        getView().setFocusableInTouchMode(true);
//        getView().requestFocus();
//        getView().setOnKeyListener(new View.OnKeyListener() {
//            @Override
//            public boolean onKey(View v, int keyCode, KeyEvent event) {
//                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
//                    ((MainActivity)getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name),0);
//                }
//                return true;
//            }
//        });

    }

    @Override
    public void onCatItemClick(int position, Item_category passdata, View v) {
        Constant.Passing_cat_id = passdata.getCid();
        Constant.Passing_cat_name = passdata.getCategory_name();
        Constant.Passing_From = "MainFragment";
        ((MainActivity) getActivity()).changetitle(passdata.getCategory_name()+"");
        Fragment fragment = new CategoryWiseListingFragment();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.add(R.id.fragment_container, fragment);
        ft.addToBackStack(Constant.Passing_From);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        ft.commit();
    }

    @Override
    public void onLatestItemClick(int position, Item_collections passdata,ArrayList<Item_collections> passarray, View v) {
        Constant.Passing_item_id = passdata.getId();
        passarray.removeAll(Collections.singleton(null));
        Constant.Passing_item_array = new ArrayList<>();
        Constant.Passing_item_array.addAll(passarray);
        if (Constant.Adscount == 2){
            constantfile.loadInterstitialAd(getActivity(),this);
        }else{
            Constant.Adscount++;
            Intent intent = new Intent(getActivity(), DetailActivity.class);
            getActivity().startActivity(intent);
        }
    }

    @Override
    public void onTrendingItemClick(int position, Item_collections passdata,ArrayList<Item_collections> passarray, View v) {
        Constant.Passing_item_id = passdata.getId();
        passarray.removeAll(Collections.singleton(null));
        Constant.Passing_item_array = new ArrayList<>();
        Constant.Passing_item_array.addAll(passarray);
        if (Constant.Adscount == 2){
            constantfile.loadInterstitialAd(getActivity(),this);
        }else{
            Constant.Adscount++;
            Intent intent = new Intent(getActivity(), DetailActivity.class);
            getActivity().startActivity(intent);
        }
    }


    public void LoadImagedata() {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (this.conn.booleanValue()) {
            content_home.setVisibility(View.VISIBLE);
            no_data_text.setVisibility(View.GONE);
            getCategoriesListData();
        } else {
            progressbar_latest.setVisibility(View.GONE);
            progressbar_trending.setVisibility(View.GONE);
            no_data_text.setVisibility(View.VISIBLE);
            content_home.setVisibility(View.GONE);
            snackbarcommonrelativeLong(getActivity(),rootView , getActivity().getResources().getString(R.string.no_internet));

        }

    }


    public void getCategoriesListData() {
        RequestParams params = new RequestParams();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        client.setTimeout(60000);
        params.put("home", "home");
        client.get(Constant.GET_HOME_LISTING, params, new AsynchronouseData());
    }




    class AsynchronouseData extends JsonHttpResponseHandler {

        AsynchronouseData() { }

        public void onStart() {
            super.onStart();
            progressbar_latest.setVisibility(View.VISIBLE);
            progressbar_trending.setVisibility(View.VISIBLE);
            //progressbar.setVisibility(View.VISIBLE);
        }

        public void onSuccess(int i, Header[] headers, JSONObject bytes) {

            try {
                JSONArray getcategory = bytes.getJSONArray("category_list");
                JSONArray gettrending = bytes.getJSONArray("trending_list");
                JSONArray getlatest = bytes.getJSONArray("latest_list");
                HomeData statusData = new HomeData();
                statusData.setStatus(bytes.getBoolean("status"));
                statusData.setMessage(bytes.getString("message"));
                statusData.setDope_background(bytes.getString("dope_background"));
                statusData.setTrending_list(constantfile.ConvertJSONtoModel(gettrending));
                statusData.setCategory_list(constantfile.ConvertCATEGORY_JSONtoModel(getcategory));
                statusData.setLatest_list(constantfile.ConvertJSONtoModel(getlatest));

                ArrayList<Item_collections> temp_trending = new ArrayList<>();
                ArrayList<Item_collections> temp_latest = new ArrayList<>();
                ArrayList<Item_category> temp_cat = new ArrayList<>();

                if (statusData.isStatus()) {
                    if (!statusData.getDope_background().equals("")){
                        Glide.with(getActivity())
                                .load(statusData.getDope_background())
                                .placeholder(R.drawable.dope_back)
                                .into(dope_background);
                    }
                    temp_cat.addAll(statusData.getCategory_list());
                    temp_latest.addAll(statusData.getLatest_list());
                    temp_trending.addAll(statusData.getTrending_list());

                    if (temp_cat.size() == 0 && temp_latest.size() == 0 && temp_trending.size() == 0) {
                        content_home.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                        return;
                    }

                    homecatadapter.adddata(temp_cat, 1);
                    hometrendingadapter.adddata(temp_trending, 1);
                    homelatestadapter.adddata(temp_latest, 1);
                    content_home.setVisibility(View.VISIBLE);
                    no_data_text.setVisibility(View.GONE);
                    progressbar_latest.setVisibility(View.GONE);
                    progressbar_trending.setVisibility(View.GONE);
                } else {
                    progressbar_latest.setVisibility(View.GONE);
                    progressbar_trending.setVisibility(View.GONE);
                    content_home.setVisibility(View.GONE);
                    no_data_text.setVisibility(View.VISIBLE);

                }
            } catch (Exception e) {
                progressbar_latest.setVisibility(View.GONE);
                progressbar_trending.setVisibility(View.GONE);
                content_home.setVisibility(View.GONE);
                no_data_text.setVisibility(View.VISIBLE);
            }


        }

        public void onFailure(int i, Header[] headers, JSONObject bytes, Throwable throwable) {
            progressbar_latest.setVisibility(View.GONE);
            progressbar_trending.setVisibility(View.GONE);
            content_home.setVisibility(View.GONE);
            no_data_text.setVisibility(View.VISIBLE);

        }
    }


    public void snackbarcommonrelativeLong(Context mcontext, View coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoadImagedata();
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.white));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(Color.BLACK);
        textaction.setTextColor(Color.BLACK);
        snackbar.show();
    }


    @Override
    public void onAdsresponce(Boolean showing) {
        Constant.Passing_type = "0";
        Intent intent = new Intent(getActivity(), DetailActivity.class);
        getActivity().startActivity(intent);
    }

}
