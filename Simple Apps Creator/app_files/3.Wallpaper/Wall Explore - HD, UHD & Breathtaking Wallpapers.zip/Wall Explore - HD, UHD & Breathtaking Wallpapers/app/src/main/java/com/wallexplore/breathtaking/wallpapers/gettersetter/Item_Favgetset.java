package com.wallexplore.breathtaking.wallpapers.gettersetter;

public class Item_Favgetset{


    String id;
    String wall_name;
    String wallpaper_image;
    String wallpaper_image_thumb;
    String cat_id;
    String category_name;

    public Item_Favgetset() {
    }

    public Item_Favgetset(String id, String wall_name, String wallpaper_image, String wallpaper_image_thumb, String cat_id, String category_name) {
        this.id = id;
        this.wall_name = wall_name;
        this.wallpaper_image = wallpaper_image;
        this.wallpaper_image_thumb = wallpaper_image_thumb;
        this.cat_id = cat_id;
        this.category_name = category_name;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWall_name() {
        return wall_name;
    }

    public void setWall_name(String wall_name) {
        this.wall_name = wall_name;
    }

    public String getWallpaper_image() {
        return wallpaper_image;
    }

    public void setWallpaper_image(String wallpaper_image) {
        this.wallpaper_image = wallpaper_image;
    }

    public String getWallpaper_image_thumb() {
        return wallpaper_image_thumb;
    }

    public void setWallpaper_image_thumb(String wallpaper_image_thumb) {
        this.wallpaper_image_thumb = wallpaper_image_thumb;
    }

    public String getCat_id() {
        return cat_id;
    }

    public void setCat_id(String cat_id) {
        this.cat_id = cat_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String toString() {
        return "ClassPojo [id = " + this.id + ", wall_name = " + this.wall_name + ", wallpaper_image = " + this.wallpaper_image + ", wallpaper_image_thumb = " + this.wallpaper_image_thumb + ", cat_id = " + this.cat_id + ", category_name = " + this.category_name + "]";
    }
}
