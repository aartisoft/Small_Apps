package com.wallexplore.breathtaking.wallpapers.Fragment;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.wallexplore.breathtaking.wallpapers.Activity.DetailActivity;
import com.wallexplore.breathtaking.wallpapers.Activity.FavDetailActivity;
import com.wallexplore.breathtaking.wallpapers.Activity.MainActivity;
import com.wallexplore.breathtaking.wallpapers.Adapter.FavItemsAdapter;
import com.wallexplore.breathtaking.wallpapers.ConnectionDetector;
import com.wallexplore.breathtaking.wallpapers.Constant;
import com.wallexplore.breathtaking.wallpapers.DbAdapter;
import com.wallexplore.breathtaking.wallpapers.R;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_Favgetset;
import com.wallexplore.breathtaking.wallpapers.gettersetter.Item_collections;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class FavouriteFragment extends Fragment implements FavItemsAdapter.MyClickListener,Constant.Callingafterads{

    public static final String TAG = "Main_list";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    private AlertDialog alert;
    RelativeLayout content_favorite;
    ArrayList<Item_Favgetset> fav_item_list;
    RecyclerView items_recycler;
    TextView no_data_text;
    FavItemsAdapter mainAdapter;
    private SearchView searchView;
    DbAdapter db;
    View rootView;

    public FavouriteFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.favorite_fragment, container, false);
        fav_item_list = new ArrayList<>();

        this.conn = null;
        constantfile = new Constant();
        db = new DbAdapter(getActivity());
        db.open();
        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_favorite = (RelativeLayout) rootView.findViewById(R.id.content_favorite);
        items_recycler = (RecyclerView) rootView.findViewById(R.id.items_recycler);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        items_recycler.setLayoutManager(mLayoutManager);
        items_recycler.setItemAnimator(new DefaultItemAnimator());
        items_recycler.setHasFixedSize(true);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);




        return rootView;
    }

    private void showData() {
        db = new DbAdapter(getActivity());
        db.open();
        fav_item_list = new ArrayList<Item_Favgetset>();
        Cursor row = db.fetchAllData();
        for (row.moveToFirst(); !row.isAfterLast(); row.moveToNext()) {
            fav_item_list.add(new Item_Favgetset(row.getString(row.getColumnIndex("item_id")), row.getString(row.getColumnIndex("item_name")),
                    row.getString(row.getColumnIndex("image_url")),row.getString(row.getColumnIndex("cat_imgur")),
                    row.getString(row.getColumnIndex("cat_id")), row.getString(row.getColumnIndex("cat_name"))));
        }

        int ii = fav_item_list.size();
        if (ii <= 0) {
            no_data_text.setVisibility(View.VISIBLE);
            items_recycler.setVisibility(View.GONE);
        } else {
            no_data_text.setVisibility(View.GONE);
            items_recycler.setVisibility(View.VISIBLE);
            setAdapterToListview();
        }
    }

    public void setAdapterToListview() {
        mainAdapter = new FavItemsAdapter(getActivity(), fav_item_list);
        mainAdapter.setClickListener(this);
        items_recycler.setAdapter(mainAdapter);
    }



    @Override
    public void onResume() {
        super.onResume();

        showData();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity)getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name),0);
                }
                return true;
            }
        });

    }

    @Override
    public void onItemClick(int position, Item_Favgetset pass_getset, View v) {
        Constant.Passing_item_id = pass_getset.getId();
        Constant.Passing_item_favorite = new ArrayList<>();
        Constant.Passing_item_favorite.addAll(fav_item_list);
        if (Constant.Adscount == 2){
            constantfile.loadInterstitialAd(getActivity(),this);
        }else{
            Constant.Adscount++;
            Intent intent = new Intent(getActivity(), FavDetailActivity.class);
            getActivity().startActivity(intent);
        }
    }

    @Override
    public void onAdsresponce(Boolean showing) {
        Constant.Passing_type = "0";
        Intent intent = new Intent(getActivity(), FavDetailActivity.class);
        getActivity().startActivity(intent);
    }
}
