package com.akbarbirbalnivarta.gujarati;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import com.akbarbirbalnivarta.gujarati.gettersetter.Item_images;

import androidx.core.content.ContextCompat;

import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Constant {
    public static final String APP_ID = "12";

    public static final String BASIC_URL = "http://simpleappscreator.com/poseandimages_admin/api/";

    public static final String GET_ADD_TOKEN = BASIC_URL+ "api_add_token.php";
    public static final String GET_ADD_VIEW = BASIC_URL+ "api_appadd_view.php";
    public static final String GET_COMMON_LISTING = BASIC_URL+ "api_appcommon_listing.php";

    public static int Adscountlisting = 2;

    public static String Passing_From = "HomeFragment";
    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;
    public static final String notification_name = "AkbarBirbalVarta_notification";
    public static final String NOTIFICATION_CHANNEL_ID = "10001_AkbarBirbalVarta";


    public static final String SHARED_PREF = "ah_firebase_AkbarBirbalVarta";
    public static final String SHARED_Token = "regId";
    public static final String TOPIC_GLOBAL = "global";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";

    public static String Passing_item_id = "";
    public static ArrayList<Item_images> Passing_item_array = new ArrayList<>();


    public void snackbarcommonview(Context mcontext, View coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.BLACK);
        snackbar.show();
    }

    public ArrayList<Item_images> ConvertJSONImage_Model(JSONArray getarray) throws JSONException {
        ArrayList<Item_images> temp_array = new ArrayList<>();

        for (int i = 0; i< getarray.length();i++){
            JSONObject pass = getarray.getJSONObject(i);
            Item_images temp_item = new Item_images();

            temp_item.setId(pass.getString("id"));
            temp_item.setItem_title(pass.getString("item_title"));
            temp_item.setItem_description(pass.getString("item_description"));
            temp_item.setImage(pass.getString("image"));
            temp_item.setImage_thumb(pass.getString("image_thumb"));
            temp_item.setTotal_views(pass.getString("total_views"));
            temp_item.setDate(pass.getString("date"));
            temp_item.setCat_id(pass.getString("cat_id"));
            temp_item.setCategory_name(pass.getString("category_name"));

            temp_array.add(temp_item);
        }
        return temp_array;
    }


//    public ArrayList<Item_videos> ConvertJSONtoModel(JSONArray getarray) throws JSONException {
//        ArrayList<Item_videos> temp_array = new ArrayList<>();
//
//        for (int i = 0; i< getarray.length();i++){
//            JSONObject pass = getarray.getJSONObject(i);
//            Item_videos temp_item = new Item_videos();
//            temp_item.setId(pass.getString("id"));
//            temp_item.setVideo_name(pass.getString("video_name"));
//            temp_item.setVideo_url(pass.getString("video_url"));
//            temp_item.setVideo_image_thumb(pass.getString("video_image_thumb"));
//            temp_item.setTotal_views(pass.getString("total_views"));
//            temp_item.setIs_type(pass.getString("is_type"));
//            temp_item.setDate(pass.getString("date"));
//            temp_item.setCat_id(pass.getString("cat_id"));
//            temp_item.setCategory_name(pass.getString("category_name"));
//            temp_array.add(temp_item);
//        }
//        return temp_array;
//    }
//
//

//
//
//    public ArrayList<Item_Status> ConvertJSONStatus_Model(JSONArray getarray) throws JSONException {
//        ArrayList<Item_Status> temp_array = new ArrayList<>();
//
//        for (int i = 0; i< getarray.length();i++){
//            JSONObject pass = getarray.getJSONObject(i);
//            Item_Status temp_item = new Item_Status();
//
//            temp_item.setId(pass.getString("id"));
//            temp_item.setStatus_text(pass.getString("status_text"));
//            temp_item.setTotal_views(pass.getString("total_views"));
//            temp_item.setTotal_shares(pass.getString("total_shares"));
//            temp_item.setDate(pass.getString("date"));
//            temp_item.setCat_id(pass.getString("cat_id"));
//            temp_item.setCategory_name(pass.getString("category_name"));
//
//            temp_array.add(temp_item);
//        }
//        return temp_array;
//    }


    Callingafterads callingafter;

    public void loadInterstitialAd(Context mContext, final Callingafterads callingafter) {

        this.callingafter = callingafter;

        final ProgressDialog progress = new ProgressDialog(mContext, R.style.MyAlertDialogStyle);
        progress.setMessage("Loading Ad");
        progress.setCancelable(false);
        progress.show();
        final InterstitialAd interstitialAd = new InterstitialAd(mContext, mContext.getResources().getString(R.string.facebook_interstitial_id));
        interstitialAd.loadAd();
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                callingafter.onAdsresponce(true);
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                callingafter.onAdsresponce(true);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd.isAdLoaded()) {
                    interstitialAd.show();
                }
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });

    }

    public interface Callingafterads {
        void onAdsresponce(Boolean showing);
    }

}

