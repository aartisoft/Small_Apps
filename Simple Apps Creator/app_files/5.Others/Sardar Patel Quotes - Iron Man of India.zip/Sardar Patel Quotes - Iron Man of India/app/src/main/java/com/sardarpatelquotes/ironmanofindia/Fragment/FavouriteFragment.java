package com.sardarpatelquotes.ironmanofindia.Fragment;

import android.app.ProgressDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.sardarpatelquotes.ironmanofindia.Activity.MainActivity;
import com.sardarpatelquotes.ironmanofindia.Adapter.FavItemsAdapter;
import com.sardarpatelquotes.ironmanofindia.ConnectionDetector;
import com.sardarpatelquotes.ironmanofindia.Constant;
import com.sardarpatelquotes.ironmanofindia.DbAdapter;
import com.sardarpatelquotes.ironmanofindia.R;
import com.sardarpatelquotes.ironmanofindia.gettersetter.Item_images;

import java.util.ArrayList;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class FavouriteFragment extends Fragment implements FavItemsAdapter.MyClickListener{

    public static final String TAG = "Main_list";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    private AlertDialog alert;
    RelativeLayout content_favorite;
    ArrayList<Item_images> fav_item_list;
    RecyclerView items_recycler;
    TextView no_data_text;
    FavItemsAdapter mainAdapter;
    private SearchView searchView;
    DbAdapter db;
    String PassingTitle = "";

    public FavouriteFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.favorite_fragment, container, false);
        fav_item_list = new ArrayList<>();

        this.conn = null;
        constantfile = new Constant();
        db = new DbAdapter(getActivity());
        db.open();
        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_favorite = (RelativeLayout) rootView.findViewById(R.id.content_favorite);
        items_recycler = (RecyclerView) rootView.findViewById(R.id.items_recycler);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        items_recycler.setLayoutManager(mLayoutManager);
        items_recycler.setItemAnimator(new DefaultItemAnimator());
        items_recycler.setHasFixedSize(true);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);


        return rootView;
    }

    private void showData() {
        db = new DbAdapter(getActivity());
        db.open();
        fav_item_list = new ArrayList<Item_images>();
        Cursor row = db.fetchAllData();
        for (row.moveToFirst(); !row.isAfterLast(); row.moveToNext()) {
            Item_images temp_item = new Item_images();
            temp_item.setId(row.getString(row.getColumnIndex("item_id")));
            temp_item.setItem_title(row.getString(row.getColumnIndex("item_name")));
            temp_item.setItem_description(row.getString(row.getColumnIndex("item_details")));
            temp_item.setImage(row.getString(row.getColumnIndex("image")));
            temp_item.setImage_thumb(row.getString(row.getColumnIndex("image_thumb")));
            temp_item.setTotal_views("total_views");
            temp_item.setDate("date");
            temp_item.setCat_id("cat_id");
            temp_item.setCategory_name("cat_name");

            fav_item_list.add(temp_item);
        }

        int ii = fav_item_list.size();
        if (ii <= 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
            setAdapterToListview();
        }
    }

    public void setAdapterToListview() {
        mainAdapter = new FavItemsAdapter(getActivity(), fav_item_list);
        mainAdapter.setClickListener(this);
        items_recycler.setAdapter(mainAdapter);
    }



    @Override
    public void onResume() {
        super.onResume();

        showData();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity)getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name),0);
                }
                return true;
            }
        });

    }

    @Override
    public void onItemClick(int position, Item_images pass_getset, View v) {
        Constant.Passing_item_id = pass_getset.getId();
        Constant.Passing_item_array = new ArrayList<>();
        Constant.Passing_item_array.addAll(fav_item_list);
        PassingTitle = pass_getset.getItem_title();
        if (Constant.Adscountlisting == 2){
            loadInterstitialAd(pass_getset.getItem_title()+"");
            Constant.Adscountlisting = 1;
        }else{
            Constant.Adscountlisting++;
            ((MainActivity) getActivity()).SelectItem(PassingTitle, 4);
        }
    }

    private void loadInterstitialAd(final String settitle) {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (conn.booleanValue()) {
            final ProgressDialog progress = new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
            progress.setMessage("Loading Ad");
            progress.setCancelable(false);
            progress.show();
            final InterstitialAd interstitialAd = new InterstitialAd(getActivity(), getResources().getString(R.string.facebook_interstitial_id));
            interstitialAd.loadAd();
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    ((MainActivity) getActivity()).SelectItem(settitle, 4);
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    ((MainActivity) getActivity()).SelectItem(settitle, 4);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd.isAdLoaded()) {
                        interstitialAd.show();
                    }
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            });
        } else {
            ((MainActivity) getActivity()).SelectItem(settitle, 4);
        }

    }

}
