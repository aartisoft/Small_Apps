package com.gymworkoutguide.formen.Activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.gymworkoutguide.formen.Adapter.MainCategoryAdapter;
import com.gymworkoutguide.formen.ConnectionDetector;
import com.gymworkoutguide.formen.Constant;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Category_main_getset;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements MainCategoryAdapter.MyClickListener {
    public static final String TAG = "Main_category";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    private AlertDialog alert;
    CoordinatorLayout content_main;
    ArrayList<Category_main_getset> main_category_list;
    RecyclerView main_cat_recycler;
    TextView no_data_text;
    MainCategoryAdapter maincatAdapter;
    ImageView option_menu;
    private FirebaseAnalytics mFirebaseAnalytics;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        main_category_list = new ArrayList<>();
        this.conn = null;
        constantfile = new Constant();

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_main = (CoordinatorLayout) findViewById(R.id.content_main);
        option_menu = (ImageView) findViewById(R.id.option_menu);
        main_cat_recycler = (RecyclerView) findViewById(R.id.main_cat_recycler);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this);
        main_cat_recycler.setLayoutManager(mLayoutManager);
        main_cat_recycler.setItemAnimator(new DefaultItemAnimator());
        main_cat_recycler.setHasFixedSize(true);
        no_data_text = (TextView) findViewById(R.id.no_data_text);

        showData();

        option_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity.this, option_menu);
                //Inflating the Popup using xml file
                popup.getMenuInflater().inflate(R.menu.menu_main, popup.getMenu());

                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        int id = item.getItemId();
                        if (id == R.id.action_rateus) {
                            getRateAppCounter();
                            return true;
                        }else if (id == R.id.action_privacy) {
                            getopenPrivacypolicy();
                            return true;
                        }else if (id == R.id.action_exit) {
                            AppExit();
                            return true;
                        }
                        return true;
                    }
                });

                popup.show();
            }
        });

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        final SharedPreferences pref = getApplicationContext().getSharedPreferences(Constant.SHARED_PREF, 0);


        if (pref.getString("regId", null) != null) {
            String regId = pref.getString("regId", null);
        } else {
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                return;
                            }
                            String token = task.getResult().getToken();
                            pref.edit().putString("regId",token).commit();
                            Log.e("gettingfirebasetoken",token+"      ::::");
                        }
                    });
            BroadcastReceiver mRegistrationBroadcastReceiver = new BroadcastReceiver() {
                @SuppressLint("NewApi")
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (Objects.equals(intent.getAction(), Constant.REGISTRATION_COMPLETE)) {
                        FirebaseMessaging.getInstance().subscribeToTopic(Constant.TOPIC_GLOBAL);
                    } else if (Objects.equals(intent.getAction(), Constant.PUSH_NOTIFICATION)) {
                        String message = intent.getStringExtra("message");
                    }
                }
            };
        }

    }

    private void showData() {
        main_category_list = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(constantfile.getAssetsMainCategory(MainActivity.this));
            JSONArray m_jArry = obj.getJSONArray("data");

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);
                main_category_list.add(new Category_main_getset(jo_inside.getString("cat_id"),jo_inside.getString("cat_name"),
                        jo_inside.getString("cat_image"),jo_inside.getString("cat_color")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        int ii = main_category_list.size();
        if (ii == 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }

        setAdapterToListview();
    }

    public void setAdapterToListview() {
        maincatAdapter = new MainCategoryAdapter(MainActivity.this, main_category_list);
        maincatAdapter.setClickListener(this);
        main_cat_recycler.setAdapter(maincatAdapter);

    }


    @Override
    public void onBackPressed() {
        AppExit();
    }



    public void getRateAppCounter() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void getopenPrivacypolicy() {
        String url = "https://simpleappscreatorpolicy.blogspot.com/2019/06/status-and-images-app-policy.html";
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }


    public void AppExit() {
        AlertDialog.Builder exitDialog = new AlertDialog.Builder(MainActivity.this);
        exitDialog.setTitle("Are you sure....?");
        exitDialog.setMessage("Your feedback is very important to us and it will huge impact. Please Give 5 STAR Rate.");
        exitDialog.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                System.exit(0);
            }
        });
        exitDialog.setNegativeButton("Dismiss", null);
        exitDialog.setNeutralButton("RATE US", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                try {
                    startActivity(goToMarket);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
                }
            }
        });
        AlertDialog errorAlert = exitDialog.create();
        errorAlert.show();
        errorAlert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.BLACK);
        errorAlert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.BLACK);
        errorAlert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.BLACK);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        return true;
    }


    @Override
    public void onItemClick(int position, View v) {
        Intent itemDetails = new Intent(MainActivity.this, SubCategoryActivity.class);
        itemDetails.putExtra("category_id", main_category_list.get(position).getCat_id());
        itemDetails.putExtra("category_name", main_category_list.get(position).getCat_name());
        startActivity(itemDetails);
    }
}