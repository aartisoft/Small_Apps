package com.gymworkoutguide.formen.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;
import com.gymworkoutguide.formen.Adapter.SubcategoryItemsAdapter;
import com.gymworkoutguide.formen.ConnectionDetector;
import com.gymworkoutguide.formen.Constant;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Item_getset;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.gymworkoutguide.formen.Constant.ITEM_DETAILS;

public class SubCategoryItemActivity extends AppCompatActivity implements SubcategoryItemsAdapter.MyClickListener {
    public static final String TAG = "Main_category";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    private AlertDialog alert;
    RelativeLayout content_main;
    ArrayList<Item_getset> Items_list;
    RecyclerView cat_items_recycler;
    TextView no_data_text;
    String subcategory_name,subcategory_id;
    SubcategoryItemsAdapter itemsAdapter;
    private AdView adViewbanner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categoryitems);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                subcategory_id = null;
                subcategory_name = null;
            } else {
                subcategory_id = extras.getString("subcategory_id");
                subcategory_name = extras.getString("subcategory_name");
            }
        } else {
            subcategory_id = (String) savedInstanceState.getSerializable("subcategory_id");
            subcategory_name = (String) savedInstanceState.getSerializable("subcategory_name");
        }

        ActionBar action = getSupportActionBar();
        action.setTitle(subcategory_name+"");
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        AudienceNetworkAds.initialize(SubCategoryItemActivity.this);

        Items_list = new ArrayList<>();
        this.conn = null;
        constantfile = new Constant();

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_main = (RelativeLayout) findViewById(R.id.content_main);
        cat_items_recycler = (RecyclerView) findViewById(R.id.cat_items_recycler);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(SubCategoryItemActivity.this);
        cat_items_recycler.setLayoutManager(mLayoutManager);
        cat_items_recycler.setItemAnimator(new DefaultItemAnimator());
        cat_items_recycler.setHasFixedSize(true);
        no_data_text = (TextView) findViewById(R.id.no_data_text);

        showData();


        adViewbanner = new AdView(this, getResources().getString(R.string.facebook_banner_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.ads);
        adContainer.addView(adViewbanner);
        adViewbanner.loadAd();

    }

    private void showData() {
        Items_list = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(constantfile.getAssetsItemList(SubCategoryItemActivity.this));
            JSONArray m_jArry = obj.getJSONArray("data");

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);
                if (jo_inside.getString("subcat_id").equals(subcategory_id)) {
                    Items_list.add(new Item_getset(jo_inside.getString("item_id"), jo_inside.getString("subcat_id"),
                            jo_inside.getString("item_name"), jo_inside.getString("item_image"),
                            jo_inside.getString("item_videolink"), jo_inside.getString("item_workoutname"),
                            jo_inside.getString("item_repetition"), jo_inside.getString("item_description")));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        int ii = Items_list.size();
        if (ii == 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }

        setAdapterToListview();
    }

    public void setAdapterToListview() {
        itemsAdapter = new SubcategoryItemsAdapter(SubCategoryItemActivity.this, Items_list);
        itemsAdapter.setClickListener(this);
        cat_items_recycler.setAdapter(itemsAdapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    protected void onDestroy() {
        if (adViewbanner != null) {
            adViewbanner.destroy();
        }
        super.onDestroy();
    }

    @Override
    public void onItemClick(int position, View v) {
        ITEM_DETAILS = new Item_getset();
        ITEM_DETAILS = Items_list.get(position);
        Item_getset pass_obj = Items_list.get(position);
        Intent itemDetails = new Intent(SubCategoryItemActivity.this,SingleItemdetail_Activity.class);
        itemDetails.putExtra("item_id",pass_obj.getItem_id());
        itemDetails.putExtra("item_name",pass_obj.getItem_name());
        startActivity(itemDetails);
    }


    //    Bottom ADs
}