package com.gymworkoutguide.formen.gettersetter;

public class Category_sub_getset {


	private String subcat_id;
	private String cat_id;
	private String subcat_name;
	private String subcat_image;


	public Category_sub_getset(String subcat_id, String cat_id, String subcat_name, String subcat_image) {
		this.subcat_id=subcat_id;
		this.cat_id=cat_id;
		this.subcat_name=subcat_name;
		this.subcat_image = subcat_image;
	}

	public Category_sub_getset() {
	}


	public String getSubcat_id() {
		return subcat_id;
	}

	public void setSubcat_id(String subcat_id) {
		this.subcat_id = subcat_id;
	}

	public String getCat_id() {
		return cat_id;
	}

	public void setCat_id(String cat_id) {
		this.cat_id = cat_id;
	}

	public String getSubcat_name() {
		return subcat_name;
	}

	public void setSubcat_name(String subcat_name) {
		this.subcat_name = subcat_name;
	}

	public String getSubcat_image() {
		return subcat_image;
	}

	public void setSubcat_image(String subcat_image) {
		this.subcat_image = subcat_image;
	}


}
