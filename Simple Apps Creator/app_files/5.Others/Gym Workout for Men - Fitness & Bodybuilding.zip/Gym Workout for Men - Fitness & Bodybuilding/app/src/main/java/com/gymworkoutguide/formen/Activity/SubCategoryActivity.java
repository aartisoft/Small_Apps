package com.gymworkoutguide.formen.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import com.gymworkoutguide.formen.Adapter.SubcategoryAdapter;
import com.gymworkoutguide.formen.ConnectionDetector;
import com.gymworkoutguide.formen.Constant;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Category_sub_getset;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SubCategoryActivity extends AppCompatActivity implements SubcategoryAdapter.MyClickListener {
    public static final String TAG = "Main_category";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    RelativeLayout content_main;
    ArrayList<Category_sub_getset> sub_category_list;
    RecyclerView sub_cat_recycler;
    TextView no_data_text;
    String category_name, category_id;
    SubcategoryAdapter subcatAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcategory);

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                category_id = null;
                category_name = null;
            } else {
                category_id = extras.getString("category_id");
                category_name = extras.getString("category_name");
            }
        } else {
            category_id = (String) savedInstanceState.getSerializable("category_id");
            category_name = (String) savedInstanceState.getSerializable("category_name");
        }

        ActionBar action = getSupportActionBar();
        action.setTitle(category_name + "");
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);
        AudienceNetworkAds.initialize(SubCategoryActivity.this);

        sub_category_list = new ArrayList<>();
        this.conn = null;
        constantfile = new Constant();

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        content_main = (RelativeLayout) findViewById(R.id.content_main);
        sub_cat_recycler = (RecyclerView) findViewById(R.id.sub_cat_recycler);
        GridLayoutManager mLayoutManager = new GridLayoutManager(SubCategoryActivity.this, 2);
        sub_cat_recycler.setLayoutManager(mLayoutManager);
        sub_cat_recycler.setItemAnimator(new DefaultItemAnimator());
        sub_cat_recycler.setHasFixedSize(true);
        no_data_text = (TextView) findViewById(R.id.no_data_text);

        showData();

    }

    private void showData() {
        sub_category_list = new ArrayList<>();
        try {
            JSONObject obj = new JSONObject(constantfile.getAssetsSubCategory(SubCategoryActivity.this));
            JSONArray m_jArry = obj.getJSONArray("data");

            for (int i = 0; i < m_jArry.length(); i++) {
                JSONObject jo_inside = m_jArry.getJSONObject(i);
                if (jo_inside.getString("cat_id").equals(category_id)) {
                    sub_category_list.add(new Category_sub_getset(jo_inside.getString("subcat_id"), jo_inside.getString("cat_id"),
                            jo_inside.getString("subcat_name"), jo_inside.getString("subcat_image")));
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        int ii = sub_category_list.size();
        if (ii == 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }

        setAdapterToListview();
    }

    public void setAdapterToListview() {
        subcatAdapter = new SubcategoryAdapter(SubCategoryActivity.this, sub_category_list);
        subcatAdapter.setClickListener(this);
        sub_cat_recycler.setAdapter(subcatAdapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }


    @Override
    public void onItemClick(int position, View v) {
        loadInterstitialAd(position);
    }


    private void loadInterstitialAd(final int pos) {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (conn.booleanValue()) {
            final ProgressDialog progress = new ProgressDialog(SubCategoryActivity.this, R.style.MyAlertDialogStyle);
            progress.setMessage("Loading Ad");
            progress.setCancelable(false);
            progress.show();
            final InterstitialAd interstitialAd = new InterstitialAd(SubCategoryActivity.this, getResources().getString(R.string.facebook_interstitial_id));
            interstitialAd.loadAd();
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    Intent itemDetails = new Intent(SubCategoryActivity.this, SubCategoryItemActivity.class);
                    itemDetails.putExtra("subcategory_id", sub_category_list.get(pos).getSubcat_id());
                    itemDetails.putExtra("subcategory_name", sub_category_list.get(pos).getSubcat_name());
                    startActivity(itemDetails);
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    Intent itemDetails = new Intent(SubCategoryActivity.this, SubCategoryItemActivity.class);
                    itemDetails.putExtra("subcategory_id", sub_category_list.get(pos).getSubcat_id());
                    itemDetails.putExtra("subcategory_name", sub_category_list.get(pos).getSubcat_name());
                    startActivity(itemDetails);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd.isAdLoaded()) {
                        interstitialAd.show();
                    }
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            });
        }else{
            snackbarcommonrelativeLong(SubCategoryActivity.this, content_main, getResources().getString(R.string.no_internet));
        }

    }

    public void snackbarcommonrelativeLong(Context mcontext, RelativeLayout coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_SHORT);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorbutton));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(ContextCompat.getColor(mcontext, R.color.colorAccentlight));
        snackbar.show();
    }
}