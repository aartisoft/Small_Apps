package com.gymworkoutguide.formen.gettersetter;

import java.io.Serializable;

public class Item_collection implements Serializable {

	private String unique_id;
	private String image_thumb;
	private String image_url;
	private String category;

	public Item_collection(String unique_id,String image_thumb,String image_url,String category) {
		this.unique_id=unique_id;
		this.image_thumb=image_thumb;
		this.image_url=image_url;
		this.category=category;
	}

	public Item_collection() {
	}

	public String getUnique_id() {
		return unique_id;
	}

	public void setUnique_id(String unique_id) {
		this.unique_id = unique_id;
	}

	public String getImage_thumb() {
		return image_thumb;
	}

	public void setImage_thumb(String image_thumb) {
		this.image_thumb = image_thumb;
	}

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}


}
