package com.gymworkoutguide.formen.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;
import com.gymworkoutguide.formen.ConnectionDetector;
import com.gymworkoutguide.formen.Constant;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Item_getset;

import static com.gymworkoutguide.formen.Constant.ITEM_DETAILS;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class SingleItemdetail_Activity extends AppCompatActivity implements YouTubeThumbnailView.OnInitializedListener {
    public static final String TAG = "Item_detail";
    private ConnectionDetector detectorconn;
    Boolean conn;
    RelativeLayout detail_linear;
    Constant constantfile;
    String getitem_name;
    Item_getset item_data;

    //ImageView detail_mainimage;
    RelativeLayout watch_video_rl;
    TextView workout_title_detail, repetition_title_detail, description_details;
    String passvideoid = "";
    private YouTubeThumbnailView youTubeThumbnailView;
    String from_action = "";
    private YouTubeThumbnailLoader youTubeThumbnailLoader;
    ProgressBar thumbnail_progress;
    ImageView no_image_found;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.single_itemdetail_activity);


        constantfile = new Constant();
        this.conn = null;
        item_data = new Item_getset();
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
            } else {
                getitem_name = extras.getString("item_name");
            }
        } else {
            getitem_name = (String) savedInstanceState.getSerializable("item_name");
        }

        ActionBar action = getSupportActionBar();
        action.setTitle(getitem_name + "");
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        detail_linear = (RelativeLayout) findViewById(R.id.detail_linear);
        thumbnail_progress = (ProgressBar) findViewById(R.id.thumbnail_progress);
        no_image_found = (ImageView) findViewById(R.id.no_image_found);
        no_image_found.setVisibility(View.GONE);
        watch_video_rl = (RelativeLayout) findViewById(R.id.watch_video_rl);
        workout_title_detail = (TextView) findViewById(R.id.workout_title_detail);
        repetition_title_detail = (TextView) findViewById(R.id.repetition_title_detail);
        description_details = (TextView) findViewById(R.id.description_details);
        //description_details.setMovementMethod(new ScrollingMovementMethod());
        youTubeThumbnailView = (YouTubeThumbnailView) findViewById(R.id.youtubethumbnailview);


        showData();

        youTubeThumbnailView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playouvideo(item_data.getItem_videolink());
            }
        });

        watch_video_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playouvideo(item_data.getItem_videolink());
            }
        });
    }

    private void showData() {
        item_data = ITEM_DETAILS;
        if (item_data != null) {
            workout_title_detail.setText(item_data.getItem_workoutname() + "");
            repetition_title_detail.setText(item_data.getItem_repetition() + "");
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
                description_details.setText(Html.fromHtml(item_data.getItem_description(),Html.FROM_HTML_MODE_COMPACT));
            }else{
                description_details.setText(Html.fromHtml(item_data.getItem_description()));
            }
            passvideoid = item_data.getItem_videolink();
            LoadImageofvideo();
        }
    }


    public void LoadImageofvideo() {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (conn.booleanValue()) {
            thumbnail_progress.setVisibility(View.VISIBLE);
            youTubeThumbnailView.initialize(Constant.API_KEY, this);
        } else {
            from_action = "main";
            snackbarcommonrelativeLong(SingleItemdetail_Activity.this, detail_linear, getResources().getString(R.string.no_internet));
        }
    }

    public void playouvideo(final String getvideoid) {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (conn.booleanValue()) {
            Intent itemDetails = new Intent(SingleItemdetail_Activity.this, Videoplay_Activity.class);
            itemDetails.putExtra("video_id", getvideoid);
            startActivity(itemDetails);
        } else {
            from_action = "video";
            snackbarcommonrelativeLong(SingleItemdetail_Activity.this, detail_linear, getResources().getString(R.string.no_internet));
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void snackbarcommonrelativeLong(Context mcontext, RelativeLayout coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again!", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (from_action.equals("main")) {
                    LoadImageofvideo();
                } else if (from_action.equals("video")) {
                    playouvideo(passvideoid);
                }
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorbutton));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(R.id.snackbar_action);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(ContextCompat.getColor(mcontext, R.color.colorAccentlight));
        textaction.setTextColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        snackbar.show();
    }

    @Override
    public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader thumbnailLoader) {
        youTubeThumbnailLoader = thumbnailLoader;
        thumbnailLoader.setOnThumbnailLoadedListener(new ThumbnailLoadedListener());
        youTubeThumbnailLoader.setVideo(passvideoid);
    }

    @Override
    public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult) {

    }

    private final class ThumbnailLoadedListener implements YouTubeThumbnailLoader.OnThumbnailLoadedListener {

        @Override
        public void onThumbnailError(YouTubeThumbnailView arg0, YouTubeThumbnailLoader.ErrorReason arg1) {
            no_image_found.setVisibility(View.VISIBLE);
            thumbnail_progress.setVisibility(View.GONE);
        }

        @Override
        public void onThumbnailLoaded(YouTubeThumbnailView arg0, String arg1) {
            no_image_found.setVisibility(View.GONE);
            thumbnail_progress.setVisibility(View.GONE);
        }

    }

}

