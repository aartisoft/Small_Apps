package com.gymworkoutguide.formen.Adapter;


import android.content.Context;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Category_main_getset;

import java.util.ArrayList;

public class MainCategoryAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<Category_main_getset> categoryList;
    Context context;
    private static MyClickListener myClickListener;
    public static final int VIEW_TYPE_LEFT = 0;
    public static final int VIEW_TYPE_RIGHT = 1;


    public MainCategoryAdapter(Context context,ArrayList<Category_main_getset> category) {
        this.context = context;
        this.categoryList = new ArrayList<>();
        this.categoryList.addAll(category);
        notifyDataSetChanged();
    }


    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }


    private class ViewHolderLeft extends RecyclerView.ViewHolder {
        public ImageView cat_image;
        public TextView cat_name;
        public CardView item_cardview;

        public ViewHolderLeft(View view) {
            super(view);
            cat_image = (ImageView) view.findViewById(R.id.image_item);
            cat_name = (TextView) view.findViewById(R.id.cat_name);
            item_cardview = (CardView) view.findViewById(R.id.item_cardview);
        }

        public void bind(final int pos) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickListener.onItemClick(pos, v);
                }
            });
        }
    }

    public class ViewHolderRight extends RecyclerView.ViewHolder {
        public ImageView cat_image;
        public TextView cat_name;
        public CardView item_cardview;

        public ViewHolderRight(View view) {
            super(view);
            cat_image = (ImageView) view.findViewById(R.id.image_item);
            cat_name = (TextView) view.findViewById(R.id.cat_name);
            item_cardview = (CardView) view.findViewById(R.id.item_cardview);
        }

        public void bind(final int pos) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickListener.onItemClick(pos, v);
                }
            });
        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_LEFT) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_category_left, parent, false);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.height = (int) (parent.getWidth()/2.5);
            view.setLayoutParams(layoutParams);
            return new ViewHolderLeft(view);
        } else if (viewType == VIEW_TYPE_RIGHT) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.main_category_right, parent, false);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.height = (int) (parent.getWidth()/2.5);
            view.setLayoutParams(layoutParams);
            return new ViewHolderRight(view);
        }
        return null;
    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolderRight) {
            ViewHolderRight userViewHolder = (ViewHolderRight) holder;
            userViewHolder.cat_name.setText(categoryList.get(position).getCat_name());
            Glide.with(context).load(Uri.parse("file:///android_asset/maincat/" + categoryList.get(position).getCat_image())).into(userViewHolder.cat_image);

            userViewHolder.item_cardview.setCardBackgroundColor(Color.parseColor(categoryList.get(position).getCat_color()));
            userViewHolder.bind(position);
        } else if (holder instanceof ViewHolderLeft) {
            ViewHolderLeft ViewHolderleft = (ViewHolderLeft) holder;
            ViewHolderleft.cat_name.setText(categoryList.get(position).getCat_name());
            Glide.with(context).load(Uri.parse("file:///android_asset/maincat/" + categoryList.get(position).getCat_image())).into(ViewHolderleft.cat_image);

            ViewHolderleft.item_cardview.setCardBackgroundColor(Color.parseColor(categoryList.get(position).getCat_color()));
            ViewHolderleft.bind(position);
        }

    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position % 2 == 0 ? VIEW_TYPE_LEFT : VIEW_TYPE_RIGHT;
    }

    public interface MyClickListener {
        void onItemClick(int position, View v);
    }

}