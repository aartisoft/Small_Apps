package com.gymworkoutguide.formen.Activity;

import android.os.Bundle;
import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.gymworkoutguide.formen.ConnectionDetector;
import com.gymworkoutguide.formen.Constant;
import com.gymworkoutguide.formen.R;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Videoplay_Activity extends YouTubeBaseActivity {
    public static final String TAG = "Item_detail";
    private ConnectionDetector detectorconn;
    Boolean conn;
    String video_id;
    Constant constantfile;
    private YouTubePlayer mPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.videoplay_activity);


        constantfile = new Constant();
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                video_id = null;
            } else {
                video_id = extras.getString("video_id");
            }
        } else {
            video_id = (String) savedInstanceState.getSerializable("video_id");
        }

        YouTubePlayerView youTubePlayerView = (YouTubePlayerView) findViewById(R.id.player);
        youTubePlayerView.initialize(Constant.API_KEY,
                new YouTubePlayer.OnInitializedListener() {
                    @Override
                    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {

                        mPlayer = youTubePlayer;
                        mPlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.DEFAULT);
                        mPlayer.setFullscreen(true);
                        mPlayer.loadVideo(video_id);
                        mPlayer.play();
                        //mPlayer.cueVideo(video_id);
                    }
                    @Override
                    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
                        String errorMessage = youTubeInitializationResult.toString();
                        Toast.makeText(Videoplay_Activity.this, errorMessage, Toast.LENGTH_LONG).show();
                        Log.d("errorMessage:", errorMessage);
                    }
                });
    }




    @Override
    public void onBackPressed() {
        this.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
