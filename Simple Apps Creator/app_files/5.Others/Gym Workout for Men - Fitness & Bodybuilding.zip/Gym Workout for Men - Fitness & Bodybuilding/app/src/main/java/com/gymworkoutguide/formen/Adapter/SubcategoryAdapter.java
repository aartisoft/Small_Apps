package com.gymworkoutguide.formen.Adapter;


import android.app.Activity;
import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.gymworkoutguide.formen.R;
import com.gymworkoutguide.formen.gettersetter.Category_sub_getset;

import java.util.ArrayList;

public class SubcategoryAdapter extends RecyclerView.Adapter<SubcategoryAdapter.DataObjectHolder> {
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private ArrayList<Category_sub_getset> subcategoryList;
    Activity main;
    private static MyClickListener myClickListener;
    private Context context;

    public static class DataObjectHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView image_subitem;
        TextView subcat_name;


        public DataObjectHolder(View itemView) {
            super(itemView);
            image_subitem = (ImageView) itemView.findViewById(R.id.image_subitem);
            subcat_name = (TextView) itemView.findViewById(R.id.subcat_name);

            itemView.setOnClickListener(this);


        }

        @Override
        public void onClick(View v) {
            myClickListener.onItemClick(getAdapterPosition(), v);
        }

    }

    public SubcategoryAdapter(Context context, ArrayList<Category_sub_getset> subcategoryList) {
        this.context = context;
        this.subcategoryList = new ArrayList<>();
        this.subcategoryList.addAll(subcategoryList);
        notifyDataSetChanged();
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sub_category_item, parent, false);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        layoutParams.height = (int) (parent.getHeight()/2.8);
        view.setLayoutParams(layoutParams);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, int position) {

        holder.subcat_name.setText(subcategoryList.get(position).getSubcat_name()+"");
        Glide.with(context).load(Uri.parse("file:///android_asset/subcat/" + subcategoryList.get(position).getSubcat_image())).into(holder.image_subitem);

    }



    @Override
    public int getItemCount() {
        return subcategoryList.size();
    }

    public interface MyClickListener {
        void onItemClick(int position, View v);
    }


}
