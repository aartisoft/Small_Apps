package com.gymworkoutguide.formen.gettersetter;

public class Item_getset {

	private String item_id;
	private String subcat_id;
	private String item_name;
	private String item_image;
	private String item_videolink;
	private String item_workoutname;
	private String item_repetition;
	private String item_description;

	public Item_getset(String item_id, String subcat_id, String item_name, String item_image, String item_videolink, String item_workoutname, String item_repetition, String item_description) {
		this.item_id=item_id;
		this.subcat_id=subcat_id;
		this.item_name=item_name;
		this.item_image=item_image;
		this.item_videolink=item_videolink;
		this.item_workoutname=item_workoutname;
		this.item_repetition=item_repetition;
		this.item_description = item_description;
	}

	public Item_getset() {
	}

	public String getItem_id() {
		return item_id;
	}

	public void setItem_id(String item_id) {
		this.item_id = item_id;
	}

	public String getSubcat_id() {
		return subcat_id;
	}

	public void setSubcat_id(String subcat_id) {
		this.subcat_id = subcat_id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_image() {
		return item_image;
	}

	public void setItem_image(String item_image) {
		this.item_image = item_image;
	}

	public String getItem_videolink() {
		return item_videolink;
	}

	public void setItem_videolink(String item_videolink) {
		this.item_videolink = item_videolink;
	}

	public String getItem_workoutname() {
		return item_workoutname;
	}

	public void setItem_workoutname(String item_workoutname) {
		this.item_workoutname = item_workoutname;
	}

	public String getItem_repetition() {
		return item_repetition;
	}

	public void setItem_repetition(String item_repetition) {
		this.item_repetition = item_repetition;
	}

	public String getItem_description() {
		return item_description;
	}

	public void setItem_description(String item_description) {
		this.item_description = item_description;
	}

	public String toString() {
		return "ClassPojo [item_id = " + this.item_id + ", subcat_id = " + this.subcat_id + ", item_name = " + this.item_name + ", item_image = " + this.item_image + ", item_videolink = " + this.item_videolink + ", item_workoutname = " + this.item_workoutname + ", item_repetition = " + this.item_repetition + ", item_description = " + this.item_description + "]";
	}

}
