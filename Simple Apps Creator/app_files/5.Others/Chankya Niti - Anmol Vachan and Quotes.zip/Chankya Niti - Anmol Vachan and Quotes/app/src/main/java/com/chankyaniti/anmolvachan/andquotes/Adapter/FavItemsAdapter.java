package com.chankyaniti.anmolvachan.andquotes.Adapter;


import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.chankyaniti.anmolvachan.andquotes.R;
import com.chankyaniti.anmolvachan.andquotes.gettersetter.Item_images;

import java.util.ArrayList;
import java.util.List;

public class FavItemsAdapter extends RecyclerView.Adapter<FavItemsAdapter.DataObjectHolder> implements Filterable {
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private ArrayList<Item_images> itemsList = new ArrayList<>();
    private List<Item_images> itemsListFiltered = new ArrayList<>();
    Activity main;
    private static MyClickListener myClickListener;
    private Context context;

    public static class DataObjectHolder extends RecyclerView.ViewHolder{

        ImageView image_detail;
        TextView item_title,count_tv;
        CardView item_cardview;


        public DataObjectHolder(View itemView) {
            super(itemView);
            image_detail = (ImageView) itemView.findViewById(R.id.image_detail);
            item_title = (TextView) itemView.findViewById(R.id.item_title);
            count_tv = (TextView) itemView.findViewById(R.id.count_tv);
            item_cardview = (CardView) itemView.findViewById(R.id.item_cardview);

        }

    }

    public FavItemsAdapter(Context context, ArrayList<Item_images> subcategoryList) {
        this.context = context;
        this.itemsList.addAll(subcategoryList);
        this.itemsListFiltered.addAll(subcategoryList);
        notifyDataSetChanged();
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item_row, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            holder.item_title.setText(Html.fromHtml(itemsListFiltered.get(position).getItem_title()+"", Html.FROM_HTML_MODE_COMPACT));
        } else {
            holder.item_title.setText(Html.fromHtml(itemsListFiltered.get(position).getItem_title()+""));
        }
        holder.count_tv.setText((position+1)+"");

        holder.item_cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myClickListener.onItemClick(position,itemsListFiltered.get(position), v);
            }
        });
    }



    @Override
    public int getItemCount() {
        return itemsListFiltered.size();
    }

    public interface MyClickListener {
        void onItemClick(int position,Item_images pass_getset, View v);
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    itemsListFiltered = itemsList;
                } else {
                    List<Item_images> filteredList = new ArrayList<>();
                    for (Item_images row : itemsList) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getItem_title().toLowerCase().contains(charString.toLowerCase()) || row.getItem_description().contains(charSequence)) {
                            filteredList.add(row);
                        }
                    }

                    itemsListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = itemsListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                itemsListFiltered = (ArrayList<Item_images>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

}
