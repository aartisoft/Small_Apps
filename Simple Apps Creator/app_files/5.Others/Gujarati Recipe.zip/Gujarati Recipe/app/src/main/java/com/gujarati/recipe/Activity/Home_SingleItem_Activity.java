package com.gujarati.recipe.Activity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gujarati.recipe.ConnectionDetector;
import com.gujarati.recipe.Constant;
import com.gujarati.recipe.IngredientsFragment;
import com.gujarati.recipe.ProcessFragment;
import com.gujarati.recipe.R;
import com.gujarati.recipe.gettersetter.Item_collection;
import com.jgabrielfreitas.core.BlurImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Home_SingleItem_Activity extends AppCompatActivity {

    private ConnectionDetector detectorconn;
    CoordinatorLayout recipe_maincontent;
    Boolean conn;
    String image_position;
    public static final int MY_PERMISSIONS_REQUEST_ACCESS_WRITE = 101;
    AlertDialog alertDialog;
    //private RewardedVideoAd mRewardedVideoAd;
    ViewPagerUnitDetailsAdapter adapter;
    Item_collection recipe_array = new Item_collection();
    Constant constantfile;
    //InterstitialAd mInterstitialAd;
    ViewPager viewPager;
    boolean showagain = true;
    ImageView back_arrow, recipe_main_image;
    TextView title_recipe_text;
    BlurImageView blur_ImageView;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.home_single_item_activity);
        constantfile = new Constant();
        //Constant.Adscount++;
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        showagain = true;
        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                image_position = null;
            } else {
                image_position = extras.getString("image_position");
                recipe_array = (Item_collection) extras.getSerializable("recipe_array");
            }
        } else {
            image_position = (String) savedInstanceState.getSerializable("image_position");
            recipe_array = (Item_collection) savedInstanceState.getSerializable("recipe_array");
        }

        recipe_maincontent = (CoordinatorLayout) findViewById(R.id.recipe_maincontent);
        back_arrow = (ImageView) findViewById(R.id.back_arrow);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);
        recipe_main_image = (ImageView) findViewById(R.id.recipe_main_image);
        blur_ImageView = (BlurImageView) findViewById(R.id.blur_ImageView);
        title_recipe_text = (TextView) findViewById(R.id.title_recipe_text);

        viewPager = (ViewPager) findViewById(R.id.recipe_viewpager);
        adapter = new ViewPagerUnitDetailsAdapter(this.getSupportFragmentManager());

        IngredientsFragment ingredientsfragment = new IngredientsFragment();
        ProcessFragment processfragment = new ProcessFragment();

        adapter.addFragment(ingredientsfragment, recipe_array.getIngredient());
        adapter.addFragment(processfragment, recipe_array.getProcess());

        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(0);

        final TabLayout tabLayout = (TabLayout) findViewById(R.id.recipe_tabs);
        tabLayout.addTab(tabLayout.newTab().setText(R.string.ingredients_title));
        tabLayout.addTab(tabLayout.newTab().setText(R.string.process_title));
        tabLayout.setupWithViewPager(viewPager);
//        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                switch (tab.getPosition()) {
//                    case 0:
//                        viewPager.setCurrentItem(0);
//                        break;
//                    case 1:
//                        viewPager.setCurrentItem(1);
////                        if(showagain){
////                            if (conn.booleanValue()) {
////                                showdownloaddialog();
////                            } else {
////                                constantfile.snackbarcommoncoordinatorLayout(Home_SingleItem_Activity.this, recipe_maincontent, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.");
////                            }
////                            tabLayout.getTabAt(0).select();
////                        }else{
////                            viewPager.setCurrentItem(1);
////                        }
//
//                        break;
//                }
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//
//            }
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });

        title_recipe_text.setText(recipe_array.getTitle() + "");

        back_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Glide.with(Home_SingleItem_Activity.this)
                .load(recipe_array.getImage_url())
                .error(R.drawable.error)
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
                        return false; // important to return false so the error placeholder can be placed
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        progressBar.setVisibility(View.GONE);
                        blur_ImageView.setImageDrawable(resource);
                        blur_ImageView.setBlur(5);
                        return false;
                    }
                })
                .into(recipe_main_image);


//        mInterstitialAd = new InterstitialAd(Home_SingleItem_Activity.this);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstial_id));
//        mInterstitialAd.setAdListener(new AdListener() {
//            @Override
//            public void onAdClosed() {
//                requestNewInterstitial();
//            }
//        });
//
//        if (Constant.Adscount == 2) {
//            requestNewInterstitial();
//            mInterstitialAd.setAdListener(new AdListener() {
//                public void onAdLoaded() {
//                    if (mInterstitialAd.isLoaded()) {
//                        mInterstitialAd.show();
//                    }
//                }
//            });
//            Constant.Adscount = 0;
//        }

//        mRewardedVideoAd = MobileAds.getRewardedVideoAdInstance(this);
//        mRewardedVideoAd.setRewardedVideoAdListener(new RewardedVideoAdListener() {
//
//            @Override
//            public void onRewarded(RewardItem rewardItem) {
//            }
//
//            @Override
//            public void onRewardedVideoAdLeftApplication() {
//            }
//
//            @Override
//            public void onRewardedVideoAdClosed() {
//
//                showagain = false;
//                tabLayout.getTabAt(1).select();
//                loadRewardedVideoAd();
//            }
//
//            @Override
//            public void onRewardedVideoAdFailedToLoad(int errorCode) {
//                if (mInterstitialAd.isLoaded()) {
//                    mInterstitialAd.show();
//                }
//                showagain = false;
//                tabLayout.getTabAt(1).select();
//            }
//
//            @Override
//            public void onRewardedVideoCompleted() {
//                showagain = false;
//                tabLayout.getTabAt(1).select();
//                loadRewardedVideoAd();
//            }
//
//            @Override
//            public void onRewardedVideoAdLoaded() {
//            }
//
//            @Override
//            public void onRewardedVideoAdOpened() {
//            }
//
//            @Override
//            public void onRewardedVideoStarted() {
//            }
//        });

        // loadRewardedVideoAd();


    }

//    public void showdownloaddialog(){
//        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
//        alertDialogBuilder.setMessage(getResources().getString(R.string.see_alert_title));
//                alertDialogBuilder.setPositiveButton("Yes",
//                        new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface arg0, int arg1) {
//                                alertDialog.dismiss();
//                                showRewardedVideo();
//                            }
//                        });
//
//                alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        alertDialog.dismiss();
//                        viewPager.setCurrentItem(0);
//                    }
//                });
//        alertDialog = alertDialogBuilder.create();
//        alertDialog.show();
//
//    }


//    private void loadRewardedVideoAd() {
//        mRewardedVideoAd.loadAd(getString(R.string.rewarded_video), new AdRequest.Builder().build());
//        //showRewardedVideo();
//    }
//
//
//    private void showRewardedVideo() {
//        if (mRewardedVideoAd.isLoaded()) {
//            mRewardedVideoAd.show();
//        }
//    }


    @Override
    public void onBackPressed() {
        this.finish();
    }


//    private void requestNewInterstitial() {
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mInterstitialAd.loadAd(adRequest);
//    }


//    @Override
//    public void onResume() {
//        mRewardedVideoAd.resume(this);
//        super.onResume();
//    }
//
//    @Override
//    public void onPause() {
//        mRewardedVideoAd.pause(this);
//        super.onPause();
//    }
//
//    @Override
//    public void onDestroy() {
//        mRewardedVideoAd.destroy(this);
//        super.onDestroy();
//    }


    public class ViewPagerUnitDetailsAdapter extends FragmentPagerAdapter {

        private ArrayList<String> mpassvalue = new ArrayList<>();

        private final List<Fragment> mFragmentList = new ArrayList<>();

        public ViewPagerUnitDetailsAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String passvalue) {
            mFragmentList.add(fragment);
            mpassvalue.add(passvalue);
        }

        @Override
        public Fragment getItem(int position) {
            if (position == 0) {
                return IngredientsFragment.newInstance(mpassvalue.get(0));
            } else {
                return ProcessFragment.newInstance(mpassvalue.get(1));
            }
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return getResources().getString(R.string.ingredients_title);
                case 1:
                    return getResources().getString(R.string.process_title);
                default:
                    return null;
            }
        }
    }


}
