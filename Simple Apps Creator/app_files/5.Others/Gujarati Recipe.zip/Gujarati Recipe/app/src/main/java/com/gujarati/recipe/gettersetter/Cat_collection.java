package com.gujarati.recipe.gettersetter;

public class Cat_collection {

	private String display_name;
	private String pass_name;
	int image_icon;

	public Cat_collection(String display_name, String pass_name,int image_icon) {
		this.display_name=display_name;
		this.pass_name=pass_name;
		this.image_icon=image_icon;
	}

	public Cat_collection() {
	}


	public String getDisplay_name() {
		return display_name;
	}

	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}

	public String getPass_name() {
		return pass_name;
	}

	public void setPass_name(String pass_name) {
		this.pass_name = pass_name;
	}

	public int getImage_icon() {
		return image_icon;
	}

	public void setImage_icon(int image_icon) {
		this.image_icon = image_icon;
	}


}
