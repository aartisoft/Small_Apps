package com.gujarati.recipe.Activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.gujarati.recipe.Adapter.RecipeItemAdapter;
import com.gujarati.recipe.ConnectionDetector;
import com.gujarati.recipe.Constant;
import com.gujarati.recipe.EndlessRecyclerOnScrollListener;
import com.gujarati.recipe.R;
import com.gujarati.recipe.gettersetter.Item_collection;

import java.util.ArrayList;
import java.util.Collections;

//
//import com.google.android.gms.ads.AdListener;
//import com.google.android.gms.ads.AdRequest;
//import com.google.android.gms.ads.InterstitialAd;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Home_CategoryItem_Activity extends AppCompatActivity implements RecipeItemAdapter.MyClickListener {


    private ConnectionDetector detectorconn;
    Boolean conn;
    ArrayList<Item_collection> arrayofimages;
    private ProgressBar progressBar;
    TextView no_data_text;
    Constant constantfile;
    RelativeLayout relaivelayout;
    RecyclerView Image_list, Trendning_list;
    RecipeItemAdapter mAdapter;
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference().child("recipe_list");
    // InterstitialAd mInterstitialAd;

    private int currentpage = 0;
    private boolean mIsLoadingMore;
    private static final int TOTAL_ITEM_EACH_LOAD = 15;
    String oldestKeyYouveSeen = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        constantfile = new Constant();
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        this.currentpage = 0;
        this.mIsLoadingMore = false;
        AudienceNetworkAds.initialize(Home_CategoryItem_Activity.this);

        ActionBar action = getSupportActionBar();
        action.setTitle(getResources().getString(R.string.app_name));
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        no_data_text = (TextView) findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);
        arrayofimages = new ArrayList<Item_collection>();
        Image_list = (RecyclerView) findViewById(R.id.Image_list);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(Home_CategoryItem_Activity.this);
        Image_list.setLayoutManager(mLayoutManager);
        Image_list.setItemAnimator(new DefaultItemAnimator());
        Image_list.setHasFixedSize(true);
        Image_list.setOnScrollListener(new EndlessRecyclerOnScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int current_page) {
                if (mIsLoadingMore) {
                    currentpage = current_page;
                    LoadImagedata(current_page);
                }
            }
        });
        mAdapter = new RecipeItemAdapter(Home_CategoryItem_Activity.this);
        mAdapter.setClickListener(this);
        Image_list.setAdapter(mAdapter);


        mIsLoadingMore = true;
        oldestKeyYouveSeen = null;
        currentpage = 0;
        LoadImagedata(currentpage);


    }

    public void LoadImagedata(final int pagenumber) {
        if (conn.booleanValue()) {
            if (pagenumber == 0) {
                progressBar.setVisibility(View.VISIBLE);
                Image_list.setVisibility(View.VISIBLE);
                no_data_text.setVisibility(View.GONE);
            }
            Query jokesQuery;
            if (oldestKeyYouveSeen != null) {
                jokesQuery = ref.orderByKey().endAt(oldestKeyYouveSeen).limitToLast(TOTAL_ITEM_EACH_LOAD + 1);
            } else {
                jokesQuery = ref.orderByKey().limitToLast(TOTAL_ITEM_EACH_LOAD);
            }

            jokesQuery.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getChildrenCount() < TOTAL_ITEM_EACH_LOAD) {
                        mIsLoadingMore = false;
                    } else {
                        mIsLoadingMore = true;
                    }
                    Boolean getkeybool = true;
                    arrayofimages = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Item_collection temp = new Item_collection(snapshot.child("unique_id").getValue().toString(), snapshot.child("thumb").getValue().toString().replace("http://", "https://"), snapshot.child("url").getValue().toString().replace("http://", "https://"), snapshot.child("category").getValue().toString(), snapshot.child("title").getValue().toString(), snapshot.child("ingredient").getValue().toString(), snapshot.child("process").getValue().toString());
                        arrayofimages.add(0, temp);
                        if (getkeybool) {
                            getkeybool = false;
                            oldestKeyYouveSeen = snapshot.getKey();
                        }
                    }
                    if (arrayofimages.size() > 0) {
                        //Collections.reverse(arrayofimages);
                        if (mIsLoadingMore) {
                            arrayofimages.remove(arrayofimages.size() - 1);
                        }
                        mAdapter.adddata(arrayofimages, pagenumber);
                        if (!mIsLoadingMore) {
                            mAdapter.setnomoredata();
                        }
                    }
                    if (progressBar != null) {
                        progressBar.setVisibility(View.GONE);
                    }

                }


                @Override
                public void onCancelled(DatabaseError databaseError) {
                    if (pagenumber == 0) {
                        progressBar.setVisibility(View.GONE);
                        Image_list.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                        no_data_text.setText("No Recipes Found");
                    }
                }
            });
        } else {
            noInternetConnectionDialog();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void noInternetConnectionDialog() {
        AlertDialog.Builder errorDialog = new AlertDialog.Builder(Home_CategoryItem_Activity.this);
        errorDialog.setTitle((CharSequence) "Error");
        errorDialog.setMessage((CharSequence) "No internet connection.");
        errorDialog.setNeutralButton((CharSequence) "OK", new dialogclicklistner());
        AlertDialog errorAlert = errorDialog.create();
        errorAlert.show();
    }


    @Override
    public void onItemClick(int position, Item_collection dataobject, View v) {
        loadInterstitialAd(position, dataobject);
    }

    class dialogclicklistner implements DialogInterface.OnClickListener {
        dialogclicklistner() {
        }

        public void onClick(DialogInterface dialog, int id) {
            detectorconn = new ConnectionDetector(Home_CategoryItem_Activity.this);
            conn = Boolean.valueOf(detectorconn.isConnectingToInternet());
            dialog.dismiss();
        }
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }


    private void loadInterstitialAd(final int pos, final Item_collection itempass) {
        final ProgressDialog progress = new ProgressDialog(Home_CategoryItem_Activity.this, R.style.MyAlertDialogStyle);
        progress.setMessage("Loading Ad");
        progress.setCancelable(false);
        progress.show();
        final InterstitialAd interstitialAd = new InterstitialAd(Home_CategoryItem_Activity.this, getResources().getString(R.string.facebook_interstitial_id));
        interstitialAd.loadAd();
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                Intent catwise = new Intent(Home_CategoryItem_Activity.this, Home_SingleItem_Activity.class);
                catwise.putExtra("recipe_position", pos + "");
                catwise.putExtra("recipe_array", itempass);
                startActivity(catwise);
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                Intent catwise = new Intent(Home_CategoryItem_Activity.this, Home_SingleItem_Activity.class);
                catwise.putExtra("recipe_position", pos + "");
                catwise.putExtra("recipe_array", itempass);
                startActivity(catwise);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd.isAdLoaded()) {
                    interstitialAd.show();
                }
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });

    }

//    private void loadInterstitialAd(final int pos) {
//        final ProgressDialog progress = new ProgressDialog(Home_CategoryItem_Activity.this);
//        progress.setMessage("Loading Ad");
//        progress.setCancelable(false);
//        progress.show();
//        mInterstitialAd = new InterstitialAd(Home_CategoryItem_Activity.this);
//        mInterstitialAd.setAdUnitId(getResources().getString(R.string.interstial_id));
//        mInterstitialAd.setAdListener(new AdListener() {
//
//            @Override
//            public void onAdLoaded() {
//                super.onAdLoaded();
//                progress.dismiss();
//                if (mInterstitialAd.isLoaded()) {
//                    mInterstitialAd.show();
//                }
//            }
//
//            @Override
//            public void onAdFailedToLoad(int i) {
//                super.onAdFailedToLoad(i);
//                if (progress.isShowing()){
//                    progress.dismiss();
//                }
//                Intent catwise = new Intent(Home_CategoryItem_Activity.this, Home_SingleItem_Activity.class);
//                catwise.putExtra("recipe_position", pos + "");
//                catwise.putExtra("recipe_array",arrayofimages.get(pos));
//                startActivity(catwise);
//            }
//
//            @Override
//            public void onAdClosed() {
//                super.onAdClosed();
//                if (progress.isShowing()){
//                    progress.dismiss();
//                }
//                Intent catwise = new Intent(Home_CategoryItem_Activity.this, Home_SingleItem_Activity.class);
//                catwise.putExtra("recipe_position", pos + "");
//                catwise.putExtra("recipe_array",arrayofimages.get(pos));
//                startActivity(catwise);
//            }
//        });
//
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mInterstitialAd.loadAd(adRequest);
//    }

}
