package com.gujarati.recipe;

import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class IngredientsFragment extends Fragment {

    private String ingredient;
    TextView show_ingredient;

    public IngredientsFragment() {
    }

    // Here I want to get unitID
    public static IngredientsFragment newInstance(String ingredient) {
        IngredientsFragment fragment = new IngredientsFragment();
        Bundle args = new Bundle();
        args.putString("ingredient", ingredient);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.show_detail_ingredient, container, false);

        ingredient = getArguments().getString("ingredient");

        show_ingredient = (TextView) view.findViewById(R.id.show_textdata);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            show_ingredient.setText(Html.fromHtml(ingredient, Html.FROM_HTML_MODE_COMPACT));
        } else {
            show_ingredient.setText(Html.fromHtml(ingredient));
        }

        return view;
    }
}