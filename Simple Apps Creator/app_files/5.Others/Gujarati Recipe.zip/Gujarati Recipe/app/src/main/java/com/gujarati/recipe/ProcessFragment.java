package com.gujarati.recipe;

import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ProcessFragment extends Fragment {

    private String process;
    TextView show_process;

    public ProcessFragment() {
    }

    // Here I want to get unitID
    public static ProcessFragment newInstance(String process) {
        ProcessFragment fragment = new ProcessFragment();
        Bundle args = new Bundle();
        args.putString("process", process);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.show_detail_fragment, container, false);

        process = getArguments().getString("process");

        show_process = (TextView) view.findViewById(R.id.show_textdata);
        show_process.setMovementMethod(new ScrollingMovementMethod());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            show_process.setText(Html.fromHtml(process, Html.FROM_HTML_MODE_COMPACT)+"");
        } else {
            show_process.setText(Html.fromHtml(process)+"");
        }

        return view;
    }
}