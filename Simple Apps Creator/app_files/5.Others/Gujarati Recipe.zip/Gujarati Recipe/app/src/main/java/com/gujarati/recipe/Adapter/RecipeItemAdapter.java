package com.gujarati.recipe.Adapter;


import android.content.ClipData;
import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.gujarati.recipe.R;
import com.gujarati.recipe.gettersetter.Item_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class RecipeItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<Item_collection> recipeList = new ArrayList<>();
    private static MyClickListener myClickListener;
    private Context context;
    int[] androidColors;
    public static final int VIEW_TYPE_ITEM = 0;
    public static final int VIEW_TYPE_LOADING = 1;


    public void setnomoredata() {
        this.recipeList.removeAll(Collections.singleton(null));
        notifyDataSetChanged();
    }


    public static class DataObjectHolder extends RecyclerView.ViewHolder {

        ImageView image;
        ProgressBar progressBar;
        TextView recipe_category,recipe_title;

        public DataObjectHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.image_item);
            recipe_category = (TextView) itemView.findViewById(R.id.recipe_category);
            recipe_title = (TextView) itemView.findViewById(R.id.recipe_title);
            progressBar = (ProgressBar) itemView.findViewById(R.id.progressBar);
            progressBar.setVisibility(View.VISIBLE);
        }

        public void bind(final int pos, final Item_collection passdata) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    myClickListener.onItemClick(pos,passdata, v);
                }
            });
        }

    }

    private class ViewHolderLoading extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public ViewHolderLoading(View view) {
            super(view);
            progressBar = (ProgressBar) view.findViewById(R.id.itemProgressbar);
        }
    }

    public void adddata(ArrayList<Item_collection> recipeList, int pagenumber) {
        if (pagenumber == 0) {
            this.recipeList.clear();
            this.recipeList.addAll(recipeList);
            this.recipeList.add(null);
        } else {
            this.recipeList.removeAll(Collections.singleton(null));
            this.recipeList.addAll(recipeList);
            this.recipeList.add(null);
        }
        notifyDataSetChanged();
    }

    public RecipeItemAdapter(Context context) {
        this.context = context;
        this.recipeList = new ArrayList<>();
        androidColors = context.getResources().getIntArray(R.array.colors);
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_single_gallery_row, parent, false);
            return new DataObjectHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_progressbar, parent, false);
            return new ViewHolderLoading(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof DataObjectHolder) {

            final DataObjectHolder userViewHolder = (DataObjectHolder) holder;
            userViewHolder.recipe_title.setText(recipeList.get(position).getTitle()+"");
            userViewHolder.recipe_category.setText(recipeList.get(position).getCategory().toUpperCase());
            int randomAndroidColor = androidColors[new Random().nextInt(androidColors.length)];
            userViewHolder.recipe_category.setBackgroundColor(randomAndroidColor);

            Glide.with(context)
                    .load(recipeList.get(position).getImage_thumb())
                    .error(R.drawable.error)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            userViewHolder.progressBar.setVisibility(View.GONE);
                            return false; // important to return false so the error placeholder can be placed
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                            userViewHolder.progressBar.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(userViewHolder.image);

            userViewHolder.bind(position,recipeList.get(position));
        } else if (holder instanceof ViewHolderLoading) {
            if (position == recipeList.size()-1){
                ViewHolderLoading loadingViewHolder = (ViewHolderLoading) holder;
                loadingViewHolder.progressBar.setIndeterminate(true);
            }

        }

    }


    @Override
    public int getItemCount() {
        return recipeList == null ? 0 : recipeList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return recipeList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    public interface MyClickListener {
        public void onItemClick(int position, Item_collection dataobject, View v);

    }


}
