package com.coolposeideas.forphotography;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DbAdapter {

    //define static variable
    public static int dbversion =1;
    public static String dbname = "PosePhotographyDB";
    public static String dbTable = "PoseFav";

    private static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context,dbname,null, dbversion);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE "+dbTable+" (_id INTEGER PRIMARY KEY autoincrement,unique_id, category, image_url, image_thumb)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+dbTable);
            onCreate(db);
        }
    }

    private final Context c;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase sqlDb;

    public DbAdapter(Context context) {
        this.c = context;
    }
    public DbAdapter open() throws SQLException {
        dbHelper = new DatabaseHelper(c);
        sqlDb = dbHelper.getWritableDatabase();
        return this;
    }

    //insert data
    public void insert(String uniqueid,String category,String imageurl,String imagethumb) {
        if(!isExist(uniqueid)) {
            sqlDb.execSQL("INSERT INTO PoseFav (unique_id,category,image_url,image_thumb) VALUES('"+uniqueid+"','"+category+"','"+imageurl+"','"+imagethumb+"')");
        }
    }
    //check entry already in database or not
    public boolean isExist(String num){
        String query = "SELECT unique_id FROM PoseFav WHERE unique_id='"+num+"' LIMIT 1";
        Cursor row = sqlDb.rawQuery(query, null);
        return row.moveToFirst();
    }

    //edit data
    public void update(int id, String text2, String text3, String text4, String text5) {
        sqlDb.execSQL("UPDATE "+dbTable+" SET unique_id='"+text2+"', category='"+text3+"', image_url='"+text4+"', image_thumb='"+text5+"',   WHERE _id=" + id);
    }

    //delete data
    public void delete(String uniqueid) {
        Log.e("deleterecord",":::  "+uniqueid);
        sqlDb.execSQL("DELETE FROM PoseFav WHERE unique_id='"+uniqueid+"'");
    }

    //fetch data
    public Cursor fetchAllData() {
        String query = "SELECT * FROM "+dbTable;
        Cursor row = sqlDb.rawQuery(query, null);
        if (row != null) {
            row.moveToFirst();
        }
        return row;
    }

    //fetch data by filter
    public Cursor fetchdatabyfilter(String inputText,String filtercolumn) throws SQLException {
        Cursor row = null;
        String query = "SELECT * FROM "+dbTable;
        if (inputText == null  ||  inputText.length () == 0)  {
            row = sqlDb.rawQuery(query, null);
        }else {
            query = "SELECT * FROM "+dbTable+" WHERE "+filtercolumn+" like '%"+inputText+"%'";
            row = sqlDb.rawQuery(query, null);
        }
        if (row != null) {
            row.moveToFirst();
        }
        return row;
    }
}
