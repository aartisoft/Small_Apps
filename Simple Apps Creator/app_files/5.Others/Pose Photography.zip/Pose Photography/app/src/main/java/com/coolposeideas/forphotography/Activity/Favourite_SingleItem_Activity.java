package com.coolposeideas.forphotography.Activity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.coolposeideas.forphotography.ConnectionDetector;
import com.coolposeideas.forphotography.Constant;
import com.coolposeideas.forphotography.DbAdapter;
import com.coolposeideas.forphotography.DownloadTask;
import com.coolposeideas.forphotography.R;
import com.coolposeideas.forphotography.gettersetter.Item_collections;
import com.coolposeideas.forphotography.widgets.EnchantedViewPager;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.facebook.ads.AudienceNetworkAds;

import java.util.ArrayList;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Favourite_SingleItem_Activity extends AppCompatActivity {

    ImageView submit_download, submit_share, submit_favourite;
    private ConnectionDetector detectorconn;
    Boolean conn;
    int image_position  = 0;

    public static final int MY_PERMISSIONS_REQUEST_ACCESS_WRITE = 101;
    private AlertDialog alert;
    TextView no_data_text;
    RelativeLayout fulllayout;
    EnchantedViewPager mViewPager;
    CustomViewPagerAdapter mAdapter;
    String Actionclick = "";
    public static final String Actiondownload = "download";
    public static final String Actionshare = "share";
    ArrayList<Item_collections> image_array = new ArrayList<>();
    RelativeLayout relative;
    Constant constantfile;
    //InterstitialAd mInterstitialAd;
    DbAdapter db;
    private AdView adViewbanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_single_item_activity);

        ActionBar action = getSupportActionBar();
        action.setTitle("Pose");
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);
        db = new DbAdapter(this);
        db.open();
        constantfile = new Constant();
       // Constant.Adscount++;
        this.conn = null;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        image_position = Constant.passpos;
        image_array = new ArrayList<>();
        image_array.addAll(Constant.passarray);


        if (!AudienceNetworkAds.isInAdsProcess(Favourite_SingleItem_Activity.this)){
            AudienceNetworkAds.initialize(Favourite_SingleItem_Activity.this);
        }

        adViewbanner = new AdView(this, getResources().getString(R.string.facebook_banner_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = (LinearLayout) findViewById(R.id.ads);
        adContainer.addView(adViewbanner);
        adViewbanner.loadAd();


        relative = (RelativeLayout) findViewById(R.id.relative);
        fulllayout = (RelativeLayout) findViewById(R.id.fulllayout);
        no_data_text = (TextView) findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);
        fulllayout.setVisibility(View.VISIBLE);
        submit_download = (ImageView) findViewById(R.id.submit_download);
        submit_share = (ImageView) findViewById(R.id.submit_share1);
        submit_favourite = (ImageView) findViewById(R.id.submit_favourite1);


        mAdapter = new CustomViewPagerAdapter();
        mViewPager = findViewById(R.id.viewPager);
        mViewPager.useScale();
        mViewPager.removeAlpha();
        submit_favourite.setImageResource(R.drawable.ic_favourite_fill);

        setResult();

        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

               // Log.e("scrolllistner","onpagescroll :: "+i);
            }

            @Override
            public void onPageSelected(int i) {
                image_position = i;
//                String uniqueid = image_array.get(image_position).getUnique_id();
//                if(db.isExist(uniqueid)){
//                    submit_favourite.setImageResource(R.drawable.ic_favourite_fill);
//                }else{
//                    submit_favourite.setImageResource(R.drawable.ic_favourite);
//                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {
               // Log.e("scrolllistner","onpagescrollchange :: "+i);
            }
        });

        submit_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Actionclick = Actiondownload;
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        if (conn.booleanValue()) {
                            actionsharedownload();
                        } else {
                            constantfile.snackbarcommonrelative(Favourite_SingleItem_Activity.this, relative, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.");
                        }
                    }
                }else{
                    actionsharedownload();
                }
            }
        });

        submit_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Actionclick = Actionshare;
                int MyVersion = Build.VERSION.SDK_INT;
                if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
                    if (!checkIfAlreadyhavePermission()) {
                        requestForSpecificPermission();
                    } else {
                        if (conn.booleanValue()){
                            actionsharedownload();
                        }
                        else {
                            constantfile.snackbarcommonrelative(Favourite_SingleItem_Activity.this, relative, "Oops!! There is no internet connection. \nPlease enable internet connection and try again.");
                        }

                    }
                }else{
                    actionsharedownload();
                }
            }
        });

        submit_favourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uniqueid = image_array.get(image_position).getId();
                if(db.isExist(uniqueid)){
                    db.delete(uniqueid);
                    image_array.remove(image_position);
                    mAdapter.notifyDataSetChanged();
                    if (image_array.size() <= 0){
                        no_data_text.setVisibility(View.VISIBLE);
                        fulllayout.setVisibility(View.GONE);
                    }
                    constantfile.snackbarcommonrelative(Favourite_SingleItem_Activity.this, relative, "Remove from Favourite Successfully!");
                }else{
                    constantfile.snackbarcommonrelative(Favourite_SingleItem_Activity.this, relative, "No Image Found!");
                }

            }
        });




    }

    @Override
    protected void onDestroy() {
        if (adViewbanner != null) {
            adViewbanner.destroy();
        }
        super.onDestroy();
    }

    public void actionsharedownload(){
        if (Actionclick.equals(Actiondownload)){
            new DownloadTask(Favourite_SingleItem_Activity.this, image_array.get(image_position).getWallpaper_image(), "download");
        }else if(Actionclick.equals(Actionshare)){
            new DownloadTask(Favourite_SingleItem_Activity.this, image_array.get(image_position).getWallpaper_image(), "share");
        }
    }



    private void setResult() {
        if (getApplicationContext() != null) {
            if (!image_array.isEmpty()) {
                mViewPager.setAdapter(mAdapter);
                if (image_array.size() >= 1) {
                    mViewPager.setCurrentItem(image_position);
                }

            }
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_ACCESS_WRITE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_WRITE : {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    actionsharedownload();
                } else {
                    constantfile.snackbarcommonrelative(Favourite_SingleItem_Activity.this, relative, "You need to give permission for download images!");
                }
                return;
            }
        }
    }


    @Override
    public void onBackPressed() {
        this.finish();
    }


//    private void requestNewInterstitial() {
//        AdRequest adRequest = new AdRequest.Builder().build();
//        mInterstitialAd.loadAd(adRequest);
//    }


    private class CustomViewPagerAdapter extends PagerAdapter {
        private LayoutInflater inflater;

        private CustomViewPagerAdapter() {
            // TODO Auto-generated constructor stub
            inflater = getLayoutInflater();
        }

        @Override
        public int getItemPosition(Object object){
            return PagerAdapter.POSITION_NONE;
        }

        @Override
        public int getCount() {
            return image_array.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            View imageLayout = inflater.inflate(R.layout.fullscreenitem_layout, container, false);
            assert imageLayout != null;
            ImageView iv_image = (ImageView) imageLayout.findViewById(R.id.iv_image);
            final ProgressBar progressBar = (ProgressBar) imageLayout.findViewById(R.id.progressBar);
            imageLayout.setTag(EnchantedViewPager.ENCHANTED_VIEWPAGER_POSITION + position);

            Glide.with(Favourite_SingleItem_Activity.this)
                    .load(image_array.get(position).getWallpaper_image())
                    .error(R.drawable.error)
                    .listener(new RequestListener<Drawable>() {
                        @Override
                        public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                            // log exception
                            progressBar.setVisibility(View.GONE);
                            return false; // important to return false so the error placeholder can be placed
                        }

                        @Override
                        public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                            progressBar.setVisibility(View.GONE);
                            return false;
                        }
                    })
                    .into(iv_image);
            container.addView(imageLayout, 0);
            return imageLayout;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            (container).removeView((View) object);
        }
    }


}
