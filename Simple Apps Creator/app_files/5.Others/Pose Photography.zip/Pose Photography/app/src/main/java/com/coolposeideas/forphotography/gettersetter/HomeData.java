package com.coolposeideas.forphotography.gettersetter;

import android.content.ClipData;

import java.util.ArrayList;

public class HomeData {

    private boolean status;
    private String message;
    private ArrayList<Item_collections> trending_list;
    private ArrayList<Item_category> category_list;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<Item_collections> getTrending_list() {
        return trending_list;
    }

    public void setTrending_list(ArrayList<Item_collections> trending_list) {
        this.trending_list = trending_list;
    }

    public ArrayList<Item_category> getCategory_list() {
        return category_list;
    }

    public void setCategory_list(ArrayList<Item_category> category_list) {
        this.category_list = category_list;
    }


    public String toString() {
        return "ClassPojo [status = " + this.status + ", message = " + this.message +  ", trending_list = " + this.trending_list +  ", category_list = " + this.category_list + "]";
    }
}
