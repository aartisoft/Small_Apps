package com.coolposeideas.forphotography.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.coolposeideas.forphotography.Adapter.ImageAdapter;
import com.coolposeideas.forphotography.ConnectionDetector;
import com.coolposeideas.forphotography.Constant;
import com.coolposeideas.forphotography.EndlessRecyclerOnScrollListener;
import com.coolposeideas.forphotography.R;
import com.coolposeideas.forphotography.gettersetter.ItemData;
import com.coolposeideas.forphotography.gettersetter.Item_collections;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Kakadiyas on 11-07-2017.
 */

public class Home_CategoryItem_Activity extends AppCompatActivity implements ImageAdapter.MyClickListener,Constant.Callingafterads{


    private ConnectionDetector detectorconn;
    Boolean conn;
    private ProgressBar progressBar;
    TextView no_data_text;
    Constant constantfile;
    RelativeLayout relaivelayout;
    RecyclerView Image_list;
    ImageAdapter  mAdapter;
    String category_id,title;
    private int currentpage = 1;
    private boolean mIsLoadingMore;
   // InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        if (!AudienceNetworkAds.isInAdsProcess(Home_CategoryItem_Activity.this)){
            AudienceNetworkAds.initialize(Home_CategoryItem_Activity.this);
        }
        constantfile = new Constant();
        this.conn = null;
        this.currentpage = 1;
        this.mIsLoadingMore = false;
        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if (extras == null) {
                category_id = null;
                title = null;
            } else {
                category_id = extras.getString("category_id");
                title = extras.getString("category_title");
            }
        } else {
            category_id = (String) savedInstanceState.getSerializable("category_id");
            title = (String) savedInstanceState.getSerializable("category_title");
        }

        ActionBar action = getSupportActionBar();
        action.setTitle(title+"");
        action.setDisplayHomeAsUpEnabled(true);
        action.setHomeButtonEnabled(true);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        no_data_text = (TextView) findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);

        Image_list = (RecyclerView) findViewById(R.id.Image_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(Home_CategoryItem_Activity.this, 3);
        Image_list.setLayoutManager(mLayoutManager);
        Image_list.setItemAnimator(new DefaultItemAnimator());
        Image_list.setHasFixedSize(true);
        Image_list.setOnScrollListener(new EndlessRecyclerOnScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int current_page) {
                if (mIsLoadingMore) {
                    currentpage = current_page;
                    LoadcategoryItemdata(current_page);
                }
            }
        });

        mAdapter = new ImageAdapter(Home_CategoryItem_Activity.this);
        mAdapter.setClickListener(this);
        Image_list.setAdapter(mAdapter);
        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (mAdapter.getItemViewType(position)) {
                    case ImageAdapter.VIEW_TYPE_ITEM:
                        return 1;
                    case ImageAdapter.VIEW_TYPE_LOADING:
                        return 3;
                    default:
                        return -1;
                }
            }
        });

        LoadcategoryItemdata(currentpage);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onItemClick(int position, ArrayList<Item_collections> arraylist, View v) {
        Constant.passpos = position;
        Constant.passarray = new ArrayList<>();
        Constant.passarray.addAll(arraylist);
        constantfile.loadInterstitialAd(Home_CategoryItem_Activity.this,this);
    }

    @Override
    public void onAdsresponce(Boolean showing) {
        Intent catwise = new Intent(Home_CategoryItem_Activity.this, Home_SingleItem_Activity.class);
        startActivity(catwise);
    }

    @Override
    public void onBackPressed() {
        this.finish();
    }

    public void LoadcategoryItemdata(final int pagenumber) {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (this.conn.booleanValue()) {
            Image_list.setVisibility(View.VISIBLE);
            no_data_text.setVisibility(View.GONE);
            getCatImagesData(pagenumber);
        } else {
            progressBar.setVisibility(View.GONE);
            if (currentpage == 1) {
                mIsLoadingMore = false;
                Image_list.setVisibility(View.GONE);
                no_data_text.setVisibility(View.VISIBLE);
            } else {
                snackbarcommonrelativeLong(Home_CategoryItem_Activity.this, relaivelayout, getResources().getString(R.string.no_internet));
            }
        }
    }

    public void snackbarcommonrelativeLong(Context mcontext, View coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoadcategoryItemdata(currentpage);
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.white));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(Color.BLACK);
        textaction.setTextColor(Color.BLACK);
        snackbar.show();
    }


    public void getCatImagesData(int pageget) {
        RequestParams params = new RequestParams();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        client.setTimeout(60000);
        params.put("page", pageget);
        params.put("cat_id", category_id);
        client.get(Constant.GET_CATWISE_LISTING, params, new AsynchronouseData(pageget));
    }



    class AsynchronouseData extends JsonHttpResponseHandler {

        int getpagenumber;

        AsynchronouseData(int pagenumber) {
            this.getpagenumber = pagenumber;
        }

        public void onStart() {
            super.onStart();
            if (getpagenumber == 1){
                progressBar.setVisibility(View.VISIBLE);
            }
        }

        public void onSuccess(int i, Header[] headers, JSONObject bytes) {

            try {
                JSONArray getdata = bytes.getJSONArray("data");
                ItemData imageData = new ItemData();
                imageData.setStatus(bytes.getBoolean("status"));
                imageData.setMessage(bytes.getString("message"));
                imageData.setLimit(bytes.getString("limit"));
                imageData.setData(constantfile.ConvertJSONtoModel(getdata));

                if (imageData.isStatus()) {
                    mIsLoadingMore = true;
                    if (imageData.getData().size() < Integer.parseInt(imageData.getLimit())) {
                        mIsLoadingMore = false;
                    }
                    mAdapter.adddata(imageData.getData(), getpagenumber);
                    Image_list.setVisibility(View.VISIBLE);
                    no_data_text.setVisibility(View.GONE);
                    progressBar.setVisibility(View.GONE);
                } else {
                    progressBar.setVisibility(View.GONE);
                    if (getpagenumber == 1) {
                        mIsLoadingMore = false;
                        Image_list.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                    }
                    mIsLoadingMore = false;
                }
            } catch (Exception e) {
                progressBar.setVisibility(View.GONE);
                if (!mIsLoadingMore) {
                    mAdapter.setnomoredata();
                }
                if (getpagenumber == 1) {
                    Image_list.setVisibility(View.GONE);
                    no_data_text.setVisibility(View.VISIBLE);
                }
                mIsLoadingMore = false;
            }

            if (!mIsLoadingMore) {
                mAdapter.setnomoredata();
            }


        }

    }

}
