package com.coolposeideas.forphotography;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;

import com.coolposeideas.forphotography.gettersetter.Item_category;
import com.coolposeideas.forphotography.gettersetter.Item_collections;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Constant {

    public static final String CATEGORY_ID = "1";

    public static final String BASIC_URL = "http://simpleappscreator.com/poseandimages_admin/api/";

    public static final String GET_ADD_TOKEN = BASIC_URL+ "api_add_token.php";
    public static final String GET_ADD_VIEW = BASIC_URL+ "api_add_view.php";
    public static final String GET_CATWISE_LISTING = BASIC_URL+ "api_cat_wise.php";
    public static final String GET_HOME_LISTING = BASIC_URL+ "api_home.php";


    public static final String downloadDirectory = "Pose Ideas for Photography";
    public static int Adscount = 1;

    public static final int NOTIFICATION_ID = 100;
    public static final int NOTIFICATION_ID_BIG_IMAGE = 101;

    public static int passpos = 0;
    public static Item_collections Notif_item_object = new Item_collections();
    public static ArrayList<Item_collections> passarray = new ArrayList<>();
    public static Boolean Passing_from_notification = false;


    public static final String SHARED_PREF = "ah_firebase_PosePhotography";
    public static final String SHARED_Token = "regId";
    public static final String TOPIC_GLOBAL = "global";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";


    public void snackbarcommonrelative(Context mcontext, RelativeLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void snackbarcommondrawerLayout(Context mcontext, DrawerLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }


    public ArrayList<Item_collections> ConvertJSONtoModel(JSONArray getarray) throws JSONException {
        ArrayList<Item_collections> temp_array = new ArrayList<>();

        for (int i = 0; i< getarray.length();i++){
            JSONObject pass = getarray.getJSONObject(i);
            Item_collections temp_item = new Item_collections();

            temp_item.setId(pass.getString("id"));
            temp_item.setWall_name(pass.getString("wall_name"));
            temp_item.setWallpaper_image(pass.getString("wallpaper_image"));
            temp_item.setWallpaper_image_thumb(pass.getString("wallpaper_image_thumb"));
            temp_item.setTotal_views(pass.getString("total_views"));
            temp_item.setTotal_download(pass.getString("total_download"));
            temp_item.setWall_tags(pass.getString("wall_tags"));
            temp_item.setDate(pass.getString("date"));
            temp_item.setCat_id(pass.getString("cat_id"));
            temp_item.setCategory_name(pass.getString("category_name"));

            temp_array.add(temp_item);
        }
        return temp_array;
    }

    public ArrayList<Item_category> ConvertJSONCategory(JSONArray getarray) throws JSONException {
        ArrayList<Item_category> temp_array = new ArrayList<>();

        for (int i = 0; i< getarray.length();i++){
            JSONObject pass = getarray.getJSONObject(i);
            Item_category temp_item = new Item_category();
            temp_item.setCid(pass.getString("cid"));
            temp_item.setCategory_name(pass.getString("category_name"));
            temp_item.setCategory_image(pass.getString("category_image"));
            temp_item.setCategory_image_thumb(pass.getString("category_image_thumb"));
            temp_item.setCategory_total_wall(pass.getString("category_total_wall"));
            temp_array.add(temp_item);
        }

        return temp_array;
    }


    Callingafterads callingafter;

    public void loadInterstitialAd(Context mContext, final Callingafterads callingafter) {

        this.callingafter = callingafter;

        final ProgressDialog progress = new ProgressDialog(mContext, R.style.MyAlertDialogStyle);
        progress.setMessage("Loading Ad");
        progress.setCancelable(false);
        progress.show();
        final InterstitialAd interstitialAd = new InterstitialAd(mContext, mContext.getResources().getString(R.string.facebook_interstitial_id));
        interstitialAd.loadAd();
        interstitialAd.setAdListener(new InterstitialAdListener() {
            @Override
            public void onInterstitialDisplayed(Ad ad) {
            }

            @Override
            public void onInterstitialDismissed(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                callingafter.onAdsresponce(true);
            }

            @Override
            public void onError(Ad ad, AdError adError) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd != null) {
                    interstitialAd.destroy();
                }
                callingafter.onAdsresponce(true);
            }

            @Override
            public void onAdLoaded(Ad ad) {
                if (progress.isShowing()) {
                    progress.dismiss();
                }
                if (interstitialAd.isAdLoaded()) {
                    interstitialAd.show();
                }
            }

            @Override
            public void onAdClicked(Ad ad) {
            }

            @Override
            public void onLoggingImpression(Ad ad) {
            }
        });

    }

    public interface Callingafterads {
        void onAdsresponce(Boolean showing);
    }


}
