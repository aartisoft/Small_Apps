package com.coolposeideas.forphotography;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import androidx.core.content.FileProvider;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;

/**
 * Created by SONU on 29/10/15.
 */
public class DownloadTask {

    private static final String TAG = "Download Task";
    private Context context;
    private String downloadUrl = "", downloadFileName = "";
    String action = "download";
    ProgressDialog pd;

    public DownloadTask(Context context, String downloadUrl,String action) {
        this.context = context;
        this.downloadUrl = downloadUrl;
        this.action = action;
        pd = new ProgressDialog(context,R.style.MyAlertDialogStyle);
       // if (action.equals("download") ){
            pd.setMessage("Please Wait...");
            pd.show();
       // }
        final int min = 10;
        final int max = 99;
        final int random1 = new Random().nextInt((max - min) + 1) + min;
        final int random2 = new Random().nextInt((max - min) + 1) + min;

        downloadFileName = "Pose" + random1 + "212" + random2 + ".jpg";//Create file name by picking download file name from URL
        Log.e(TAG, downloadFileName);

        //Start Downloading Task
        new DownloadingTask().execute();
    }

    private class DownloadingTask extends AsyncTask<Void, Void, Void> {

        File apkStorage = null;
        File outputFile = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Log.e("getdownloadprocess", "pre execute "+action);
        }

        @Override
        protected void onPostExecute(Void result) {
            Log.e("getdownloadprocess", "post execute "+action);
            try {
                if (outputFile != null) {

                    if(action.equals("share")){
                        if (pd.isShowing()){
                            pd.dismiss();
                        }
                        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                        Uri screenshotUri = Uri.parse(outputFile.getAbsolutePath());
                        sharingIntent.setType("image/png");
                        sharingIntent.putExtra(Intent.EXTRA_STREAM, screenshotUri);
                        sharingIntent.putExtra(Intent.EXTRA_SUBJECT,context.getResources().getString(R.string.share_message));
                        sharingIntent.putExtra(Intent.EXTRA_TEXT,"https://play.google.com/store/apps/details?id=" + context.getPackageName() + "\n");
                        context.startActivity(Intent.createChooser(sharingIntent, "Share image using"));

                    }else if(action.equals("setas")){
                        Uri uri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".provider",outputFile);
                        Intent intent = new Intent(Intent.ACTION_ATTACH_DATA);
                        intent.addCategory(Intent.CATEGORY_DEFAULT);
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                       // intent.setDataAndType(Uri.fromFile(outputFile),"image/*");
                        intent.setDataAndType(uri,"image/*");
                        intent.putExtra("mimeType","image/*");
                        context.startActivity(Intent.createChooser(intent,"Set Image"));
                    }else{
                        if (pd.isShowing()){
                            pd.dismiss();
                        }
                        Toast.makeText(context, "Download Successful", Toast.LENGTH_SHORT).show();
                        MediaScannerConnection.scanFile(context, new String[]{outputFile.getAbsolutePath()},
                                null,
                                new MediaScannerConnection.OnScanCompletedListener() {
                                    @Override
                                    public void onScanCompleted(String path, Uri uri) {

                                    }
                                });
                    }


                } else {
                    if (pd.isShowing()){
                        pd.dismiss();
                    }
                    Log.e(TAG, "Download Failed");

                }
            } catch (Exception e) {
                if (pd.isShowing()){
                    pd.dismiss();
                }
                e.printStackTrace();


                Log.e(TAG, "Download Failed with Exception - " + e.getLocalizedMessage());

            }


            super.onPostExecute(result);
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            try {
                Log.e("getdownloadprocess", "background try execute ");
                URL url = new URL(downloadUrl);//Create Download URl
                HttpURLConnection c = (HttpURLConnection) url.openConnection();//Open Url Connection
                c.setRequestMethod("GET");//Set Request Method to "GET" since we are grtting data
                c.connect();//connect the URL Connection

                if (c.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    Log.e(TAG, "Server returned HTTP " + c.getResponseCode() + " " + c.getResponseMessage());

                }

                if (new CheckForSDCard().isSDCardPresent()) {
                    apkStorage = new File(Environment.getExternalStorageDirectory() + "/" + Constant.downloadDirectory);
                } else
                    Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();

                if (!apkStorage.exists()) {
                    apkStorage.mkdir();
                    Log.e(TAG, "Directory Created.");
                }

                outputFile = new File(apkStorage, downloadFileName);//Create Output file in Main File

                //Create New File if not present
                if (!outputFile.exists()) {
                    outputFile.createNewFile();
                    Log.e(TAG, "File Created");
                }

                FileOutputStream fos = new FileOutputStream(outputFile);//Get OutputStream for NewFile Location

                InputStream is = c.getInputStream();//Get InputStream for connection

                byte[] buffer = new byte[1024];//Set buffer type
                int len1 = 0;//init length
                while ((len1 = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, len1);//Write new file
                }

                //Close all connection after doing task
                fos.close();
                is.close();

            } catch (Exception e) {

                //Read exception if something went wrong
                e.printStackTrace();
                outputFile = null;
                Log.e("getdownloadprocess", "background catch execute "+e.getMessage());
                Log.e(TAG, "Download Error Exception " + e.getMessage());
            }

            return null;
        }
    }
}
