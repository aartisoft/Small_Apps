package com.coolposeideas.forphotography.Fragment;


import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.coolposeideas.forphotography.Activity.MainActivity;
import com.coolposeideas.forphotography.Constant;
import com.coolposeideas.forphotography.R;
import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;

/**
 * Created by Kakadiyas on 12-03-2017.
 */

public class FeedbackFragment extends Fragment {


    EditText feedback_subject,feedback_edit;
    Button submit_feedback;
    RelativeLayout relaivelayout;
    Constant constantfile;
    private AdView adViewbanner;


    public FeedbackFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.feedbackfragment, container, false);

        constantfile = new Constant();
        relaivelayout = (RelativeLayout) rootView.findViewById(R.id.relaivelayout);
        feedback_subject = (EditText) rootView.findViewById(R.id.feedback_subject);
        feedback_edit = (EditText) rootView.findViewById(R.id.feedback_edit);
        submit_feedback = (Button) rootView.findViewById(R.id.submit_feedback);


        adViewbanner = new AdView(getActivity(), getActivity().getResources().getString(R.string.facebook_banner_id), AdSize.BANNER_HEIGHT_50);
        LinearLayout adContainer = (LinearLayout) rootView.findViewById(R.id.ads);
        adContainer.addView(adViewbanner);
        adViewbanner.loadAd();


        submit_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (feedback_edit.getText().length() > 10){
                    Intent email = new Intent(Intent.ACTION_SEND);
                    email.putExtra(Intent.EXTRA_EMAIL, new String[]{"simpleappscreator@gmail.com"});
                    email.putExtra(Intent.EXTRA_SUBJECT, feedback_subject.getText().toString()+"");
                    email.putExtra(Intent.EXTRA_TEXT, feedback_edit.getText().toString()+"");
                    //need this to prompts email client only
                    email.setType("message/rfc822");
                    startActivity(Intent.createChooser(email, "Choose an Email client :"));
                }else{
                    constantfile.snackbarcommonrelative(getActivity(),relaivelayout,"please write feedback");
                }
            }
        });


        return rootView;
    }


    @Override
    public void onDestroy() {
        if (adViewbanner != null) {
            adViewbanner.destroy();
        }
        super.onDestroy();
    }


    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity)getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name),0);
                }
                return true;
            }
        });

    }
}

