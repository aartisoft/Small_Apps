package com.coolposeideas.forphotography.Fragment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.coolposeideas.forphotography.Activity.Home_CategoryItem_Activity;
import com.coolposeideas.forphotography.Activity.Home_SingleItem_Activity;
import com.coolposeideas.forphotography.Adapter.CategoryAdapter;
import com.coolposeideas.forphotography.Adapter.TrendingAdapter;
import com.coolposeideas.forphotography.gettersetter.HomeData;
import com.coolposeideas.forphotography.gettersetter.Item_category;
import com.coolposeideas.forphotography.gettersetter.Item_collections;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.coolposeideas.forphotography.ConnectionDetector;
import com.coolposeideas.forphotography.Constant;
import com.coolposeideas.forphotography.R;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class HomemainFragment extends Fragment implements CategoryAdapter.MyClickListener,TrendingAdapter.MyClickListener,Constant.Callingafterads  {

    Context context;
    private ConnectionDetector detectorconn;
    Boolean conn;
    private ProgressBar progressBar;
    TextView no_data_text;
    Constant constantfile;
    RelativeLayout relaivelayout;
    LinearLayout linear_data;
    RecyclerView Category_Recycler,Trendning_list;
    CategoryAdapter mAdapter;
    TrendingAdapter TrendingAdapter;
    //InterstitialAd mInterstitialAd;

    public HomemainFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
//        if (Constant.Passing_from_notification){
//            Constant.passpos = 0;
//            Constant.passarray = new ArrayList<>();
//            Constant.passarray.add(Constant.Notif_item_object);
//            opendetailscreen();
//            Constant.Passing_from_notification = false;
//        }
        LoadHomedata();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.homemainfragment, container, false);
        this.conn = null;

        constantfile = new Constant();
        relaivelayout = (RelativeLayout) rootView.findViewById(R.id.relaivelayout);
        linear_data = (LinearLayout) rootView.findViewById(R.id.linear_data);
        linear_data.setVisibility(View.VISIBLE);


        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);


        Trendning_list = (RecyclerView) rootView.findViewById(R.id.Trendning_list);
        LinearLayoutManager horizontalLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        Trendning_list.setLayoutManager(horizontalLayoutManager);

        TrendingAdapter = new TrendingAdapter(getActivity());
        TrendingAdapter.setClickListener(this);
        Trendning_list.setAdapter(TrendingAdapter);

        Category_Recycler = (RecyclerView) rootView.findViewById(R.id.Image_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(),2);
        Category_Recycler.setLayoutManager(mLayoutManager);
        Category_Recycler.setItemAnimator(new DefaultItemAnimator());


        mAdapter = new CategoryAdapter(getActivity());
        mAdapter.setClickListener(this);
        Category_Recycler.setAdapter(mAdapter);

        return rootView;
    }


    public void LoadHomedata() {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (this.conn.booleanValue()) {
            linear_data.setVisibility(View.VISIBLE);
            no_data_text.setVisibility(View.GONE);
            getCategoriesListData();
        } else {
            progressBar.setVisibility(View.GONE);
            linear_data.setVisibility(View.GONE);
            no_data_text.setVisibility(View.VISIBLE);
            snackbarcommonrelativeLong(getActivity(), relaivelayout, getActivity().getResources().getString(R.string.no_internet));

        }
    }

    public void getCategoriesListData() {
        RequestParams params = new RequestParams();
        AsyncHttpClient client = new AsyncHttpClient();
        client.setTimeout(60000);
        params.put("home", "get");
        params.put("catid", Constant.CATEGORY_ID);
        client.get(Constant.GET_HOME_LISTING, params, new AsynchronouseData());
    }


    class AsynchronouseData extends JsonHttpResponseHandler {

        AsynchronouseData() { }

        public void onStart() {
            super.onStart();
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onSuccess(int statusCode, Header[] headers, JSONObject bytes) {
            try {
                JSONArray getcategory = bytes.getJSONArray("category_list");
                JSONArray gettrending = bytes.getJSONArray("trending_list");

                HomeData homeData = new HomeData();
                homeData.setStatus(bytes.getBoolean("status"));
                homeData.setMessage(bytes.getString("message"));

                if (homeData.isStatus()) {
                    if (getcategory.length() > 0) {
                        homeData.setCategory_list(constantfile.ConvertJSONCategory(getcategory));
                        mAdapter.adddata(homeData.getCategory_list());
                    }
                    if (gettrending.length() > 0) {
                        homeData.setTrending_list(constantfile.ConvertJSONtoModel(gettrending));
                        TrendingAdapter.adddata(homeData.getTrending_list());
                    }
                    if (homeData.getCategory_list().size() <= 0 && homeData.getTrending_list().size() <= 0 ) {
                        linear_data.setVisibility(View.GONE);
                        progressBar.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                        return;
                    }
                    linear_data.setVisibility(View.VISIBLE);
                    no_data_text.setVisibility(View.GONE);
                    progressBar.setVisibility(View.GONE);

                } else {

                    progressBar.setVisibility(View.GONE);
                    linear_data.setVisibility(View.GONE);
                    no_data_text.setVisibility(View.VISIBLE);

                }
            } catch (Exception e) {
                progressBar.setVisibility(View.GONE);
                linear_data.setVisibility(View.GONE);
                no_data_text.setVisibility(View.VISIBLE);
            }
        }

    }


    @Override
    public void onItemClick(int position, ArrayList<Item_collections> arraylist, View v) {
        Constant.passpos = position;
        Constant.passarray = new ArrayList<>();
        Constant.passarray.addAll(arraylist);
        constantfile.loadInterstitialAd(getActivity(),this);
    }

    @Override
    public void onAdsresponce(Boolean showing) {
        opendetailscreen();
    }


    public void opendetailscreen(){
        Intent catwise = new Intent(getActivity(), Home_SingleItem_Activity.class);
        startActivity(catwise);
    }

    @Override
    public void onCategoryClick(int position, ArrayList<Item_category> cat_list, View v) {
        Intent catwise = new Intent(getActivity(), Home_CategoryItem_Activity.class);
        catwise.putExtra("category_id", cat_list.get(position).getCid() + "");
        catwise.putExtra("category_title", cat_list.get(position).getCategory_name() + "");
        startActivity(catwise);
    }


    public void snackbarcommonrelativeLong(Context mcontext, View coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoadHomedata();
            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.white));
        TextView textView = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(com.google.android.material.R.id.snackbar_text);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(Color.BLACK);
        textaction.setTextColor(Color.BLACK);
        snackbar.show();
    }
}
