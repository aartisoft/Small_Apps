package com.coolposeideas.forphotography.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.coolposeideas.forphotography.Activity.Favourite_SingleItem_Activity;
import com.coolposeideas.forphotography.Activity.Home_CategoryItem_Activity;
import com.coolposeideas.forphotography.Activity.Home_SingleItem_Activity;
import com.coolposeideas.forphotography.Activity.MainActivity;
import com.coolposeideas.forphotography.Adapter.ImageAdapter;
import com.coolposeideas.forphotography.ConnectionDetector;
import com.coolposeideas.forphotography.Constant;
import com.coolposeideas.forphotography.DbAdapter;
import com.coolposeideas.forphotography.R;
import com.coolposeideas.forphotography.gettersetter.Item_collections;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;

import java.util.ArrayList;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class FavouriteFragment extends Fragment implements ImageAdapter.MyClickListener,Constant.Callingafterads {

    private ConnectionDetector detectorconn;
    Boolean conn;
    ArrayList<Item_collections> arrayofimages;
    private ProgressBar progressBar;
    TextView no_data_text;
    Constant constantfile;
    RelativeLayout relaivelayout;
    RecyclerView Image_list;
    ImageAdapter mAdapter;
    DbAdapter db;

    public FavouriteFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.activity_category, container, false);
        this.conn = null;

        constantfile = new Constant();
        relaivelayout = (RelativeLayout) rootView.findViewById(R.id.relaivelayout);

        db = new DbAdapter(getActivity());
        db.open();

        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        no_data_text.setVisibility(View.GONE);


        Image_list = (RecyclerView) rootView.findViewById(R.id.Image_list);
        GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        Image_list.setLayoutManager(mLayoutManager);
        Image_list.setItemAnimator(new DefaultItemAnimator());

        mAdapter = new ImageAdapter(getActivity());
        mAdapter.setClickListener(this);
        Image_list.setAdapter(mAdapter);

        arrayofimages = new ArrayList<Item_collections>();
        Cursor row = db.fetchAllData();
        for (row.moveToFirst(); !row.isAfterLast(); row.moveToNext()) {
            Item_collections fav_item = new Item_collections();
            fav_item.setId(row.getString(row.getColumnIndex("unique_id")));
            fav_item.setWall_name("");
            fav_item.setWallpaper_image(row.getString(row.getColumnIndex("image_thumb")));
            fav_item.setWallpaper_image_thumb(row.getString(row.getColumnIndex("image_url")));
            fav_item.setTotal_views("");
            fav_item.setTotal_download("");
            fav_item.setWall_tags("");
            fav_item.setDate("");
            fav_item.setCat_id("");
            fav_item.setCategory_name(row.getString(row.getColumnIndex("category")));
            arrayofimages.add(fav_item);
       }
        mAdapter.adddata(arrayofimages,1);
        mAdapter.setnomoredata();

        if (arrayofimages.size() <= 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }


        return rootView;
    }



    @Override
    public void onResume() {
        super.onResume();
        db = new DbAdapter(getActivity());
        db.open();
        arrayofimages = new ArrayList<Item_collections>();
        Cursor row = db.fetchAllData();
        for (row.moveToFirst(); !row.isAfterLast(); row.moveToNext()) {
            Item_collections fav_item = new Item_collections();
            fav_item.setId(row.getString(row.getColumnIndex("unique_id")));
            fav_item.setWall_name("");
            fav_item.setWallpaper_image(row.getString(row.getColumnIndex("image_thumb")));
            fav_item.setWallpaper_image_thumb(row.getString(row.getColumnIndex("image_url")));
            fav_item.setTotal_views("");
            fav_item.setTotal_download("");
            fav_item.setWall_tags("");
            fav_item.setDate("");
            fav_item.setCat_id("");
            fav_item.setCategory_name(row.getString(row.getColumnIndex("category")));
            arrayofimages.add(fav_item);
        }
        mAdapter.adddata(arrayofimages,1);
        mAdapter.setnomoredata();


        if (arrayofimages.size() <= 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name), 0);
                }
                return true;
            }
        });

    }

    @Override
    public void onItemClick(int position, ArrayList<Item_collections> passarray, View v) {
        Constant.passpos = position;
        Constant.passarray = new ArrayList<>();
        Constant.passarray.addAll(arrayofimages);
        constantfile.loadInterstitialAd(getActivity(),this);

    }

    @Override
    public void onAdsresponce(Boolean showing) {
        Intent catwise = new Intent(getActivity(), Favourite_SingleItem_Activity.class);
        startActivity(catwise);
    }

}
