package com.inspiringsuccess.storiesinhindi.Fragment;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.facebook.ads.AdSize;
import com.facebook.ads.AdView;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.inspiringsuccess.storiesinhindi.Activity.MainActivity;
import com.inspiringsuccess.storiesinhindi.Constant;
import com.inspiringsuccess.storiesinhindi.DbAdapter;
import com.inspiringsuccess.storiesinhindi.R;
import com.inspiringsuccess.storiesinhindi.gettersetter.ItemUpdate;
import com.inspiringsuccess.storiesinhindi.gettersetter.Item_images;
import com.inspiringsuccess.storiesinhindi.widgets.EnchantedViewPager;

import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;


/**
 * Created by Kakadiyas on 12-03-2017.
 */

public class DetailFragment extends Fragment {


    RelativeLayout relative;
    Constant constantfile;
    ImageView submit_home, submit_whatsapp, submit_fav, submit_share;

    TextView no_data_text;

    EnchantedViewPager mViewPager;
    CustomViewPagerAdapter mAdapter;
    ArrayList<Item_images> detail_item_list;
    int detail_position;

    DbAdapter db;

    public DetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.detailfragment, container, false);

        constantfile = new Constant();

        relative = (RelativeLayout) rootView.findViewById(R.id.relative);
        db = new DbAdapter(getActivity());
        db.open();
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        submit_home = (ImageView) rootView.findViewById(R.id.submit_home);
        submit_whatsapp = (ImageView) rootView.findViewById(R.id.submit_whatsapp);
        submit_fav = (ImageView) rootView.findViewById(R.id.submit_fav);
        submit_share = (ImageView) rootView.findViewById(R.id.submit_share);

        mViewPager = rootView.findViewById(R.id.viewPager);

        showData();

        submit_whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                constantfile.snackbarcommonview(getActivity(), relative, "Processing");
                String finalString = "";
                String ShareString = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    finalString = String.valueOf(Html.fromHtml(""+detail_item_list.get(detail_position).getItem_description(), Html.FROM_HTML_MODE_COMPACT));
                } else {
                    finalString = String.valueOf((Html.fromHtml(""+ detail_item_list.get(detail_position).getItem_description())));
                }
                if (finalString.length() > 1000) {
                    ShareString = finalString.substring(0, 1000);
                } else {
                    ShareString = finalString;
                }

                if (null != ShareString && ShareString.length() > 0 )
                {
                    int endIndex = ShareString.lastIndexOf(".");
                    if (endIndex != -1)
                    {
                        ShareString = ShareString.substring(0, endIndex); // not forgot to put check if(endIndex != -1)
                    }
                }

                String shareBody = ShareString+"...\n\n"+ getActivity().getResources().getString(R.string.share_message) +
                        "\n\n https://play.google.com/store/apps/details?id="+getActivity().getPackageName();
                Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
                whatsappIntent.setType("text/plain");
                whatsappIntent.setPackage("com.whatsapp");
                whatsappIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                try {
                    startActivity(whatsappIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    constantfile.snackbarcommonview(getActivity(),relative,"Whatsapp have not been installed");
                }
            }
        });

        submit_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                constantfile.snackbarcommonview(getActivity(), relative, "Processing");
                String finalString = "";
                String ShareString = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    finalString = String.valueOf(Html.fromHtml(""+detail_item_list.get(detail_position).getItem_description(), Html.FROM_HTML_MODE_COMPACT));
                } else {
                    finalString = String.valueOf((Html.fromHtml(""+ detail_item_list.get(detail_position).getItem_description())));
                }
                if (finalString.length() > 1000) {
                    ShareString = finalString.substring(0, 1000);
                } else {
                    ShareString = finalString;
                }

                if (null != ShareString && ShareString.length() > 0 )
                {
                    int endIndex = ShareString.lastIndexOf(".");
                    if (endIndex != -1)
                    {
                        ShareString = ShareString.substring(0, endIndex); // not forgot to put check if(endIndex != -1)
                    }
                }

                String shareBody = ShareString+"...\n\n"+ getActivity().getResources().getString(R.string.share_message) +
                        "\n\n https://play.google.com/store/apps/details?id="+getActivity().getPackageName();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, getActivity().getResources().getString(R.string.app_name));
                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });

        submit_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name), 0);
            }
        });

        submit_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Item_images temp_get = detail_item_list.get(detail_position);

                String uniqueid = temp_get.getId();
                if(db.isExist(uniqueid)){
                    db.delete(uniqueid);
                    submit_fav.setImageResource(R.drawable.ic_favorite);
                    constantfile.snackbarcommonview(getActivity(), relative, "Remove from Favourite Successfully!");
                }else{
                    String name = temp_get.getItem_title();
                    String details = temp_get.getItem_description();
                    String image = temp_get.getItem_description();
                    String image_thumb = temp_get.getItem_description();
                    String total_views = temp_get.getItem_description();
                    String date = temp_get.getItem_description();
                    String cat_id = temp_get.getItem_description();
                    String cat_name = temp_get.getItem_description();

                    db.insert(uniqueid,name,details,image,image_thumb,total_views,date,cat_id,cat_name);
                    submit_fav.setImageResource(R.drawable.ic_favorite_done);
                    constantfile.snackbarcommonview(getActivity(), relative, "Add to Favourite Successfully!");
                }
            }
        });



        return rootView;
    }

    private void showData() {


        detail_item_list = new ArrayList<>();
        detail_item_list.addAll(Constant.Passing_item_array);
        int ii = detail_item_list.size();
        if (ii == 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }
        detail_position = getIndexByProperty(Constant.Passing_item_id);
        setAdapterToListview();
    }

    public void setAdapterToListview() {
        mAdapter = new CustomViewPagerAdapter();
        mViewPager.useScale();
        mViewPager.removeAlpha();
        mViewPager.setAdapter(mAdapter);

        if (detail_position != -1) {
            CallAddView(detail_item_list.get(detail_position).getId());
            mViewPager.setCurrentItem(detail_position);
            String uniqueid = detail_item_list.get(detail_position).getId();
            if(db.isExist(uniqueid)){
                submit_fav.setImageResource(R.drawable.ic_favorite_done);
            }else{
                submit_fav.setImageResource(R.drawable.ic_favorite);
            }
        }

        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

                // Log.e("scrolllistner","onpagescroll :: "+i);
            }

            @Override
            public void onPageSelected(int i) {
                Log.e("scrolllistner","onpagescrollchange :: "+i);
                detail_position = i;
                ((MainActivity) getActivity()).changetitle(detail_item_list.get(i).getItem_title());
                String uniqueid = detail_item_list.get(detail_position).getId();
                if(db.isExist(uniqueid)){
                    submit_fav.setImageResource(R.drawable.ic_favorite_done);
                }else{
                    submit_fav.setImageResource(R.drawable.ic_favorite);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {
                // Log.e("scrolllistner","onpagescrollchange :: "+i);
            }
        });

    }


    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity) getActivity()).changetitle(getActivity().getResources().getString(R.string.app_name));
                    FragmentManager fm = getActivity().getSupportFragmentManager();
                    fm.popBackStack(Constant.Passing_From, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    ((MainActivity) getActivity()).changetitle(getActivity().getResources().getString(R.string.app_name));
                }
                return true;
            }
        });

    }

    private class CustomViewPagerAdapter extends PagerAdapter {
        private LayoutInflater inflater;

        private CustomViewPagerAdapter() {
            inflater = getLayoutInflater();
        }

        @Override
        public int getCount() {
            return detail_item_list.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            View detailLayout = inflater.inflate(R.layout.fullscreenitem_layout, container, false);
            assert detailLayout != null;
            TextView item_details = (TextView) detailLayout.findViewById(R.id.item_details);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                item_details.setText(Html.fromHtml(detail_item_list.get(position).getItem_description(), Html.FROM_HTML_MODE_COMPACT));
            } else {
                item_details.setText(Html.fromHtml(detail_item_list.get(position).getItem_description()));
            }

            container.addView(detailLayout, 0);
            return detailLayout;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            (container).removeView((View) object);
        }
    }

    private int getIndexByProperty(String yourString) {
        for (int i = 0; i < detail_item_list.size(); i++) {
            if (detail_item_list != null && detail_item_list.get(i).getId().equals(yourString)) {
                return i;
            }
        }
        return -1;
    }


    public void CallAddView(String PassID) {
        RequestParams params = new RequestParams();
        AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);
        client.setTimeout(60000);
        params.put("item_id", PassID);
        client.get(Constant.GET_ADD_VIEW, params, new AsynchronouseData());
    }


    class AsynchronouseData extends JsonHttpResponseHandler {

        AsynchronouseData() {
        }

        public void onStart() {
            super.onStart();
        }

        public void onSuccess(int i, Header[] headers, JSONObject bytes) {


            try {
                ItemUpdate statusData = new ItemUpdate();
                statusData.setStatus(bytes.getBoolean("status"));
                statusData.setMessage(bytes.getString("message"));
                if (statusData.isStatus()) {

                } else {

                }
                Log.e("calladdviewApi", "response :: " + bytes.getBoolean("status"));
            } catch (Exception e) {
            }


        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}

