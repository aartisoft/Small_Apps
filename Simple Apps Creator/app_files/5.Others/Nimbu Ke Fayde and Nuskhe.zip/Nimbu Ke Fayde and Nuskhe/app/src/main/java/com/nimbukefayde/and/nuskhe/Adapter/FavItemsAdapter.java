package com.nimbukefayde.and.nuskhe.Adapter;


import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.nimbukefayde.and.nuskhe.R;
import com.nimbukefayde.and.nuskhe.gettersetter.Item_getset;

import java.util.ArrayList;
import java.util.List;

public class FavItemsAdapter extends RecyclerView.Adapter<FavItemsAdapter.DataObjectHolder> implements Filterable {
    private static String LOG_TAG = "MyRecyclerViewAdapter";
    private ArrayList<Item_getset> itemsList = new ArrayList<>();
    private List<Item_getset> itemsListFiltered = new ArrayList<>();
    Activity main;
    private static MyClickListener myClickListener;
    private Context context;

    public static class DataObjectHolder extends RecyclerView.ViewHolder{

        ImageView image_detail;
        TextView item_title;
        CardView item_cardview;


        public DataObjectHolder(View itemView) {
            super(itemView);
            image_detail = (ImageView) itemView.findViewById(R.id.image_detail);
            item_title = (TextView) itemView.findViewById(R.id.item_title);
            item_cardview = (CardView) itemView.findViewById(R.id.item_cardview);

        }

    }

    public FavItemsAdapter(Context context, ArrayList<Item_getset> subcategoryList) {
        this.context = context;
        this.itemsList.addAll(subcategoryList);
        this.itemsListFiltered.addAll(subcategoryList);
        notifyDataSetChanged();
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item_row, parent, false);
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(final DataObjectHolder holder, final int position) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            holder.item_title.setText(Html.fromHtml(itemsListFiltered.get(position).getItem_name()+"", Html.FROM_HTML_MODE_COMPACT));
        } else {
            holder.item_title.setText(Html.fromHtml(itemsListFiltered.get(position).getItem_name()+""));
        }

        holder.item_cardview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myClickListener.onItemClick(position,itemsListFiltered.get(position), v);
            }
        });
    }



    @Override
    public int getItemCount() {
        return itemsListFiltered.size();
    }

    public interface MyClickListener {
        void onItemClick(int position,Item_getset pass_getset, View v);
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    itemsListFiltered = itemsList;
                } else {
                    List<Item_getset> filteredList = new ArrayList<>();
                    for (Item_getset row : itemsList) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getItem_name().toLowerCase().contains(charString.toLowerCase()) || row.getItem_details().contains(charSequence)) {
                            filteredList.add(row);
                        }
                    }

                    itemsListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = itemsListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                itemsListFiltered = (ArrayList<Item_getset>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

}
