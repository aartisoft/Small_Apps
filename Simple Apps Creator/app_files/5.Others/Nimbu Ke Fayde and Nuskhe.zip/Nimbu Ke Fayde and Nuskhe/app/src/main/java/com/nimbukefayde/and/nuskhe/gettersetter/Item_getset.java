package com.nimbukefayde.and.nuskhe.gettersetter;

public class Item_getset {

	private String item_id;
	private String item_name;
	private String item_details;

	public Item_getset() {
	}

	public Item_getset(String item_id,String item_name,String item_details) {
		this.item_id=item_id;
		this.item_name=item_name;
		this.item_details=item_details;
	}


	public String getItem_id() {
		return item_id;
	}

	public void setItem_id(String item_id) {
		this.item_id = item_id;
	}

	public String getItem_name() {
		return item_name;
	}

	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}

	public String getItem_details() {
		return item_details;
	}

	public void setItem_details(String item_details) {
		this.item_details = item_details;
	}



	public String toString() {
		return "ClassPojo [item_id = " + this.item_id + ", item_name = " + this.item_name + ", item_details = " + this.item_details + "]";
	}

}
