package com.nimbukefayde.and.nuskhe.Activity;


import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.nimbukefayde.and.nuskhe.ConnectionDetector;
import com.nimbukefayde.and.nuskhe.Constant;
import com.nimbukefayde.and.nuskhe.DbAdapter;
import com.nimbukefayde.and.nuskhe.Fragment.DetailFragment;
import com.nimbukefayde.and.nuskhe.Fragment.FavDetailFragment;
import com.nimbukefayde.and.nuskhe.Fragment.FavouriteFragment;
import com.nimbukefayde.and.nuskhe.Fragment.HomeFragment;
import com.nimbukefayde.and.nuskhe.Fragment.PrivacyPolicyFragment;
import com.nimbukefayde.and.nuskhe.R;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    //TextView tool_title;
    ImageView drawer_back;
    Toolbar toolbar;
    private ConnectionDetector detectorconn;
    Boolean conn;
    private int fragmentposition = 0;
    Constant constantfile;
    String title_text = "";
    DrawerLayout drawer_layout;
    private AlertDialog alert;
    NavigationView navigationView;
    private FirebaseAnalytics mFirebaseAnalytics;

    DbAdapter db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //tool_title = (TextView) toolbar.findViewById(R.id.tool_title);

        title_text = getResources().getString(R.string.app_name);
        toolbar.setTitle(title_text);
        db = new DbAdapter(this);
        db.open();

        this.conn = null;
        constantfile = new Constant();
        drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        drawer_back = (ImageView) navigationView.findViewById(R.id.drawer_back);

        this.detectorconn = new ConnectionDetector(getApplicationContext());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_menu, getApplicationContext().getTheme()));
        } else {
            toolbar.setNavigationIcon(getResources().getDrawable(R.drawable.ic_menu));
        }

        navigationView.setNavigationItemSelectedListener(this);

        SelectItem(title_text, fragmentposition);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);

        final SharedPreferences pref = getApplicationContext().getSharedPreferences(Constant.SHARED_PREF, 0);


        if (pref.getString("regId", null) != null) {
            String regId = pref.getString("regId", null);
        } else {
            FirebaseInstanceId.getInstance().getInstanceId()
                    .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                        @Override
                        public void onComplete(@NonNull Task<InstanceIdResult> task) {
                            if (!task.isSuccessful()) {
                                return;
                            }
                            String token = task.getResult().getToken();
                            pref.edit().putString("regId",token).commit();
                            Log.e("gettingfirebasetoken",token+"      ::::");
                        }
                    });
            BroadcastReceiver mRegistrationBroadcastReceiver = new BroadcastReceiver() {
                @SuppressLint("NewApi")
                @Override
                public void onReceive(Context context, Intent intent) {
                    if (Objects.equals(intent.getAction(), Constant.REGISTRATION_COMPLETE)) {
                        FirebaseMessaging.getInstance().subscribeToTopic(Constant.TOPIC_GLOBAL);
                    } else if (Objects.equals(intent.getAction(), Constant.PUSH_NOTIFICATION)) {
                        String message = intent.getStringExtra("message");
                    }
                }
            };
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            AppExit();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        boolean changefragment = false;
        if (id == R.id.nav_home) {
            changefragment = true;
            fragmentposition = 0;
            title_text = getResources().getString(R.string.app_name);
        } else if (id == R.id.nav_favourite) {
            changefragment = true;
            fragmentposition = 1;
            title_text = getResources().getString(R.string.favoritlist_title);
        } else if (id == R.id.nav_rate_us) {
            getRateAppCounter();
        } else if (id == R.id.nav_share_app) {
            getShareCounter();
        } else if (id == R.id.nav_policy) {
            getopenPrivacypolicy();
        } else if (id == R.id.nav_exit_app) {
            AppExit();
        }
        if (changefragment){
            SelectItem(title_text, fragmentposition);
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void SelectItem(String title, int fragmentpos) {
        fragmentposition = fragmentpos;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            toolbar.setTitle(Html.fromHtml(title, Html.FROM_HTML_MODE_COMPACT));
        } else {
            toolbar.setTitle(Html.fromHtml(title));
        }
        Fragment fragment = null;
        if (fragmentpos < 0) {
            return;
        } else {
            if (fragmentpos == 0) {
                fragment = new HomeFragment();
            } else if (fragmentpos == 1) {
                fragment = new FavouriteFragment();
            } else if (fragmentpos == 2) {
                fragment = new PrivacyPolicyFragment();
            } else if (fragmentpos == 3) {
                fragment = new DetailFragment();
            }else if (fragmentpos == 4) {
                fragment = new FavDetailFragment();
            }

        }

        if (fragment != null) {

//            if (fragmentposition == 0){
//                FragmentTransaction ft = fragmentManager.beginTransaction();
//                ft.add(R.id.content_main, fragment);
//                ft.addToBackStack(null);
//                ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
//                ft.commit();
//            }else{
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_main, fragment).commit();
                if (fragmentposition == 0) {
                    navigationView.getMenu().getItem(0).setChecked(true);
                }
            //}

        }
    }

    public void changetitle(String title){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            toolbar.setTitle(Html.fromHtml(title, Html.FROM_HTML_MODE_COMPACT));
        } else {
            toolbar.setTitle(Html.fromHtml(title));
        }
    }


    public void getRateAppCounter() {
        Uri uri = Uri.parse("market://details?id=" + getPackageName());
        Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
        goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        try {
            startActivity(goToMarket);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
        }
    }

    public void getopenPrivacypolicy() {
        String url = "https://simpleappscreatorpolicy.blogspot.com/2019/07/status-policy.html";
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    public void getShareCounter() {
        constantfile.snackbarcommondrawerLayout(MainActivity.this, drawer_layout, "Processing");
        String whatsAppMessage = getResources().getString(R.string.share_message) + "\n\n";
        whatsAppMessage = whatsAppMessage + "https://play.google.com/store/apps/details?id=" + getApplicationContext().getPackageName() + "\n";
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, whatsAppMessage);
        sendIntent.setType("text/plain");
        startActivity(sendIntent);

    }

    public void send_feedback() {
        constantfile.snackbarcommondrawerLayout(MainActivity.this, drawer_layout, "Processing");
        Intent email = new Intent(Intent.ACTION_SEND);
        email.putExtra(Intent.EXTRA_EMAIL, new String[]{"simpleappscreator@gmail.com"});
        email.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name));
        email.putExtra(Intent.EXTRA_TEXT, "");
        email.setType("message/rfc822");
        startActivity(Intent.createChooser(email, "Send email"));

    }


    public void AppExit() {
        AlertDialog.Builder exitDialog = new AlertDialog.Builder(MainActivity.this);
        exitDialog.setTitle("Are you sure....?");
        exitDialog.setMessage("If you like this app please give us positive feedback.");
        exitDialog.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
                System.exit(0);
            }
        });
        exitDialog.setNegativeButton("Dismiss", null);
        exitDialog.setNeutralButton("RATE US", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Uri uri = Uri.parse("market://details?id=" + getPackageName());
                Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
                goToMarket.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                try {
                    startActivity(goToMarket);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + getPackageName())));
                }
            }
        });
        AlertDialog errorAlert = exitDialog.create();
        errorAlert.show();
        errorAlert.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.BLACK);
        errorAlert.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.BLACK);
        errorAlert.getButton(AlertDialog.BUTTON_NEUTRAL).setTextColor(Color.BLACK);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        return true;
    }


}
