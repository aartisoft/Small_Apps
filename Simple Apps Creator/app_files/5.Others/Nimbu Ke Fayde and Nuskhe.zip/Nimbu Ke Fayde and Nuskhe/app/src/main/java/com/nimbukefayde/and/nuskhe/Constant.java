package com.nimbukefayde.and.nuskhe;

import android.content.Context;
import android.graphics.Color;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.snackbar.Snackbar;
import com.nimbukefayde.and.nuskhe.R;
import com.nimbukefayde.and.nuskhe.gettersetter.Item_getset;

import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class Constant {
    public static final String SHARED_PREF = "ah_firebase";
    public static final String TOPIC_GLOBAL = "global";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";
    public static String Passing_item_id = "";
    public static ArrayList<Item_getset> Passing_item_array = new ArrayList<>();

    public void snackbarcommonrelative(Context mcontext, RelativeLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void snackbarcommonlinear(Context mcontext, LinearLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void snackbarcommoncoordinatorLayout(Context mcontext, CoordinatorLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void snackbarcommondrawerLayout(Context mcontext, DrawerLayout coordinatorLayout, String snackmsg){
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg+"", Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        textView.setTextSize(16);
        textView.setTextColor(Color.WHITE);
        snackbar.show();
    }

    public void ProgressDialog(ImageView progressBar, boolean visible){
        if (visible){
//            progressBar.setBackgroundResource(R.drawable.progress_image);
//            AnimationDrawable animationDrawable = (AnimationDrawable)progressBar.getBackground();
//            progressBar.setVisibility(View.VISIBLE);
//            animationDrawable.start();
        }else{
//            progressBar.setBackgroundResource(R.drawable.progress_image);
//            AnimationDrawable animationDrawable = (AnimationDrawable)progressBar.getBackground();
//            progressBar.setVisibility(View.GONE);
//            animationDrawable.stop();
        }

    }


}
