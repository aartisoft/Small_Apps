package com.nimbukefayde.and.nuskhe.Fragment;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.nimbukefayde.and.nuskhe.Activity.MainActivity;
import com.nimbukefayde.and.nuskhe.Constant;
import com.nimbukefayde.and.nuskhe.DbAdapter;
import com.nimbukefayde.and.nuskhe.R;
import com.nimbukefayde.and.nuskhe.gettersetter.Item_getset;
import com.nimbukefayde.and.nuskhe.widgets.EnchantedViewPager;

import java.util.ArrayList;


/**
 * Created by Kakadiyas on 12-03-2017.
 */

public class DetailFragment extends Fragment {


    RelativeLayout relative;
    Constant constantfile;
    ImageView submit_home, submit_whatsapp, submit_fav, submit_share;

    TextView no_data_text;

    EnchantedViewPager mViewPager;
    CustomViewPagerAdapter mAdapter;
    ArrayList<Item_getset> detail_item_list;
    int detail_position;

    DbAdapter db;

    public DetailFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.detailfragment, container, false);

        constantfile = new Constant();

        relative = (RelativeLayout) rootView.findViewById(R.id.relative);
        db = new DbAdapter(getActivity());
        db.open();
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        submit_home = (ImageView) rootView.findViewById(R.id.submit_home);
        submit_whatsapp = (ImageView) rootView.findViewById(R.id.submit_whatsapp);
        submit_fav = (ImageView) rootView.findViewById(R.id.submit_fav);
        submit_share = (ImageView) rootView.findViewById(R.id.submit_share);

        mViewPager = rootView.findViewById(R.id.viewPager);

        showData();


        submit_whatsapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                constantfile.snackbarcommonrelative(getActivity(), relative, "Processing");
                String finalString = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    finalString = String.valueOf(Html.fromHtml(""+detail_item_list.get(detail_position).getItem_details(), Html.FROM_HTML_MODE_COMPACT));
                } else {
                    finalString = String.valueOf((Html.fromHtml(""+ detail_item_list.get(detail_position).getItem_details())));
                }
                String shareBody = finalString+"\n\n"+
                                    getActivity().getResources().getString(R.string.share_message) +
                                    "\n\n https://play.google.com/store/apps/details?id="+getActivity().getPackageName();
                Intent whatsappIntent = new Intent(Intent.ACTION_SEND);
                whatsappIntent.setType("text/plain");
                whatsappIntent.setPackage("com.whatsapp");
                whatsappIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                try {
                    startActivity(whatsappIntent);
                } catch (android.content.ActivityNotFoundException ex) {
                    constantfile.snackbarcommonrelative(getActivity(),relative,"Whatsapp have not been installed");
                }
            }
        });

        submit_share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                constantfile.snackbarcommonrelative(getActivity(), relative, "Processing");
                String finalString = "";
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    finalString = String.valueOf(Html.fromHtml(""+detail_item_list.get(detail_position).getItem_details(), Html.FROM_HTML_MODE_COMPACT));
                } else {
                    finalString = String.valueOf((Html.fromHtml(""+ detail_item_list.get(detail_position).getItem_details())));
                }
                String shareBody = finalString+"\n\n"+
                        getActivity().getResources().getString(R.string.share_message) +
                        "\n\n https://play.google.com/store/apps/details?id="+getActivity().getPackageName();
                Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(Intent.EXTRA_SUBJECT, "Raksha Bandhan Status");
                sharingIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share via"));
            }
        });

        submit_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name), 0);
            }
        });

        submit_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Item_getset temp_get = detail_item_list.get(detail_position);

                String uniqueid = temp_get.getItem_id();
                if(db.isExist(uniqueid)){
                    db.delete(uniqueid);
                    submit_fav.setImageResource(R.drawable.ic_favorite);
                    constantfile.snackbarcommonrelative(getActivity(), relative, "Remove from Favourite Successfully!");
                }else{
                    String name = temp_get.getItem_name();
                    String details = temp_get.getItem_details();
                    db.insert(uniqueid,name,details);
                    submit_fav.setImageResource(R.drawable.ic_favorite_done);
                    constantfile.snackbarcommonrelative(getActivity(), relative, "Add to Favourite Successfully!");
                }
            }
        });



        return rootView;
    }

    private void showData() {
        detail_item_list = new ArrayList<>();
        detail_item_list.addAll(Constant.Passing_item_array);
        int ii = detail_item_list.size();
        if (ii == 0) {
            no_data_text.setVisibility(View.VISIBLE);
        } else {
            no_data_text.setVisibility(View.GONE);
        }
        detail_position = getIndexByProperty(Constant.Passing_item_id);
        setAdapterToListview();
    }

    public void setAdapterToListview() {
        mAdapter = new CustomViewPagerAdapter();
        mViewPager.useScale();
        mViewPager.removeAlpha();
        mViewPager.setAdapter(mAdapter);

        if (detail_position != -1) {
            mViewPager.setCurrentItem(detail_position);
            String uniqueid = detail_item_list.get(detail_position).getItem_id();
            if(db.isExist(uniqueid)){
                submit_fav.setImageResource(R.drawable.ic_favorite_done);
            }else{
                submit_fav.setImageResource(R.drawable.ic_favorite);
            }
        }

        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

                // Log.e("scrolllistner","onpagescroll :: "+i);
            }

            @Override
            public void onPageSelected(int i) {
                Log.e("scrolllistner","onpagescrollchange :: "+i);
                detail_position = i;
                ((MainActivity) getActivity()).changetitle(detail_item_list.get(i).getItem_name());
                String uniqueid = detail_item_list.get(detail_position).getItem_id();
                if(db.isExist(uniqueid)){
                    submit_fav.setImageResource(R.drawable.ic_favorite_done);
                }else{
                    submit_fav.setImageResource(R.drawable.ic_favorite);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {
                // Log.e("scrolllistner","onpagescrollchange :: "+i);
            }
        });

    }


    @Override
    public void onResume() {
        super.onResume();
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    ((MainActivity) getActivity()).SelectItem(getActivity().getResources().getString(R.string.app_name), 0);
                }
                return true;
            }
        });

    }

    private class CustomViewPagerAdapter extends PagerAdapter {
        private LayoutInflater inflater;

        private CustomViewPagerAdapter() {
            inflater = getLayoutInflater();
        }

        @Override
        public int getCount() {
            return detail_item_list.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public Object instantiateItem(ViewGroup container, final int position) {
            View detailLayout = inflater.inflate(R.layout.fullscreenitem_layout, container, false);
            assert detailLayout != null;
            TextView item_details = (TextView) detailLayout.findViewById(R.id.item_details);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                item_details.setText(Html.fromHtml(detail_item_list.get(position).getItem_details(), Html.FROM_HTML_MODE_COMPACT));
            } else {
                item_details.setText(Html.fromHtml(detail_item_list.get(position).getItem_details()));
            }

            container.addView(detailLayout, 0);
            return detailLayout;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            (container).removeView((View) object);
        }
    }

    private int getIndexByProperty(String yourString) {
        for (int i = 0; i < detail_item_list.size(); i++) {
            if (detail_item_list != null && detail_item_list.get(i).getItem_id().equals(yourString)) {
                return i;
            }
        }
        return -1;
    }
}

