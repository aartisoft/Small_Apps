package com.nimbukefayde.and.nuskhe.Fragment;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.Transition;
import androidx.transition.TransitionInflater;
import androidx.transition.TransitionManager;

import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AudienceNetworkAds;
import com.facebook.ads.InterstitialAd;
import com.facebook.ads.InterstitialAdListener;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.nimbukefayde.and.nuskhe.Activity.MainActivity;
import com.nimbukefayde.and.nuskhe.Adapter.MainItemAdapter;
import com.nimbukefayde.and.nuskhe.ConnectionDetector;
import com.nimbukefayde.and.nuskhe.Constant;
import com.nimbukefayde.and.nuskhe.EndlessRecyclerOnScrollListener;
import com.nimbukefayde.and.nuskhe.R;
import com.nimbukefayde.and.nuskhe.gettersetter.Item_getset;

import java.util.ArrayList;

/**
 * Created by Kakadiyas on 12-03-2017.
 */
public class HomeFragment extends Fragment implements MainItemAdapter.MyClickListener {

    public static final String TAG = "Main_list";
    private ConnectionDetector detectorconn;
    Boolean conn;
    Constant constantfile;
    private AlertDialog alert;
    RelativeLayout content_home;
    ArrayList<Item_getset> main_item_list;
    RecyclerView items_recycler;
    TextView no_data_text;
    MainItemAdapter mainAdapter;
    private SearchView searchView;


    private ProgressBar progressBar;

    private int currentpage = 0;
    private boolean mIsLoadingMore;
    private static final int TOTAL_ITEM_EACH_LOAD = 15;
    String oldestKeyYouveSeen = null;
    String searchtext = "";
    final FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference().child("BoL_list");

    public HomeFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View rootView = inflater.inflate(R.layout.homefragment, container, false);
        setHasOptionsMenu(true);
        main_item_list = new ArrayList<>();
        this.conn = null;
        constantfile = new Constant();
        if (!AudienceNetworkAds.isInAdsProcess(getActivity())){
            AudienceNetworkAds.initialize(getActivity());
        }
        this.detectorconn = new ConnectionDetector(getActivity());
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        this.currentpage = 0;
        this.mIsLoadingMore = false;

        content_home = (RelativeLayout) rootView.findViewById(R.id.content_home);
        progressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);
        items_recycler = (RecyclerView) rootView.findViewById(R.id.items_recycler);
        no_data_text = (TextView) rootView.findViewById(R.id.no_data_text);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        items_recycler.setLayoutManager(mLayoutManager);
        items_recycler.setItemAnimator(new DefaultItemAnimator());
        items_recycler.setHasFixedSize(true);
        items_recycler.setOnScrollListener(new EndlessRecyclerOnScrollListener(mLayoutManager) {
            @Override
            public void onLoadMore(int current_page) {
                if (mIsLoadingMore && searchtext.equals("")) {
                    currentpage++;
                    LoadImagedata(current_page);
                }
            }
        });
        mainAdapter = new MainItemAdapter(getActivity());
        mainAdapter.setClickListener(this);
        items_recycler.setAdapter(mainAdapter);


        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        getActivity().getMenuInflater().inflate(R.menu.menu_main, menu);

        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        searchView = (SearchView) menu.findItem(R.id.action_search).getActionView();
        View v = searchView.findViewById(R.id.search_plate);
        v.setBackgroundColor(getActivity().getResources().getColor(R.color.white));
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setQueryHint("Search...");
        LinearLayout searchEditFrame = (LinearLayout) searchView.findViewById(R.id.search_edit_frame);
        ((LinearLayout.LayoutParams) searchEditFrame.getLayoutParams()).leftMargin = -25;
        MenuItemCompat.setOnActionExpandListener(menu.findItem(R.id.action_search), new MenuItemCompat.OnActionExpandListener() {

            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                if (((MainActivity) getActivity()).getSupportActionBar() != null) {
                    ((MainActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getActivity().getResources().getColor(R.color.white)));
                }
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                if (((MainActivity) getActivity()).getSupportActionBar() != null) {
                    ((MainActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getActivity().getResources().getColor(R.color.colorPrimary)));
                }
                mIsLoadingMore = true;
                oldestKeyYouveSeen = null;
                currentpage = 0;
                //EndlessRecyclerOnScrollListener.current_page = 0;
                searchtext = "";
                LoadImagedata(currentpage);
                return true;
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                mIsLoadingMore = true;
                oldestKeyYouveSeen = null;
                currentpage = 0;
                //EndlessRecyclerOnScrollListener.current_page = 0;
                if (query.length() > 0) {
                    searchtext = query;
                    LoadBoLSearchdata(currentpage,searchtext);
                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String query) {
                if (query.length() <= 0) {
                    mIsLoadingMore = true;
                    oldestKeyYouveSeen = null;
                    currentpage = 0;
                    //EndlessRecyclerOnScrollListener.current_page = 0;
                    searchtext = "";
                    LoadImagedata(currentpage);
                }
                return false;
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                TransitionManager.beginDelayedTransition((ViewGroup) getActivity().findViewById(R.id.toolbar));
                MenuItemCompat.expandActionView(item);
                return true;
            default:
                break;
        }

        return false;
    }

    @Override
    public void onResume() {

        super.onResume();
        mIsLoadingMore = true;
        oldestKeyYouveSeen = null;
        currentpage = 0;
        searchtext = "";
        LoadImagedata(currentpage);



        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {
                    if (!searchView.isIconified()) {
                        searchView.setIconified(true);
                        return false;
                    }
                }
                return false;
            }
        });

    }

    public void LoadImagedata(final int pagenumber) {
        Log.e("gettingfield",mIsLoadingMore+"   ::   "+oldestKeyYouveSeen+"   ::   "+currentpage+"   ::   "+"   ::   "+searchtext);
        if (conn.booleanValue()) {
            if (pagenumber == 0) {
                progressBar.setVisibility(View.VISIBLE);
                items_recycler.setVisibility(View.VISIBLE);
                no_data_text.setVisibility(View.GONE);
            }
            Query bolQuery;

            if (oldestKeyYouveSeen != null) {
                bolQuery = ref.orderByKey().endAt(oldestKeyYouveSeen).limitToLast(TOTAL_ITEM_EACH_LOAD + 1);
            } else {
                bolQuery = ref.orderByKey().limitToLast(TOTAL_ITEM_EACH_LOAD);
            }


            bolQuery.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    if (dataSnapshot.getChildrenCount() < TOTAL_ITEM_EACH_LOAD) {
                        mIsLoadingMore = false;
                    } else {
                        mIsLoadingMore = true;
                    }
                    Boolean getkeybool = true;
                    main_item_list = new ArrayList<>();

                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Item_getset temp = new Item_getset(snapshot.child("item_id").getValue().toString(), snapshot.child("item_name").getValue().toString(), snapshot.child("item_details").getValue().toString());
                        main_item_list.add(0, temp);
                        if (getkeybool) {
                            getkeybool = false;
                            oldestKeyYouveSeen = snapshot.getKey();
                        }
                    }

                    if (main_item_list.size() > 0) {
                        if (mIsLoadingMore) {
                            main_item_list.remove(main_item_list.size() - 1);
                        }
                        mainAdapter.adddata(main_item_list, pagenumber);
                        if (!mIsLoadingMore) {
                            mainAdapter.setnomoredata();
                        }

                    } else {
                        if (pagenumber == 0) {
                            mIsLoadingMore = false;
                            items_recycler.setVisibility(View.GONE);
                            no_data_text.setVisibility(View.VISIBLE);
                            mainAdapter.setnomoredata();
                        }
                    }
                    if (progressBar != null) {
                        progressBar.setVisibility(View.GONE);
                    }

                }


                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Log.e("geterrordatabase", databaseError.getMessage() + " ::");
                    if (pagenumber == 0) {
                        progressBar.setVisibility(View.GONE);
                        items_recycler.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                    }
                }
            });
        } else {
            snackbarcommonrelativeLong(getActivity(), content_home, getResources().getString(R.string.no_internet));
        }
    }


    public void LoadBoLSearchdata(final int pagenumber, final String searchtext) {
        if (conn.booleanValue()) {
            if (pagenumber == 0) {
                progressBar.setVisibility(View.VISIBLE);
                items_recycler.setVisibility(View.VISIBLE);
                no_data_text.setVisibility(View.GONE);
            }

            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    main_item_list = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.child("item_name").getValue().toString().toLowerCase().indexOf(searchtext) >= 0) {
                            Item_getset temp = new Item_getset(snapshot.child("item_id").getValue().toString(), snapshot.child("item_name").getValue().toString(), snapshot.child("item_details").getValue().toString());
                            main_item_list.add(0, temp);
                        }
                    }

                    if (main_item_list.size() > 0) {
                        mainAdapter.adddata(main_item_list, 0);
                        mainAdapter.setnomoredata();
                    } else {
                        items_recycler.setVisibility(View.GONE);
                        no_data_text.setVisibility(View.VISIBLE);
                        mainAdapter.setnomoredata();
                    }
                    if (progressBar != null) {
                        progressBar.setVisibility(View.GONE);
                    }

                }


                @Override
                public void onCancelled(DatabaseError databaseError) {
                    progressBar.setVisibility(View.GONE);
                    items_recycler.setVisibility(View.GONE);
                    no_data_text.setVisibility(View.VISIBLE);
                }
            });
        } else {
            snackbarcommonrelativeLong(getActivity(), content_home, getResources().getString(R.string.no_internet));
        }
    }

    @Override
    public void onItemClick(int position, Item_getset pass_getset, ArrayList<Item_getset> getarray, View v) {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            if (((MainActivity) getActivity()).getSupportActionBar() != null) {
                ((MainActivity) getActivity()).getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getActivity().getResources().getColor(R.color.colorPrimary)));
            }
        }
        Constant.Passing_item_id = pass_getset.getItem_id();
        Constant.Passing_item_array = new ArrayList<>();
        Constant.Passing_item_array.addAll(getarray);
        loadInterstitialAd(pass_getset.getItem_name());
    }

    private void loadInterstitialAd(final String settitle) {
        this.conn = Boolean.valueOf(this.detectorconn.isConnectingToInternet());
        if (conn.booleanValue()) {
            final ProgressDialog progress = new ProgressDialog(getActivity(), R.style.MyAlertDialogStyle);
            progress.setMessage("Loading Ad");
            progress.setCancelable(false);
            progress.show();
            final InterstitialAd interstitialAd = new InterstitialAd(getActivity(), getResources().getString(R.string.facebook_interstitial_id));
            interstitialAd.loadAd();
            interstitialAd.setAdListener(new InterstitialAdListener() {
                @Override
                public void onInterstitialDisplayed(Ad ad) {
                }

                @Override
                public void onInterstitialDismissed(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    ((MainActivity) getActivity()).SelectItem(settitle, 3);
                }

                @Override
                public void onError(Ad ad, AdError adError) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd != null) {
                        interstitialAd.destroy();
                    }
                    ((MainActivity) getActivity()).SelectItem(settitle, 3);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    if (progress.isShowing()) {
                        progress.dismiss();
                    }
                    if (interstitialAd.isAdLoaded()) {
                        interstitialAd.show();
                    }
                }

                @Override
                public void onAdClicked(Ad ad) {
                }

                @Override
                public void onLoggingImpression(Ad ad) {
                }
            });
        } else {
            ((MainActivity) getActivity()).SelectItem(settitle, 3);
        }

    }


    public void snackbarcommonrelativeLong(Context mcontext, RelativeLayout coordinatorLayout, String snackmsg) {
        Snackbar snackbar = Snackbar.make(coordinatorLayout, snackmsg + "", Snackbar.LENGTH_INDEFINITE).setAction("Try Again!", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!searchtext.equals("")){
                    LoadBoLSearchdata(0,searchtext);
                }else{
                    LoadImagedata(currentpage);
                }

            }
        });
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(mcontext, R.color.colorbutton));
        TextView textView = (TextView) snackbarView.findViewById(R.id.snackbar_text);
        TextView textaction = (TextView) snackbarView.findViewById(R.id.snackbar_action);
        textView.setTextSize(16);
        textaction.setTextSize(18);
        textView.setTextColor(ContextCompat.getColor(mcontext, R.color.colorAccentlight));
        textaction.setTextColor(ContextCompat.getColor(mcontext, R.color.colorPrimaryDark));
        snackbar.show();
    }

}
