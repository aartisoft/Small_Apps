package com.nimbukefayde.and.nuskhe.Adapter;


import android.content.ClipData;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.nimbukefayde.and.nuskhe.R;
import com.nimbukefayde.and.nuskhe.gettersetter.Item_getset;

import java.util.ArrayList;
import java.util.Collections;

public class MainItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<Item_getset> BoLitemList = new ArrayList<>();
    private static MyClickListener myClickListener;
    private Context context;
    int[] androidColors;
    public static final int VIEW_TYPE_ITEM = 0;
    public static final int VIEW_TYPE_LOADING = 1;


    public void setnomoredata() {
        this.BoLitemList.removeAll(Collections.singleton(null));
        notifyDataSetChanged();
    }


    public static class DataObjectHolder extends RecyclerView.ViewHolder {

        ImageView image_detail;
        TextView item_title;
        CardView item_cardview;

        public DataObjectHolder(View itemView) {
            super(itemView);
            image_detail = (ImageView) itemView.findViewById(R.id.image_detail);
            item_title = (TextView) itemView.findViewById(R.id.item_title);
            item_cardview = (CardView) itemView.findViewById(R.id.item_cardview);
        }

        public void bind(final int pos, final Item_getset passdata) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //myClickListener.onItemClick(pos,passdata, v);
                }
            });
        }

    }

    private class ViewHolderLoading extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        public ViewHolderLoading(View view) {
            super(view);
            progressBar = (ProgressBar) view.findViewById(R.id.itemProgressbar);
        }
    }

    public void adddata(ArrayList<Item_getset> bolitemList, int pagenumber) {
        if (pagenumber == 0) {
            this.BoLitemList.clear();
            this.BoLitemList.addAll(bolitemList);
            this.BoLitemList.add(null);
        } else {
            this.BoLitemList.removeAll(Collections.singleton(null));
            this.BoLitemList.addAll(bolitemList);
            this.BoLitemList.add(null);
        }
        notifyDataSetChanged();
    }

    public MainItemAdapter(Context context) {
        this.context = context;
        this.BoLitemList = new ArrayList<>();
        androidColors = context.getResources().getIntArray(R.array.colors);
    }

    public void setClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_item_row, parent, false);
            return new DataObjectHolder(view);
        } else if (viewType == VIEW_TYPE_LOADING) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_progressbar, parent, false);
            return new ViewHolderLoading(view);
        }
        return null;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof DataObjectHolder) {

            final DataObjectHolder userViewHolder = (DataObjectHolder) holder;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                userViewHolder.item_title.setText(Html.fromHtml(BoLitemList.get(position).getItem_name()+"", Html.FROM_HTML_MODE_COMPACT));
            } else {
                userViewHolder.item_title.setText(Html.fromHtml(BoLitemList.get(position).getItem_name()+""));
            }

            userViewHolder.item_cardview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ArrayList<Item_getset> templist = new ArrayList<>();
                    templist.addAll(BoLitemList);
                    templist.removeAll(Collections.singleton(null));
                    myClickListener.onItemClick(position,BoLitemList.get(position),templist, v);
                }
            });

            //userViewHolder.bind(position,BoLitemList.get(position));
        } else if (holder instanceof ViewHolderLoading) {
            if (position == BoLitemList.size()-1){
                ViewHolderLoading loadingViewHolder = (ViewHolderLoading) holder;
                loadingViewHolder.progressBar.setIndeterminate(true);
            }

        }

    }


    @Override
    public int getItemCount() {
        return BoLitemList == null ? 0 : BoLitemList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return BoLitemList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }


    public interface MyClickListener {
        public void onItemClick(int position, Item_getset dataobject, ArrayList<Item_getset> bolitemList, View v);

    }


}
